import React, { useState } from 'react';
import { Trophy, Lock } from 'lucide-react';

export default function Badges() {
  const [badges] = useState([
    { id: 1, name: 'Premier pas', description: 'Complétez votre 1er entraînement', unlocked: true, icon: '👟', date: '2026-04-10' },
    { id: 2, name: 'Week Warrior', description: '7 jours consécutifs', unlocked: true, icon: '⚡', date: '2026-04-20' },
    { id: 3, name: 'Century', description: '100 entraînements complétés', unlocked: false, icon: '💯', progress: 45 },
    { id: 4, name: 'Iron Grip', description: 'Soulevez 100kg+', unlocked: false, icon: '💪', progress: 60 },
    { id: 5, name: 'Cardio King', description: '50km de distance', unlocked: false, icon: '🏃', progress: 28 },
    { id: 6, name: 'Social Butterfly', description: 'Invitez 5 amis', unlocked: true, icon: '🦋', date: '2026-04-15' },
    { id: 7, name: 'Calorie Crusher', description: 'Brûlez 10k calories', unlocked: false, icon: '🔥', progress: 72 },
    { id: 8, name: 'Champion', description: 'Gagnez un défi', unlocked: false, icon: '🥇', progress: 15 },
  ]);

  const [leaderboard] = useState([
    { rank: 1, name: 'Amadou', badges: 12, points: 5600 },
    { rank: 2, name: 'Fatima', badges: 10, points: 4800 },
    { rank: 3, name: 'Papa', badges: 9, points: 4200 },
    { rank: 4, name: 'Vous', badges: 6, points: 2850 },
  ]);

  const stats = {
    totalBadges: badges.filter(b => b.unlocked).length,
    totalPoints: 2850,
    nextBadge: 'Century - 45/100 entraînements',
  };

  return (
    <div className="badges">
      <h1>🏆 Badges & Récompenses</h1>

      {/* Stats */}
      <div className="stats-banner">
        <div className="stat-item">
          <div className="stat-val">{stats.totalBadges}</div>
          <div className="stat-lab">Badges obtenus</div>
        </div>
        <div className="stat-item">
          <div className="stat-val">{stats.totalPoints}</div>
          <div className="stat-lab">Points</div>
        </div>
      </div>

      {/* Next Badge */}
      <div className="next-badge">
        <h3>🎯 Prochain badge</h3>
        <div className="badge-progress">
          <div className="progress-bar">
            <div className="progress-fill" style={{ width: '45%' }}></div>
          </div>
          <p>{stats.nextBadge}</p>
        </div>
      </div>

      {/* Badges Grid */}
      <div className="badges-section">
        <h2>Tous les badges</h2>
        <div className="badges-grid">
          {badges.map(badge => (
            <div 
              key={badge.id} 
              className={`badge-card ${badge.unlocked ? 'unlocked' : 'locked'}`}
            >
              <div className="badge-icon">
                {badge.unlocked ? badge.icon : <Lock size={32} />}
              </div>
              <h3>{badge.name}</h3>
              <p>{badge.description}</p>
              {!badge.unlocked && (
                <div className="badge-progress-small">
                  <div className="progress-bar-small">
                    <div className="progress-fill-small" style={{ width: `${badge.progress}%` }}></div>
                  </div>
                  <span>{badge.progress}%</span>
                </div>
              )}
              {badge.unlocked && (
                <p className="unlock-date">Obtenu le {badge.date}</p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Leaderboard */}
      <div className="leaderboard-section">
        <h2>🏅 Classement des badges</h2>
        {leaderboard.map(entry => (
          <div key={entry.rank} className="leaderboard-row">
            <div className="rank-badge">#{entry.rank}</div>
            <div className="user-name">{entry.name}</div>
            <div className="user-badges">
              <Trophy size={14} />
              {entry.badges}
            </div>
            <div className="user-points">{entry.points}pts</div>
          </div>
        ))}
      </div>

      {/* Achievement Tips */}
      <div className="tips">
        <h2>💡 Conseils</h2>
        <div className="tip-card">
          <p>✅ Entraînez-vous régulièrement pour débloquer plus de badges</p>
        </div>
        <div className="tip-card">
          <p>✅ Participez aux défis pour augmenter vos points</p>
        </div>
        <div className="tip-card">
          <p>✅ Invitez vos amis pour débloquer le badge Social</p>
        </div>
      </div>

      <style jsx>{`
        .badges {
          padding: 20px;
          max-width: 500px;
          margin: 0 auto;
        }

        .badges h1 {
          margin-bottom: 20px;
          color: #ff6b35;
        }

        .stats-banner {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
          margin-bottom: 20px;
        }

        .stat-item {
          background: #ff6b35;
          color: white;
          padding: 20px;
          border-radius: 10px;
          text-align: center;
        }

        .stat-val {
          font-size: 28px;
          font-weight: bold;
          margin-bottom: 5px;
        }

        .stat-lab {
          font-size: 12px;
          opacity: 0.9;
        }

        .next-badge {
          background: #fff9f0;
          border: 2px solid #ff6b35;
          padding: 15px;
          border-radius: 10px;
          margin-bottom: 20px;
        }

        .next-badge h3 {
          margin: 0 0 12px 0;
          color: #ff6b35;
        }

        .badge-progress {
          margin: 0;
        }

        .progress-bar {
          width: 100%;
          height: 12px;
          background: #ffe0cc;
          border-radius: 6px;
          overflow: hidden;
          margin-bottom: 8px;
        }

        .progress-fill {
          height: 100%;
          background: #ff6b35;
          transition: width 0.3s;
        }

        .badge-progress p {
          margin: 0;
          font-size: 12px;
          color: #666;
        }

        .badges-section {
          margin-bottom: 30px;
        }

        .badges-section h2 {
          margin-bottom: 15px;
          color: #333;
        }

        .badges-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
        }

        .badge-card {
          background: white;
          border: 2px solid #eee;
          padding: 15px;
          border-radius: 10px;
          text-align: center;
        }

        .badge-card.unlocked {
          border-color: #ff6b35;
          background: #fff9f0;
        }

        .badge-icon {
          font-size: 40px;
          margin-bottom: 10px;
          opacity: 0.5;
        }

        .badge-card.unlocked .badge-icon {
          opacity: 1;
        }

        .badge-card h3 {
          margin: 0 0 5px 0;
          font-size: 12px;
          color: #333;
        }

        .badge-card p {
          margin: 0;
          font-size: 10px;
          color: #999;
        }

        .unlock-date {
          font-size: 10px;
          color: #ff6b35;
          margin-top: 8px;
        }

        .badge-progress-small {
          margin-top: 8px;
        }

        .progress-bar-small {
          width: 100%;
          height: 6px;
          background: #eee;
          border-radius: 3px;
          overflow: hidden;
          margin-bottom: 4px;
        }

        .progress-fill-small {
          height: 100%;
          background: #ff6b35;
        }

        .badge-progress-small span {
          font-size: 9px;
          color: #666;
        }

        .leaderboard-section {
          background: white;
          padding: 15px;
          border-radius: 10px;
          margin-bottom: 30px;
        }

        .leaderboard-section h2 {
          margin: 0 0 15px 0;
          color: #333;
        }

        .leaderboard-row {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px;
          background: #f9f9f9;
          border-radius: 8px;
          margin-bottom: 8px;
          font-size: 12px;
        }

        .rank-badge {
          background: #ff6b35;
          color: white;
          width: 32px;
          height: 32px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          font-size: 11px;
        }

        .user-name {
          flex: 1;
          color: #333;
          font-weight: bold;
        }

        .user-badges {
          display: flex;
          align-items: center;
          gap: 4px;
          color: #ff6b35;
          font-weight: bold;
        }

        .user-points {
          font-weight: bold;
          color: #ffa500;
        }

        .tips {
          margin-top: 20px;
        }

        .tips h2 {
          margin-bottom: 12px;
          color: #333;
        }

        .tip-card {
          background: #f0f0f0;
          padding: 12px;
          border-radius: 8px;
          margin-bottom: 8px;
          font-size: 12px;
          color: #333;
        }

        .tip-card p {
          margin: 0;
        }
      `}</style>
    </div>
  );
}

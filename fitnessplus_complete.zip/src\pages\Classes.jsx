import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Calendar, Clock, MapPin, ChevronRight, 
  Search, Filter, Play, CheckCircle2, User
} from 'lucide-react';

const Classes = () => {
  const navigate = useNavigate();
  const [activeDay, setActiveDay] = useState('Lun');

  const days = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];
  
  const classes = [
    { 
      id: 1, name: 'Crossfit Intense', coach: 'Coach Ousmane', 
      time: '08:00 - 09:30', room: 'Zone A', type: 'Haute Intensité', 
      spots: '3 places', image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=200&auto=format&fit=crop' 
    },
    { 
      id: 2, name: 'Prépa Lutte MMA', coach: 'Coach Eloufit', 
      time: '10:00 - 12:00', room: 'Dojo', type: 'Combat', 
      spots: 'Plein', image: 'https://images.unsplash.com/photo-1595078475328-1ab05d0a6a0e?q=80&w=200&auto=format&fit=crop' 
    },
    { 
      id: 3, name: 'Yoga Flow & Chill', coach: 'Coach Amina', 
      time: '17:30 - 18:30', room: 'Studio Zen', type: 'Bien-être', 
      spots: '12 places', image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=200&auto=format&fit=crop' 
    },
  ];

  return (
    <div className="page-container">
      {/* Header */}
      <div className="flex-between mb-8 stagger-1">
        <div>
          <h1 style={{ fontSize: '2rem', marginBottom: '8px' }}>Planning</h1>
          <p className="subtitle">Réserve ta place en un clic</p>
        </div>
        <div className="btn-icon">
          <Filter size={24} />
        </div>
      </div>

      {/* Day Selector */}
      <div style={{ display: 'flex', gap: '12px', overflowX: 'auto', paddingBottom: '16px', marginBottom: '32px' }} className="no-scrollbar stagger-1">
        {days.map(day => (
          <button 
            key={day}
            onClick={() => setActiveDay(day)}
            style={{ 
              minWidth: '64px', height: '80px', borderRadius: '20px',
              background: activeDay === day ? 'var(--primary)' : 'var(--bg-card)',
              color: activeDay === day ? '#000' : '#888',
              border: activeDay === day ? 'none' : '1px solid var(--surface-border)',
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: '8px', cursor: 'pointer', transition: 'all 0.3s'
            }}
          >
            <span style={{ fontSize: '0.7rem', fontWeight: '900', textTransform: 'uppercase' }}>{day}</span>
            <span style={{ fontSize: '1.2rem', fontWeight: '900' }}>{days.indexOf(day) + 12}</span>
          </button>
        ))}
      </div>

      {/* Classes List */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }} className="stagger-2">
        <h3 className="mb-4">Cours disponibles</h3>
        {classes.map((c, i) => (
          <div key={c.id} className="glass-panel" style={{ padding: '16px', display: 'flex', gap: '20px', position: 'relative', overflow: 'hidden' }}>
            <div style={{ width: '100px', height: '120px', borderRadius: '16px', overflow: 'hidden', flexShrink: 0 }}>
              <img src={c.image} alt={c.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            </div>
            
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
              <div style={{ fontSize: '0.65rem', fontWeight: '900', color: 'var(--primary)', textTransform: 'uppercase', marginBottom: '4px' }}>{c.type}</div>
              <h4 style={{ fontSize: '1.1rem', marginBottom: '8px' }}>{c.name}</h4>
              
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                <div className="flex-center" style={{ justifyContent: 'flex-start', gap: '8px', color: 'var(--text-muted)', fontSize: '0.75rem' }}>
                  <Clock size={14} /> <span>{c.time}</span>
                </div>
                <div className="flex-center" style={{ justifyContent: 'flex-start', gap: '8px', color: 'var(--text-muted)', fontSize: '0.75rem' }}>
                  <MapPin size={14} /> <span>{c.room}</span>
                </div>
                <div className="flex-center" style={{ justifyContent: 'flex-start', gap: '8px', color: 'var(--text-muted)', fontSize: '0.75rem' }}>
                  <User size={14} /> <span>{c.coach}</span>
                </div>
              </div>
            </div>

            <div style={{ position: 'absolute', top: '16px', right: '16px' }}>
              <span style={{ fontSize: '0.65rem', fontWeight: '900', color: c.spots === 'Plein' ? 'var(--danger)' : '#10b981' }}>{c.spots.toUpperCase()}</span>
            </div>
            
            <button 
              className="flex-center"
              style={{ 
                position: 'absolute', bottom: '16px', right: '16px',
                width: '44px', height: '44px', borderRadius: '14px',
                background: c.spots === 'Plein' ? '#222' : 'var(--primary)',
                border: 'none', color: '#000', cursor: c.spots === 'Plein' ? 'not-allowed' : 'pointer',
                boxShadow: c.spots === 'Plein' ? 'none' : '0 8px 15px var(--primary-glow)'
              }}
              disabled={c.spots === 'Plein'}
              onClick={() => alert(`Réservation confirmée pour ${c.name} !`)}
            >
              {c.spots === 'Plein' ? <CheckCircle2 size={20} color="#444" /> : <Play size={20} fill="#000" />}
            </button>
          </div>
        ))}
      </div>

      {/* Featured Workout Card */}
      <div className="glass-panel mt-12 stagger-3" style={{ background: 'linear-gradient(135deg, #111 0%, #000 100%)', border: '1px solid var(--primary-glow)', padding: '32px' }}>
        <h3 className="mb-4">Ton Coach IA Personnel</h3>
        <p className="subtitle mb-6">Tu ne sais pas quel cours choisir ? Laisse notre IA analyser tes objectifs et te proposer le meilleur créneau.</p>
        <button className="btn-primary" style={{ height: '60px', fontSize: '1rem' }} onClick={() => navigate('/assistant')}>Analyser mon planning</button>
      </div>
    </div>
  );
};

export default Classes;

import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, QrCode, User, Users, Dumbbell, ClipboardList, ShoppingBag, TrendingUp, Zap, Trophy, Apple, Video, MapPin, Bell, Search } from 'lucide-react';

const BottomNav = () => {
  // Déterminer le rôle réel depuis le stockage
  const role = localStorage.getItem('fp_user_role') || 'client';

  let navItems = [];

  if (role === 'coach') {
    navItems = [
      { id: 'coach-dash', icon: <Home size={24} />, label: 'Tableau', path: '/coach-dashboard' },
      { id: 'coach-clients', icon: <Users size={24} />, label: 'Élèves', path: '/coach/clients' },
      { id: 'coach-profile', icon: <User size={24} />, label: 'Profil', path: '/profile' }
    ];
  } else {
    // Nav Client standard FitnessPlus Style
    navItems = [
      { id: 'dashboard', icon: <Home size={24} />, label: 'Accueil', path: '/dashboard' },
      { id: 'explore', icon: <Search size={24} />, label: 'Explorer', path: '/explore' },
      { id: 'qr', icon: <QrCode size={30} />, label: '', path: '/qr', isMain: true },
      { id: 'progress', icon: <TrendingUp size={24} />, label: 'Suivi', path: '/progress' },
      { id: 'profile', icon: <User size={24} />, label: 'Profil', path: '/profile' }
    ];
  }

  return (
    <nav className="bottom-nav">
      {navItems.map((item) => (
        <NavLink
          key={item.id}
          to={item.path}
          className={({ isActive }) => 
            `nav-item ${isActive ? 'active' : ''} ${item.isMain ? 'nav-item-main' : ''}`
          }
        >
          <div className={`nav-icon ${item.isMain ? 'main-icon' : ''}`}>
            {item.icon}
          </div>
          {!item.isMain && <span className="nav-label">{item.label}</span>}
        </NavLink>
      ))}

      <style>{`
        .nav-item-main {
          transform: translateY(-20px);
        }
        .main-icon {
          background: var(--primary);
          color: #000;
          padding: 15px;
          border-radius: 50%;
          box-shadow: 0 10px 25px var(--primary-glow);
          border: 5px solid var(--bg-dark);
          display: flex;
          align-items: center;
          justify-content: center;
        }
        .nav-item.active {
          color: var(--primary) !important;
        }
        .nav-item.active .nav-icon {
          transform: translateY(-2px);
        }
      `}</style>
    </nav>
  );
};

export default BottomNav;

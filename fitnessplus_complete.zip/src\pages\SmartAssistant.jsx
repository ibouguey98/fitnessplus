import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Send, Sparkles, Brain, MessageSquare, ChevronLeft, Zap, Target } from 'lucide-react';

const SmartAssistant = () => {
  const navigate = useNavigate();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([
    { role: 'bot', text: 'Bonjour ! Je suis ton assistant FitnessPlus IA. Comment puis-je t\'aider dans ton entraînement aujourd\'hui ?' }
  ]);
  const [loading, setLoading] = useState(false);

  const userStats = {
    workouts: 42,
    streak: 12,
    calories: 8500,
  };

  const getBotResponse = (text) => {
    const t = text.toLowerCase();
    if (t.includes('nutrition') || t.includes('calorie')) {
      return `Avec ${userStats.calories} kcal brûlées au total, vise une récupération active et un apport protéiné après l'effort.`;
    }
    if (t.includes('progress') || t.includes('progression') || t.includes('entrainement') || t.includes('workout')) {
      return `Tu as ${userStats.workouts} entraînements au compteur et une série de ${userStats.streak} jours — belle progression ! Continue les séances courtes et intenses.`;
    }
    if (t.includes('cardio')) {
      return 'Bon choix. Pour le cardio, fais 25–40 minutes à intensité modérée ou 20 minutes HIIT selon ton énergie.';
    }
    if (t.includes('récup') || t.includes('repos') || t.includes('yoga')) {
      return 'Je te recommande une séance de mobilité / yoga léger de 25 minutes et 10 minutes d\'étirements.';
    }
    return 'Analyse rapide... Essaie de préciser ton objectif (force, cardio, nutrition, récupération).';
  };

  const handleSendWithText = (text) => {
    const trimmed = text.trim();
    if (!trimmed) return;
    setLoading(true);
    const newMessages = [...messages, { role: 'user', text: trimmed }];
    // add user message and a typing placeholder
    setMessages([...newMessages, { role: 'bot', text: '...', typing: true }]);
    setInput('');

    setTimeout(() => {
      const reply = getBotResponse(trimmed);
      // replace last typing message with real reply
      setMessages(prev => {
        const withoutTyping = prev.filter((m, i) => !(i === prev.length - 1 && m.typing));
        return [...withoutTyping, { role: 'bot', text: reply }];
      });
      setLoading(false);
    }, 900 + Math.min(trimmed.length * 20, 900));
  };

  const handleSend = () => handleSendWithText(input);

  return (
    <div className="page-container" style={{ display: 'flex', flexDirection: 'column', height: '100vh', paddingBottom: '0' }}>
      {/* Header */}
      <div className="flex-between mb-8 stagger-1">
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <div style={{ width: '50px', height: '50px', background: 'var(--primary)', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 25px var(--primary-glow)' }}>
            <Brain color="#000" size={28} />
          </div>
          <div>
            <h1 style={{ fontSize: '1.5rem', marginBottom: '2px' }}>FITNESSPLUS <span style={{ color: 'var(--primary)' }}>IA</span></h1>
            <div className="flex-center" style={{ justifyContent: 'flex-start', gap: '6px' }}>
              <div style={{ width: '6px', height: '6px', background: '#10b981', borderRadius: '50%' }} />
              <span className="subtitle" style={{ fontSize: '0.7rem' }}>En ligne • Prêt à aider</span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Suggestions */}
      <div style={{ display: 'flex', gap: '10px', overflowX: 'auto', marginBottom: '24px' }} className="no-scrollbar stagger-1">
        {['Planifier ma semaine', 'Conseils nutrition', 'Routine cardio', 'Ma progression'].map(s => (
          <button 
            key={s} 
            onClick={() => handleSendWithText(s)}
            style={{ 
              padding: '12px 20px', borderRadius: '14px', background: 'rgba(255,255,255,0.05)', 
              border: '1px solid rgba(255,255,255,0.1)', color: '#fff', fontSize: '0.75rem', 
              fontWeight: '700', whiteSpace: 'nowrap', cursor: 'pointer',
              transition: 'all 0.2s ease'
            }}
            onMouseOver={e => e.currentTarget.style.background = 'rgba(255,255,255,0.1)'}
            onMouseOut={e => e.currentTarget.style.background = 'rgba(255,255,255,0.05)'}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Chat Area */}
      <div 
        id="chat-area"
        style={{ 
          flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', 
          gap: '16px', padding: '0 4px 150px 4px', scrollBehavior: 'smooth' 
        }} 
        className="no-scrollbar stagger-2"
      >
        {messages.map((m, i) => (
          <div key={i} style={{ 
            alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start',
            maxWidth: '90%',
            padding: '14px 18px',
            borderRadius: m.role === 'user' ? '24px 24px 4px 24px' : '24px 24px 24px 4px',
            background: m.role === 'user' ? 'var(--primary)' : '#1a1a1a',
            border: m.role === 'user' ? 'none' : '1px solid #222',
            color: m.role === 'user' ? '#000' : '#f0f0f0',
            fontWeight: m.role === 'user' ? '800' : '500',
            fontSize: '0.95rem',
            lineHeight: '1.6',
            boxShadow: m.role === 'user' ? '0 8px 16px rgba(212, 255, 0, 0.15)' : '0 4px 12px rgba(0,0,0,0.3)',
            animation: 'slideUp 0.4s ease-out forwards',
            wordBreak: 'break-word'
          }}>
            {m.typing ? (
              <div style={{ display: 'flex', gap: '4px', padding: '4px 0' }}>
                <div className="dot" style={{ width: '6px', height: '6px', background: '#555', borderRadius: '50%', animation: 'bounce 1.4s infinite 0.1s' }} />
                <div className="dot" style={{ width: '6px', height: '6px', background: '#555', borderRadius: '50%', animation: 'bounce 1.4s infinite 0.2s' }} />
                <div className="dot" style={{ width: '6px', height: '6px', background: '#555', borderRadius: '50%', animation: 'bounce 1.4s infinite 0.3s' }} />
              </div>
            ) : m.text}
          </div>
        ))}
        <div ref={el => el?.scrollIntoView({ behavior: 'smooth' })} />
      </div>

      {/* Input Area */}
      <div style={{ 
        position: 'absolute', bottom: '100px', left: '20px', right: '20px',
        background: 'rgba(20,20,20,0.9)', backdropFilter: 'blur(30px)',
        padding: '8px', borderRadius: '24px', border: '1px solid rgba(255,255,255,0.1)',
        display: 'flex', gap: '8px', alignItems: 'center',
        boxShadow: '0 10px 30px rgba(0,0,0,0.5)'
      }} className="stagger-3">
        <input 
          type="text" 
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Pose ta question ici..."
          style={{ flex: 1, background: 'transparent', border: 'none', color: 'white', padding: '12px', fontSize: '1rem', outline: 'none' }}
          onKeyPress={e => e.key === 'Enter' && !loading && input.trim() && handleSend()}
        />
        <button 
          onClick={handleSend}
          disabled={!input.trim() || loading}
          style={{ 
            width: '48px', height: '48px', borderRadius: '18px', 
            background: input.trim() && !loading ? 'var(--primary)' : '#222', 
            border: 'none', cursor: input.trim() && !loading ? 'pointer' : 'default', 
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            transition: 'all 0.3s ease',
            opacity: input.trim() && !loading ? 1 : 0.5
          }}
        >
          <Send size={20} color="#000" fill={input.trim() && !loading ? '#000' : 'none'} />
        </button>
        <style>{`
        .stagger-1 { animation: slideUp 0.6s ease-out forwards; }
        .stagger-2 { opacity: 0; animation: slideUp 0.6s ease-out 0.2s forwards; }
        .stagger-3 { opacity: 0; animation: slideUp 0.6s ease-out 0.4s forwards; }
        
        @keyframes bounce {
          0%, 80%, 100% { transform: translateY(0); }
          40% { transform: translateY(-6px); }
        }
        
        @keyframes slideUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
      </div>
    </div>
  );
};

export default SmartAssistant;

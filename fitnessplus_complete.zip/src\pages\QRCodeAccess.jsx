import React from 'react';
import { useNavigate } from 'react-router-dom';
import { QrCode, ScanLine, Info, Camera } from 'lucide-react';

const QRCodeAccess = () => {
  const navigate = useNavigate();
  return (
    <div className="page-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', paddingBottom: '120px' }}>
      
      <div style={{ textAlign: 'center', marginBottom: '30px' }}>
        <h1 className="text-gradient" style={{ fontSize: '2.5rem', marginBottom: '10px' }}>Accès Salle</h1>
        <p className="subtitle">Choisissez votre méthode de check-in</p>
      </div>

      <div className="glass-panel" style={{ 
        padding: '30px', 
        borderRadius: '24px', 
        display: 'flex', 
        flexDirection: 'column', 
        alignItems: 'center',
        boxShadow: '0 20px 40px rgba(212, 255, 0, 0.1)',
        border: '1px solid var(--primary-glow)',
        position: 'relative',
        width: '100%',
        maxWidth: '320px'
      }}>
        <div style={{ 
          background: 'white', 
          padding: '20px', 
          borderRadius: '16px',
          marginBottom: '20px'
        }}>
          <QrCode size={160} color="#000" strokeWidth={1.5} />
        </div>

        <div style={{ fontSize: '1rem', fontWeight: 'bold', letterSpacing: '2px', color: 'var(--text-muted)', marginBottom: '24px' }}>
          ID: FP-8492-DKR
        </div>

        <div style={{ width: '100%', height: '1px', background: 'var(--surface-border)', marginBottom: '24px' }}></div>

        <button 
          className="btn-primary" 
          onClick={() => navigate('/scanner')}
          style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '10px' }}
        >
          <Camera size={20} /> Scanner la borne
        </button>
      </div>

      <div className="glass-panel mt-4" style={{ width: '100%', maxWidth: '320px', display: 'flex', alignItems: 'flex-start', gap: '10px', padding: '15px' }}>
        <Info color="var(--primary)" size={20} style={{ flexShrink: 0, marginTop: '2px' }} />
        <p className="subtitle" style={{ fontSize: '0.8rem', textAlign: 'left' }}>
          Vous pouvez présenter votre QR Code au lecteur ou scanner directement le code de la borne avec votre caméra.
        </p>
      </div>

    </div>
  );
};

export default QRCodeAccess;

import React from 'react';
import { Target, CheckCircle2, TrendingUp, Plus } from 'lucide-react';

const MyGoals = () => {
  const goals = [
    { id: 1, title: 'Perdre 5kg de gras', progress: 60, deadline: 'Mars 2025' },
    { id: 2, title: 'Soulever 100kg au DC', progress: 40, deadline: 'Avril 2025' },
    { id: 3, title: 'Courir 10km sans arrêt', progress: 90, deadline: 'Février 2025' },
  ];

  return (
    <div className="page-container">
      <h1 className="mb-6">Mes Objectifs</h1>
      
      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        {goals.map(goal => (
          <div key={goal.id} className="glass-panel">
            <div className="flex-between mb-4">
              <h3 style={{ fontSize: '1.1rem' }}>{goal.title}</h3>
              <span style={{ fontSize: '0.8rem', color: 'var(--primary)', fontWeight: 'bold' }}>{goal.progress}%</span>
            </div>
            <div style={{ width: '100%', height: '8px', background: 'var(--surface-solid)', borderRadius: '4px', marginBottom: '12px', overflow: 'hidden' }}>
              <div style={{ width: `${goal.progress}%`, height: '100%', background: 'var(--primary)', borderRadius: '4px' }} />
            </div>
            <p className="subtitle" style={{ fontSize: '0.8rem' }}>Échéance : {goal.deadline}</p>
          </div>
        ))}
      </div>

      <button className="btn-primary mt-6" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
        <Plus size={20} /> Nouvel Objectif
      </button>

      <div style={{ padding: '40px 0', textAlign: 'center' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>Dépassez vos limites avec FitnessPlus</p>
      </div>
    </div>
  );
};

export default MyGoals;

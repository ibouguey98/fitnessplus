import React, { useState } from 'react';
import { MapPin, Phone, Clock, Star } from 'lucide-react';

export default function PartnerGyms() {
  const [gyms] = useState([
    { id: 1, name: 'FitnessPLUS Pikine', address: 'Pikine, Dakar', distance: 0.5, rating: 4.8, phone: '+221 78 123 4567', hours: '06:00 - 22:00', lat: 14.7669, lng: -17.3769 },
    { id: 2, name: 'PowerGym Ngor', address: 'Ngor, Dakar', distance: 8.2, rating: 4.5, phone: '+221 78 234 5678', hours: '06:30 - 21:00', lat: 14.7505, lng: -17.5083 },
    { id: 3, name: 'FitBody Plateau', address: 'Plateau, Dakar', distance: 12.5, rating: 4.6, phone: '+221 78 345 6789', hours: '05:30 - 22:30', lat: 14.6928, lng: -17.4404 },
    { id: 4, name: 'StrengthZone Almadies', address: 'Almadies, Dakar', distance: 15.3, rating: 4.7, phone: '+221 78 456 7890', hours: '06:00 - 23:00', lat: 14.6471, lng: -17.5236 },
  ]);

  const [selectedGym, setSelectedGym] = useState(null);

  return (
    <div className="partner-gyms">
      <h1>📍 Salles Partenaires</h1>

      {/* Map View */}
      <div className="map-container">
        <div className="map-placeholder">
          <MapPin size={48} color="#ff6b35" />
          <p>Carte interactive des salles</p>
          <small>Dakar, Sénégal</small>
        </div>
      </div>

      {/* Gym List */}
      <div className="gyms-list">
        <h2>Salles à proximité</h2>
        {gyms.map(gym => (
          <div 
            key={gym.id} 
            className={`gym-card ${selectedGym?.id === gym.id ? 'selected' : ''}`}
            onClick={() => setSelectedGym(gym)}
          >
            <div className="gym-header">
              <h3>{gym.name}</h3>
              <div className="gym-rating">
                <Star size={16} fill="#ffa500" color="#ffa500" />
                <span>{gym.rating}</span>
              </div>
            </div>

            <div className="gym-info">
              <div className="info-row">
                <MapPin size={16} />
                <div>
                  <p className="info-label">Localisation</p>
                  <p className="info-value">{gym.address} • {gym.distance}km</p>
                </div>
              </div>

              <div className="info-row">
                <Clock size={16} />
                <div>
                  <p className="info-label">Horaires</p>
                  <p className="info-value">{gym.hours}</p>
                </div>
              </div>

              <div className="info-row">
                <Phone size={16} />
                <div>
                  <p className="info-label">Téléphone</p>
                  <p className="info-value">{gym.phone}</p>
                </div>
              </div>
            </div>

            <div className="gym-actions">
              <button className="btn-direction">📍 Direction</button>
              <button className="btn-call">📞 Appeler</button>
            </div>
          </div>
        ))}
      </div>

      {/* Facilities */}
      <div className="facilities">
        <h2>Équipements disponibles</h2>
        <div className="facilities-grid">
          <div className="facility-badge">💪 Haltères</div>
          <div className="facility-badge">🏃 Tapis roulants</div>
          <div className="facility-badge">🚴 Vélos</div>
          <div className="facility-badge">🧘 Yoga</div>
          <div className="facility-badge">🥊 Boxing</div>
          <div className="facility-badge">🏊 Piscine</div>
        </div>
      </div>

      <style jsx>{`
        .partner-gyms {
          padding: 20px;
          max-width: 500px;
          margin: 0 auto;
        }

        .partner-gyms h1 {
          margin-bottom: 20px;
          color: #ff6b35;
        }

        .map-container {
          background: #f0f0f0;
          border-radius: 15px;
          height: 200px;
          display: flex;
          align-items: center;
          justify-content: center;
          margin-bottom: 20px;
          text-align: center;
        }

        .map-placeholder {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 10px;
          color: #999;
        }

        .map-placeholder p {
          margin: 0;
          font-size: 14px;
        }

        .map-placeholder small {
          color: #ccc;
        }

        .gyms-list {
          margin-bottom: 30px;
        }

        .gyms-list h2 {
          margin-bottom: 15px;
          color: #333;
        }

        .gym-card {
          background: #fff;
          border: 2px solid #eee;
          padding: 15px;
          border-radius: 12px;
          margin-bottom: 12px;
          transition: all 0.3s;
          cursor: pointer;
        }

        .gym-card:hover,
        .gym-card.selected {
          border-color: #ff6b35;
          box-shadow: 0 4px 12px rgba(255, 107, 53, 0.2);
        }

        .gym-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 12px;
        }

        .gym-header h3 {
          margin: 0;
          color: #333;
          font-size: 14px;
        }

        .gym-rating {
          display: flex;
          align-items: center;
          gap: 4px;
          background: #fff9f0;
          padding: 4px 8px;
          border-radius: 6px;
          font-size: 12px;
        }

        .gym-info {
          margin: 12px 0;
        }

        .info-row {
          display: flex;
          gap: 10px;
          margin-bottom: 10px;
          font-size: 12px;
          color: #ff6b35;
        }

        .info-label {
          margin: 0;
          color: #999;
          font-size: 10px;
        }

        .info-value {
          margin: 3px 0 0 0;
          color: #333;
          font-size: 12px;
        }

        .gym-actions {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
          margin-top: 12px;
        }

        .btn-direction,
        .btn-call {
          padding: 10px;
          border: none;
          border-radius: 8px;
          cursor: pointer;
          font-size: 12px;
          font-weight: bold;
        }

        .btn-direction {
          background: #ff6b35;
          color: white;
        }

        .btn-call {
          background: #f0f0f0;
          color: #ff6b35;
        }

        .facilities {
          background: #fff;
          padding: 20px;
          border-radius: 15px;
        }

        .facilities h2 {
          margin: 0 0 15px 0;
          color: #333;
        }

        .facilities-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 10px;
        }

        .facility-badge {
          background: #fff9f0;
          padding: 12px;
          border-radius: 8px;
          text-align: center;
          font-size: 13px;
          border: 1px solid #ffe0cc;
        }
      `}</style>
    </div>
  );
}

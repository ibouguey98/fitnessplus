import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import TopBar from './components/TopBar';
import BottomNav from './components/BottomNav';
import Auth from './pages/Auth';
import Dashboard from './pages/Dashboard';
import Classes from './pages/Classes';
import QRCodeAccess from './pages/QRCodeAccess';
import Profile from './pages/Profile';
import Payments from './pages/Payments';
import AdminSaaS from './pages/AdminSaaS';
import CoachDashboard from './pages/CoachDashboard';
import Shop from './pages/Shop';
import Community from './pages/Community';
import Onboarding from './pages/Onboarding';
import Explore from './pages/Explore';
import SmartAssistant from './pages/SmartAssistant';
import ProgressTracking from './pages/ProgressTracking';
import Challenges from './pages/Challenges';
import Notifications from './pages/Notifications';
import Nutrition from './pages/Nutrition';
import PartnerGyms from './pages/PartnerGyms';
import ExerciseVideos from './pages/ExerciseVideos';
import Referral from './pages/Referral';
import Badges from './pages/Badges';
import HealthReports from './pages/HealthReports';
import OfflineMode from './pages/OfflineMode';
import './index.css';

const AppContent = () => {
  const location = useLocation();
  const path = location.pathname;
  
  const isAdmin = path.startsWith('/admin');
  const isAuth = path === '/auth' || path === '/onboarding';

  return (
    <div className="app-layout">
      {!isAdmin && !isAuth ? (
        <div className="mobile-wrap">
          <TopBar />
          <div className="content-scroll">
            <Routes>
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/classes" element={<Classes />} />
              <Route path="/shop" element={<Shop />} />
              <Route path="/community" element={<Community />} />
              <Route path="/explore" element={<Explore />} />
              <Route path="/qr" element={<QRCodeAccess />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/progress" element={<ProgressTracking />} />
              <Route path="/challenges" element={<Challenges />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/nutrition" element={<Nutrition />} />
              <Route path="/gyms" element={<PartnerGyms />} />
              <Route path="/videos" element={<ExerciseVideos />} />
              <Route path="/referral" element={<Referral />} />
              <Route path="/badges" element={<Badges />} />
              <Route path="/health-reports" element={<HealthReports />} />
              <Route path="/offline" element={<OfflineMode />} />
              <Route path="/payment" element={<Payments />} />
              <Route path="/coach-dashboard" element={<CoachDashboard />} />
              <Route path="/assistant" element={<SmartAssistant />} />
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="*" element={<Navigate to="/dashboard" replace />} />
            </Routes>
          </div>
          <BottomNav />
        </div>
      ) : (
        <Routes>
          <Route path="/auth" element={<Auth />} />
          <Route path="/onboarding" element={<Onboarding />} />
          <Route path="/admin" element={<AdminSaaS />} />
          <Route path="*" element={<Navigate to="/auth" replace />} />
        </Routes>
      )}
    </div>
  );
};

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App;

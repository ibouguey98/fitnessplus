import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, ShieldCheck, Check, Star, Shield, Trophy } from 'lucide-react';

const Payments = () => {
  const navigate = useNavigate();
  const [method, setMethod] = useState('wave');
  const [activePlan, setActivePlan] = useState('silver');
  const [isProcessing, setIsProcessing] = useState(false);
  const [cart, setCart] = useState(() => {
    const saved = localStorage.getItem('fp_cart');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [tarifs, setTarifs] = useState({
    silver: { price: 25000, features: 'Accès Salle + Cardio' },
    gold: { price: 45000, features: 'Salle + Coach + Piscine' },
    platinum: { price: 75000, features: 'Accès Total 24/7 + SPA' }
  });

  useEffect(() => {
    const saved = localStorage.getItem('fp_tarifs_full');
    if (saved) {
      const parsed = JSON.parse(saved);
      // Convert price strings to numbers if needed
      Object.keys(parsed).forEach(k => {
        if (typeof parsed[k].price === 'string') {
          parsed[k].price = parseInt(parsed[k].price.replace(/\s/g, ''));
        }
      });
      setTarifs(parsed);
    }
  }, []);

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const planPrice = localStorage.getItem('fp_user_plan') === activePlan ? 0 : tarifs[activePlan].price;
  const total = cartTotal + planPrice;

  const handlePayment = () => {
    setIsProcessing(true);
    // Simulate API Call
    setTimeout(() => {
      localStorage.setItem('fp_user_plan', activePlan);
      localStorage.removeItem('fp_cart'); // Clear cart on success
      setIsProcessing(false);
      alert('Paiement Stripe réussi ! Votre commande et votre abonnement sont validés.');
      navigate('/dashboard');
    }, 2500);
  };

  const plans = [
    { id: 'silver', label: 'Silver', icon: <Shield size={18} /> },
    { id: 'gold', label: 'Gold', icon: <Star size={18} /> },
    { id: 'platinum', label: 'Platinum', icon: <Trophy size={18} /> },
  ];

  return (
    <div className="page-container" style={{ background: '#000', display: 'flex', flexDirection: 'column' }}>
      <div className="flex-center mb-10" style={{ justifyContent: 'flex-start', gap: '20px' }}>
        <button className="btn-icon" onClick={() => navigate(-1)}>
          <ArrowLeft size={24} />
        </button>
        <h2 style={{ fontSize: '1.8rem' }}>Paiement Sécurisé</h2>
      </div>

      {/* Cart Summary if items exist */}
      {cart.length > 0 && (
        <div className="glass-panel mb-6 stagger-1" style={{ padding: '20px' }}>
          <h4 style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '12px' }}>VOTRE PANIER</h4>
          {cart.map(item => (
            <div key={item.id} className="flex-between mb-2">
              <span style={{ fontSize: '0.85rem' }}>{item.name} x{item.quantity}</span>
              <span style={{ fontWeight: '700' }}>{(item.price * item.quantity).toLocaleString()} F</span>
            </div>
          ))}
          <div style={{ marginTop: '12px', paddingTop: '12px', borderTop: '1px dotted #222' }} className="flex-between">
            <span style={{ fontWeight: '800' }}>Sous-total</span>
            <span style={{ color: 'var(--primary)', fontWeight: '900' }}>{cartTotal.toLocaleString()} FCFA</span>
          </div>
        </div>
      )}

      {/* Plan Selection */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px' }} className="stagger-1">
        {plans.map(p => (
          <button 
            key={p.id}
            onClick={() => setActivePlan(p.id)}
            className={`pill-tab ${activePlan === p.id ? 'active' : ''}`}
            style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}
          >
            {p.icon} {p.label}
          </button>
        ))}
      </div>

      <div className="glass-panel mb-8 stagger-2" style={{ padding: '24px', textAlign: 'center', border: '1px solid var(--primary-glow)' }}>
        <div style={{ color: 'var(--primary)', fontWeight: '900', fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '0.2em', marginBottom: '12px' }}>TOTAL À PAYER</div>
        <div style={{ fontSize: '2.5rem', fontWeight: '900', color: '#fff' }}>{total.toLocaleString()} <span style={{ fontSize: '1rem', color: 'var(--text-muted)' }}>FCFA</span></div>
      </div>

      <div className="stagger-3">
        <h3 className="mb-6">Choisir un mode de paiement</h3>
        
        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
          {[
            { id: 'stripe', label: 'Carte Bancaire (Stripe)', icon: <div style={{ width: '40px', height: '40px', background: '#6366f1', borderRadius: '10px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', fontSize: '0.6rem', color: '#fff' }}>STRIPE</div> },
            { id: 'wave', label: 'Wave', logo: '/wave.png' },
            { id: 'orange', label: 'Orange Money', logo: '/orange.png' },
          ].map(m => (
            <div key={m.id}>
              <div 
                onClick={() => setMethod(m.id)}
                className="glass-panel"
                style={{ 
                  display: 'flex', alignItems: 'center', gap: '20px', padding: '20px 24px',
                  border: method === m.id ? '2px solid var(--primary)' : '1px solid var(--surface-border)',
                  background: method === m.id ? 'rgba(212, 255, 0, 0.03)' : 'var(--bg-card)',
                  cursor: 'pointer'
                }}
              >
                {m.logo ? (
                  <img src={m.logo} alt={m.label} style={{ width: '40px', height: '40px', borderRadius: '10px', objectFit: 'contain', background: 'white' }} />
                ) : m.icon}
                
                <span style={{ fontWeight: '700', flex: 1, fontSize: '1.1rem' }} translate="no">{m.label}</span>
                
                <div style={{ width: '24px', height: '24px', borderRadius: '50%', border: '2px solid', borderColor: method === m.id ? 'var(--primary)' : '#333', background: method === m.id ? 'var(--primary)' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {method === m.id && <Check size={16} color="#000" strokeWidth={4} />}
                </div>
              </div>

              {/* Stripe Credit Card Form */}
              {method === 'stripe' && m.id === 'stripe' && (
                <div className="stagger-1" style={{ marginTop: '16px', padding: '24px', background: '#0a0a0a', borderRadius: '24px', border: '1px solid #222' }}>
                  <div style={{ marginBottom: '20px' }}>
                    <label style={{ display: 'block', fontSize: '0.7rem', color: '#666', fontWeight: '800', marginBottom: '8px', textTransform: 'uppercase' }}>Numéro de carte</label>
                    <div style={{ background: '#111', border: '1px solid #333', borderRadius: '12px', padding: '16px', display: 'flex', alignItems: 'center', gap: '12px' }}>
                      <div style={{ width: '32px', height: '20px', background: '#222', borderRadius: '4px' }} />
                      <input type="text" placeholder="4242 4242 4242 4242" style={{ background: 'transparent', border: 'none', color: '#fff', fontSize: '1rem', width: '100%', outline: 'none' }} />
                    </div>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.7rem', color: '#666', fontWeight: '800', marginBottom: '8px', textTransform: 'uppercase' }}>Expiration</label>
                      <input type="text" placeholder="MM / YY" style={{ background: '#111', border: '1px solid #333', borderRadius: '12px', padding: '16px', color: '#fff', fontSize: '1rem', width: '100%', outline: 'none' }} />
                    </div>
                    <div>
                      <label style={{ display: 'block', fontSize: '0.7rem', color: '#666', fontWeight: '800', marginBottom: '8px', textTransform: 'uppercase' }}>CVC</label>
                      <input type="text" placeholder="123" style={{ background: '#111', border: '1px solid #333', borderRadius: '12px', padding: '16px', color: '#fff', fontSize: '1rem', width: '100%', outline: 'none' }} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      <div style={{ marginTop: '40px', paddingBottom: '20px' }} className="stagger-3">
        <button 
          className="btn-primary" 
          disabled={isProcessing}
          style={{ height: '70px', boxShadow: '0 10px 30px var(--primary-glow)', position: 'relative' }}
          onClick={handlePayment}
        >
          {isProcessing ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <div className="spinner" /> Traitement...
            </div>
          ) : (
            `Payer ${total.toLocaleString()} FCFA`
          )}
        </button>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', marginTop: '20px', color: 'var(--text-muted)', fontSize: '0.8rem' }}>
          <ShieldCheck size={16} />
          Paiement sécurisé via {method === 'stripe' ? 'Stripe' : method.toUpperCase()}
        </div>
      </div>

      <style>{`
        .spinner {
          width: 20px;
          height: 20px;
          border: 3px solid rgba(0,0,0,0.1);
          border-top-color: #000;
          border-radius: 50%;
          animation: spin 1s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
};

export default Payments;

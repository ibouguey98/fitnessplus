import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Layout, Users, CreditCard, ShoppingBag, 
  Settings, LogOut, Search, Bell, TrendingUp, 
  Activity, UserPlus, FileText, Trash2, Edit,
  Clock, DollarSign, Plus, Check, Shield, Star, Trophy
} from 'lucide-react';

const AdminSaaS = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('Finances');
  
  // États pour la gestion réelle (Persistance via localStorage)
  const [tarifs, setTarifs] = useState({
    silver: { price: '25 000', features: 'Accès Salle + Cardio' },
    gold: { price: '45 000', features: 'Salle + Coach + Piscine' },
    platinum: { price: '75 000', features: 'Accès Total 24/7 + SPA' }
  });
  
  const [coaches, setCoaches] = useState([
    { id: 1, name: 'Coach Eloufit', specialty: 'Lutte / MMA', status: 'Actif', clients: 24 },
    { id: 2, name: 'Coach Amina', specialty: 'Yoga / Fitness', status: 'Actif', clients: 18 },
    { id: 3, name: 'Coach Ousmane', specialty: 'Crossfit', status: 'Inactif', clients: 0 }
  ]);

  const [members, setMembers] = useState([
    { id: 1, name: 'Ibrahima Fall', plan: 'Gold', status: 'Actif', joinDate: '12/03/2026' },
    { id: 2, name: 'Moussa Diop', plan: 'Silver', status: 'Expiré', joinDate: '01/02/2026' },
    { id: 3, name: 'Fatou Sow', plan: 'Platinum', status: 'Actif', joinDate: '20/04/2026' }
  ]);

  const [showAddMember, setShowAddMember] = useState(false);
  const [showAddCoach, setShowAddCoach] = useState(false);
  
  const [newMember, setNewMember] = useState({ name: '', plan: 'Silver', status: 'Actif' });
  const [newCoach, setNewCoach] = useState({ name: '', specialty: 'Fitness' });

  const [horaires, setHoraires] = useState('06:00 - 23:00');
  const [showSaved, setShowSaved] = useState(false);

  useEffect(() => {
    const savedTarifs = localStorage.getItem('fp_tarifs_full');
    if (savedTarifs) setTarifs(JSON.parse(savedTarifs));
    
    const savedCoaches = localStorage.getItem('fp_coaches');
    if (savedCoaches) setCoaches(JSON.parse(savedCoaches));

    const savedMembers = localStorage.getItem('fp_members');
    if (savedMembers) setMembers(JSON.parse(savedMembers));

    const savedHours = localStorage.getItem('fp_hours');
    if (savedHours) setHoraires(savedHours);
  }, []);

  const saveAll = (updatedMembers, updatedCoaches) => {
    if (updatedMembers) localStorage.setItem('fp_members', JSON.stringify(updatedMembers));
    else localStorage.setItem('fp_members', JSON.stringify(members));
    
    if (updatedCoaches) localStorage.setItem('fp_coaches', JSON.stringify(updatedCoaches));
    else localStorage.setItem('fp_coaches', JSON.stringify(coaches));

    localStorage.setItem('fp_tarifs_full', JSON.stringify(tarifs));
    localStorage.setItem('fp_hours', horaires);
    setShowSaved(true);
    setTimeout(() => setShowSaved(false), 3000);
  };

  const handleAddMember = () => {
    if (!newMember.name) return;
    const added = [...members, { id: Date.now(), ...newMember, joinDate: new Date().toLocaleDateString() }];
    setMembers(added);
    saveAll(added, null);
    setShowAddMember(false);
    setNewMember({ name: '', plan: 'Silver', status: 'Actif' });
  };

  const handleAddCoach = () => {
    if (!newCoach.name) return;
    const added = [...coaches, { id: Date.now(), ...newCoach, status: 'Actif', clients: 0 }];
    setCoaches(added);
    saveAll(null, added);
    setShowAddCoach(false);
    setNewCoach({ name: '', specialty: 'Fitness' });
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'Finances':
        return (
          <div className="stagger-1" style={{ width: '100%' }}>
            <div className="flex-between mb-8">
              <div>
                <h2 style={{ fontSize: '1.8rem', color: 'var(--primary)' }}>Tarification & Plans</h2>
                <p className="subtitle">Gérez les prix des abonnements FitnessPlus</p>
              </div>
              <button className="btn-primary" style={{ width: 'auto', padding: '12px 32px' }} onClick={() => saveAll()}>Enregistrer les tarifs</button>
            </div>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '24px', paddingBottom: '40px' }}>
              {[
                { id: 'silver', label: 'SILVER PASS', icon: <Shield size={32} color="#888" />, color: '#888' },
                { id: 'gold', label: 'GOLD PASS', icon: <Star size={32} color="var(--primary)" />, color: 'var(--primary)' },
                { id: 'platinum', label: 'PLATINUM VIP', icon: <Trophy size={32} color="#fff" />, color: '#fff' },
              ].map(plan => (
                <div key={plan.id} className="glass-panel" style={{ textAlign: 'left', padding: '40px', border: activeTab === plan.id ? '2px solid var(--primary)' : '1px solid #111' }}>
                  <div style={{ marginBottom: '24px', display: 'flex', alignItems: 'center', gap: '16px' }}>
                    <div style={{ padding: '12px', background: 'rgba(255,255,255,0.03)', borderRadius: '16px' }}>{plan.icon}</div>
                    <h4 style={{ fontSize: '1.4rem', fontWeight: '900', letterSpacing: '-0.02em' }}>{plan.label}</h4>
                  </div>
                  
                  <div style={{ marginBottom: '32px' }}>
                    <label className="subtitle block mb-2" style={{ fontSize: '0.7rem', fontWeight: '800' }}>PRIX MENSUEL (FCFA)</label>
                    <div className="flex-center" style={{ gap: '12px', background: '#080808', padding: '8px 16px', borderRadius: '16px', border: '1px solid #111' }}>
                      <span style={{ fontSize: '1.5rem', fontWeight: '900', color: plan.color }}>$</span>
                      <input 
                        type="text" 
                        value={tarifs[plan.id].price} 
                        onChange={(e) => setTarifs({...tarifs, [plan.id]: {...tarifs[plan.id], price: e.target.value}})}
                        style={{ background: 'transparent', border: 'none', color: 'white', padding: '12px 0', width: '100%', fontSize: '1.8rem', fontWeight: '900', outline: 'none' }}
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="subtitle block mb-2" style={{ fontSize: '0.7rem', fontWeight: '800' }}>AVANTAGES & SERVICES</label>
                    <textarea 
                      value={tarifs[plan.id].features} 
                      onChange={(e) => setTarifs({...tarifs, [plan.id]: {...tarifs[plan.id], features: e.target.value}})}
                      style={{ background: '#080808', border: '1px solid #111', color: '#666', padding: '16px', borderRadius: '16px', width: '100%', minHeight: '120px', fontSize: '0.9rem', resize: 'none', outline: 'none', lineHeight: '1.6' }}
                      placeholder="Listez les services ici..."
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      
      case 'Utilisateurs':
        return (
          <div className="stagger-1">
            <div className="flex-between mb-8">
              <h3>Gestion des Membres</h3>
              <div className="flex-center gap-4">
                <div className="search-bar" style={{ width: '300px', background: '#0a0a0a', border: '1px solid #111', borderRadius: '12px', padding: '8px 16px' }}>
                  <Search size={18} color="#444" />
                  <input type="text" placeholder="Rechercher..." style={{ background: 'transparent', border: 'none', color: 'white', padding: '8px', outline: 'none' }} />
                </div>
                <button className="btn-primary" style={{ width: 'auto', padding: '12px 24px' }} onClick={() => setShowAddMember(true)}>
                  <Plus size={18} /> Ajouter un Membre
                </button>
              </div>
            </div>
            
            <div className="glass-panel" style={{ padding: '0', overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', minWidth: '800px' }}>
                <thead style={{ background: '#050505', borderBottom: '1px solid #111' }}>
                  <tr>
                    <th style={{ padding: '24px', fontSize: '0.75rem', color: '#444', fontWeight: '900' }}>MEMBRE</th>
                    <th style={{ padding: '24px', fontSize: '0.75rem', color: '#444', fontWeight: '900' }}>PLAN</th>
                    <th style={{ padding: '24px', fontSize: '0.75rem', color: '#444', fontWeight: '900' }}>STATUT</th>
                    <th style={{ padding: '24px', fontSize: '0.75rem', color: '#444', fontWeight: '900' }}>INSCRIPTION</th>
                    <th style={{ padding: '24px', fontSize: '0.75rem', color: '#444', fontWeight: '900' }}>ACTIONS</th>
                  </tr>
                </thead>
                <tbody>
                  {members.map(m => (
                    <tr key={m.id} style={{ borderBottom: '1px solid #080808' }}>
                      <td style={{ padding: '24px', fontWeight: '700', color: '#fff' }}>{m.name}</td>
                      <td style={{ padding: '24px' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                          <Star size={14} color={m.plan === 'Platinum' ? 'var(--primary)' : '#444'} />
                          <span style={{ fontSize: '0.9rem', fontWeight: '600' }}>{m.plan}</span>
                        </div>
                      </td>
                      <td style={{ padding: '24px' }}>
                        <span style={{ padding: '6px 12px', borderRadius: '10px', background: m.status === 'Actif' ? 'rgba(212, 255, 0, 0.05)' : 'rgba(239, 68, 68, 0.05)', color: m.status === 'Actif' ? 'var(--primary)' : '#ef4444', fontSize: '0.75rem', fontWeight: '900' }}>{m.status.toUpperCase()}</span>
                      </td>
                      <td style={{ padding: '24px', color: '#555', fontSize: '0.85rem' }}>{m.joinDate}</td>
                      <td style={{ padding: '24px' }}>
                        <div className="flex-center gap-4" style={{ justifyContent: 'flex-start' }}>
                          <button onClick={() => {
                            const updated = members.filter(mem => mem.id !== m.id);
                            setMembers(updated);
                            saveAll(updated, null);
                          }} style={{ background: 'transparent', border: 'none', color: '#ef4444', cursor: 'pointer' }}>
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );
      
      case 'Coachs':
        return (
          <div className="stagger-1">
            <div className="flex-between mb-8">
              <h3>Gestion de l'Équipe</h3>
              <button className="btn-primary" style={{ width: 'auto', padding: '12px 24px' }} onClick={() => setShowAddCoach(true)}>
                <Plus size={18} /> Ajouter un Coach
              </button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '24px' }}>
              {coaches.map(c => (
                <div key={c.id} className="glass-panel" style={{ padding: '32px', display: 'flex', alignItems: 'center', gap: '24px' }}>
                  <div style={{ width: '70px', height: '70px', background: '#080808', borderRadius: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid #111' }}><UserPlus color="var(--primary)" size={28} /></div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: '900', fontSize: '1.2rem', marginBottom: '4px' }}>{c.name}</div>
                    <p className="subtitle">{c.specialty} • <span style={{ color: 'var(--primary)' }}>{c.clients} clients</span></p>
                  </div>
                  <button onClick={() => {
                    const updated = coaches.filter(co => co.id !== c.id);
                    setCoaches(updated);
                    saveAll(null, updated);
                  }} style={{ background: '#111', border: 'none', color: '#ef4444', cursor: 'pointer', padding: '12px', borderRadius: '12px' }}><Trash2 size={20} /></button>
                </div>
              ))}
            </div>
          </div>
        );

      case 'Tableau de bord':
      default:
        return (
          <div className="stagger-1">
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '24px', marginBottom: '40px' }}>
              {[
                { label: 'Revenus Mensuels', value: '8.7M FCFA', icon: <DollarSign />, trend: '+15%' },
                { label: 'Total Membres', value: '1,240', icon: <Users />, trend: '+8%' },
                { label: 'Taux Rétention', value: '92%', icon: <Activity />, trend: '+2%' },
                { label: 'Nouveaux', value: '84', icon: <Plus />, trend: '-3%' },
              ].map((s, i) => (
                <div key={i} className="glass-panel" style={{ padding: '28px' }}>
                  <div className="flex-between mb-4">
                    <div style={{ color: '#444' }}>{s.icon}</div>
                    <span style={{ fontSize: '0.7rem', fontWeight: '900', color: s.trend.startsWith('+') ? 'var(--primary)' : '#ef4444' }}>{s.trend}</span>
                  </div>
                  <div style={{ fontSize: '2rem', fontWeight: '900' }}>{s.value}</div>
                  <p className="subtitle" style={{ fontSize: '0.75rem', marginTop: '4px' }}>{s.label}</p>
                </div>
              ))}
            </div>
            
            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px' }}>
               <div className="glass-panel" style={{ padding: '40px' }}>
                  <h3 className="mb-8">Graphique de Croissance</h3>
                  <div style={{ height: '200px', display: 'flex', alignItems: 'flex-end', gap: '8px' }}>
                    {[20, 35, 25, 45, 60, 55, 75, 85, 70, 90, 95, 100].map((h, i) => (
                      <div key={i} style={{ flex: 1, background: i === 11 ? 'var(--primary)' : 'rgba(255,255,255,0.03)', height: `${h}%`, borderRadius: '4px' }} />
                    ))}
                  </div>
               </div>
               <div className="glass-panel" style={{ padding: '40px' }}>
                  <h3 className="mb-8">Notifications</h3>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                    <div style={{ padding: '16px', background: '#050505', borderRadius: '12px' }}>
                      <p style={{ fontSize: '0.8rem', fontWeight: '700' }} translate="no">Nouveau paiement Wave</p>
                      <span className="subtitle" style={{ fontSize: '0.6rem' }}>Il y a 2 min</span>
                    </div>
                    <div style={{ padding: '16px', background: '#050505', borderRadius: '12px' }}>
                      <p style={{ fontSize: '0.8rem', fontWeight: '700' }}>Coach Amina connectée</p>
                      <span className="subtitle" style={{ fontSize: '0.6rem' }}>Il y a 15 min</span>
                    </div>
                  </div>
               </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="saas-layout" style={{ background: '#000', height: '100vh', width: '100vw', display: 'flex', overflow: 'hidden' }}>
      {showSaved && (
        <div style={{ position: 'fixed', top: '32px', right: '32px', background: 'var(--primary)', color: '#000', padding: '20px 32px', borderRadius: '16px', fontWeight: '900', zIndex: 10000, display: 'flex', alignItems: 'center', gap: '12px', animation: 'slideUp 0.3s ease', boxShadow: '0 20px 40px rgba(212, 255, 0, 0.4)' }}>
          <Check size={20} strokeWidth={4} /> CONFIGURATION SAUVEGARDÉE !
        </div>
      )}

      {/* Sidebar - FIXED WIDTH, FULL HEIGHT */}
      <div className="saas-sidebar" style={{ width: '280px', flexShrink: 0, borderRight: '1px solid #111', background: '#050505', display: 'flex', flexDirection: 'column', height: '100%' }}>
        <div style={{ padding: '48px 32px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
            <div style={{ width: '44px', height: '44px', background: 'var(--primary)', borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 0 20px var(--primary-glow)' }}>
              <Activity color="#000" size={24} />
            </div>
            <span style={{ fontWeight: '900', fontSize: '1.4rem', letterSpacing: '-0.05em' }}>ADMIN<span style={{ color: 'var(--primary)' }}>HUB</span></span>
          </div>
        </div>
        
        <nav style={{ padding: '0 20px', flex: 1, display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {[
            { id: 'Tableau de bord', icon: <Layout size={20} /> },
            { id: 'Utilisateurs', icon: <Users size={20} /> },
            { id: 'Coachs', icon: <UserPlus size={20} /> },
            { id: 'Finances', icon: <CreditCard size={20} /> },
            { id: 'Planning', icon: <Clock size={20} /> },
            { id: 'Boutique', icon: <ShoppingBag size={20} /> },
          ].map(item => (
            <button 
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              style={{ 
                width: '100%', padding: '16px 20px', borderRadius: '16px', 
                background: activeTab === item.id ? 'var(--primary)' : 'transparent',
                color: activeTab === item.id ? '#000' : '#555',
                border: 'none', textAlign: 'left', display: 'flex', alignItems: 'center', gap: '16px', cursor: 'pointer', fontWeight: '800', transition: 'all 0.3s'
              }}
            >
              {item.icon}
              <span style={{ fontSize: '0.95rem' }}>{item.id}</span>
            </button>
          ))}
        </nav>

        <div style={{ padding: '40px 20px', borderTop: '1px solid #111' }}>
          <button onClick={() => { localStorage.removeItem('fp_user_role'); navigate('/auth'); }} style={{ width: '100%', padding: '16px', borderRadius: '16px', background: 'transparent', border: '1px solid #111', color: '#ef4444', fontWeight: '800', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px' }}>
            <LogOut size={18} /> Déconnexion
          </button>
        </div>
      </div>

      {/* Main Content Area - SCROLLABLE */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
        <header style={{ padding: '32px 48px', borderBottom: '1px solid #111', background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(20px)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h2 style={{ fontSize: '1.6rem', fontWeight: '900' }}>{activeTab}</h2>
          <div style={{ display: 'flex', alignItems: 'center', gap: '32px' }}>
            <div style={{ background: '#0a0a0a', border: '1px solid #111', borderRadius: '14px', display: 'flex', alignItems: 'center', padding: '10px 16px', gap: '12px' }}>
              <Search size={18} color="#333" />
              <input type="text" placeholder="Rechercher..." style={{ background: 'transparent', border: 'none', color: 'white', outline: 'none', fontSize: '0.9rem' }} />
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '16px', padding: '8px 8px 8px 16px', background: '#0a0a0a', borderRadius: '16px', border: '1px solid #111' }}>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontSize: '0.8rem', fontWeight: '900' }}>Directeur</div>
                <div style={{ fontSize: '0.6rem', color: 'var(--primary)' }}>Sénégal Hub</div>
              </div>
              <img src="https://ui-avatars.com/api/?name=Admin&background=d4ff00&color=000" alt="Admin" style={{ width: '36px', height: '36px', borderRadius: '10px' }} />
            </div>
          </div>
        </header>

        <main style={{ padding: '48px', overflowY: 'auto', flex: 1 }}>
          <div style={{ maxWidth: '1400px', margin: '0 auto' }}>
            {renderContent()}
          </div>
        </main>
      </div>

      {/* MODAL AJOUT MEMBRE */}
      {showAddMember && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.9)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 20000 }}>
          <div className="glass-panel" style={{ width: '500px', padding: '40px', border: '1px solid #222' }}>
            <h2 className="mb-8">Nouveau Membre</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <label className="subtitle block mb-2" style={{ fontSize: '0.7rem', fontWeight: '800' }}>NOM COMPLET</label>
                <input type="text" value={newMember.name} onChange={e => setNewMember({...newMember, name: e.target.value})} style={{ width: '100%', background: '#080808', border: '1px solid #111', padding: '16px', borderRadius: '12px', color: 'white', outline: 'none' }} placeholder="Ex: Moussa Diop" />
              </div>
              <div>
                <label className="subtitle block mb-2" style={{ fontSize: '0.7rem', fontWeight: '800' }}>PLAN D'ABONNEMENT</label>
                <select value={newMember.plan} onChange={e => setNewMember({...newMember, plan: e.target.value})} style={{ width: '100%', background: '#080808', border: '1px solid #111', padding: '16px', borderRadius: '12px', color: 'white', outline: 'none' }}>
                  <option value="Silver">Silver Pass</option>
                  <option value="Gold">Gold Pass</option>
                  <option value="Platinum">Platinum VIP</option>
                </select>
              </div>
              <div style={{ display: 'flex', gap: '16px', marginTop: '20px' }}>
                <button className="btn-primary" onClick={handleAddMember}>Créer le profil</button>
                <button onClick={() => setShowAddMember(false)} style={{ flex: 1, background: 'transparent', border: '1px solid #222', color: 'white', borderRadius: '12px', fontWeight: '800', cursor: 'pointer' }}>Annuler</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL AJOUT COACH */}
      {showAddCoach && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.9)', backdropFilter: 'blur(10px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 20000 }}>
          <div className="glass-panel" style={{ width: '500px', padding: '40px', border: '1px solid #222' }}>
            <h2 className="mb-8">Nouveau Coach</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div>
                <label className="subtitle block mb-2" style={{ fontSize: '0.7rem', fontWeight: '800' }}>NOM DU COACH</label>
                <input type="text" value={newCoach.name} onChange={e => setNewCoach({...newCoach, name: e.target.value})} style={{ width: '100%', background: '#080808', border: '1px solid #111', padding: '16px', borderRadius: '12px', color: 'white', outline: 'none' }} placeholder="Ex: Coach Amina" />
              </div>
              <div>
                <label className="subtitle block mb-2" style={{ fontSize: '0.7rem', fontWeight: '800' }}>SPÉCIALITÉ</label>
                <input type="text" value={newCoach.specialty} onChange={e => setNewCoach({...newCoach, specialty: e.target.value})} style={{ width: '100%', background: '#080808', border: '1px solid #111', padding: '16px', borderRadius: '12px', color: 'white', outline: 'none' }} placeholder="Ex: Crossfit, Yoga..." />
              </div>
              <div style={{ display: 'flex', gap: '16px', marginTop: '20px' }}>
                <button className="btn-primary" onClick={handleAddCoach}>Ajouter à l'équipe</button>
                <button onClick={() => setShowAddCoach(false)} style={{ flex: 1, background: 'transparent', border: '1px solid #222', color: 'white', borderRadius: '12px', fontWeight: '800', cursor: 'pointer' }}>Annuler</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <style>{`
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #000; }
        ::-webkit-scrollbar-thumb { background: #1a1a1a; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #222; }
        .stagger-1 { animation: slideUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards; }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>
    </div>
  );
};

export default AdminSaaS;

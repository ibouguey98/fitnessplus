import React from 'react';
import { Users, TrendingUp, DollarSign, ArrowUpRight, Activity, ShieldCheck } from 'lucide-react';

const AdminDashboard = () => {
  return (
    <div className="page-container">
      <div className="flex-between mb-6">
        <div>
          <h1 className="text-gradient" style={{ fontSize: '1.8rem' }}>Espace Admin</h1>
          <p className="subtitle mt-1">Vue d'ensemble FitnessPlus</p>
        </div>
        <div style={{ width: '40px', height: '40px', background: 'var(--primary)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <ShieldCheck color="#170533" />
        </div>
      </div>

      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '24px' }}>
        <div className="glass-panel" style={{ padding: '16px' }}>
          <div className="flex-between mb-2">
            <div style={{ background: 'rgba(251, 191, 36, 0.2)', padding: '8px', borderRadius: '8px' }}>
              <DollarSign size={20} color="var(--primary)" />
            </div>
            <span style={{ color: 'var(--primary)', fontSize: '0.8rem', fontWeight: 'bold' }}>+12%</span>
          </div>
          <p className="subtitle" style={{ fontSize: '0.8rem', marginBottom: '4px' }}>CA du mois</p>
          <div style={{ fontSize: '1.4rem', fontWeight: 'bold' }}>2.4M <span style={{ fontSize: '0.8rem' }}>FCFA</span></div>
        </div>

        <div className="glass-panel" style={{ padding: '16px' }}>
          <div className="flex-between mb-2">
            <div style={{ background: 'rgba(192, 132, 252, 0.2)', padding: '8px', borderRadius: '8px' }}>
              <Users size={20} color="var(--secondary)" />
            </div>
            <span style={{ color: 'var(--primary)', fontSize: '0.8rem', fontWeight: 'bold' }}>+5</span>
          </div>
          <p className="subtitle" style={{ fontSize: '0.8rem', marginBottom: '4px' }}>Membres Actifs</p>
          <div style={{ fontSize: '1.4rem', fontWeight: 'bold' }}>142</div>
        </div>
      </div>

      <div className="glass-panel mb-6" style={{ background: 'linear-gradient(135deg, var(--surface-solid), rgba(251, 191, 36, 0.05))' }}>
        <div className="flex-between mb-4">
          <h3 className="flex-center gap-2"><TrendingUp size={20} color="var(--primary)" /> Ventes Premium (Scale)</h3>
        </div>
        <div className="flex-between mb-2">
          <span className="subtitle">Packs Coaching Vondus</span>
          <span style={{ fontWeight: 'bold' }}>18 ce mois-ci</span>
        </div>
        <div style={{ width: '100%', height: '8px', background: 'var(--bg-darker)', borderRadius: '4px', overflow: 'hidden' }}>
          <div style={{ width: '85%', height: '100%', background: 'var(--primary)', borderRadius: '4px' }}></div>
        </div>
      </div>

      <div className="flex-between mb-4">
        <h3>Activité en temps réel</h3>
        <span style={{ color: 'var(--primary)', fontSize: '0.9rem', cursor: 'pointer' }}>Gérer</span>
      </div>

      <div className="glass-panel" style={{ padding: '0' }}>
        <div className="flex-between" style={{ padding: '16px', borderBottom: '1px solid var(--surface-border)' }}>
          <div className="flex-center gap-3">
            <div style={{ width: '10px', height: '10px', borderRadius: '50%', background: 'var(--primary)', boxShadow: '0 0 10px var(--primary)' }}></div>
            <div>
              <div style={{ fontWeight: 'bold' }}>42 membres en salle</div>
              <p className="subtitle" style={{ fontSize: '0.8rem' }}>Pic d'affluence prévu à 19h</p>
            </div>
          </div>
          <Activity color="var(--text-muted)" />
        </div>
        <div className="flex-between" style={{ padding: '16px' }}>
          <div className="flex-center gap-3">
            <div style={{ width: '40px', height: '40px', borderRadius: '12px', background: 'var(--surface-solid)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold', color: 'var(--secondary)' }}>O</div>
            <div>
              <div style={{ fontWeight: 'bold' }}>Coach Ousmane</div>
              <p className="subtitle" style={{ fontSize: '0.8rem' }}>En cours : Prépa Lutte (15 inscrits)</p>
            </div>
          </div>
        </div>
      </div>

      {/* Giant Spacer and Footer */}
      <div style={{ padding: '100px 0 200px', textAlign: 'center' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', letterSpacing: '1px' }}>
          ADMINISTRATION PANEL v1.0
        </p>
      </div>

    </div>
  );
};

export default AdminDashboard;

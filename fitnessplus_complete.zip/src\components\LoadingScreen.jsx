import React from 'react';
import { Dumbbell } from 'lucide-react';

const LoadingScreen = () => {
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: '#000',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 9999,
      animation: 'fadeOut 0.5s ease-in-out 1.5s forwards'
    }}>
      <div style={{
        width: '80px',
        height: '80px',
        background: 'var(--primary)',
        borderRadius: '24px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: '20px',
        animation: 'pulse 1.5s infinite ease-in-out'
      }}>
        <Dumbbell size={40} color="#000" />
      </div>
      <h2 style={{ color: 'white', letterSpacing: '4px', fontSize: '1.2rem', fontWeight: '900', marginBottom: '8px' }}>FITNESS<span style={{ color: 'var(--primary)' }}>PLUS</span></h2>
      <p style={{ color: 'var(--text-muted)', fontSize: '0.7rem', textTransform: 'uppercase', letterSpacing: '2px', fontWeight: '600' }}>Maintenant ou jamais.</p>
      
      <style>{`
        @keyframes pulse {
          0% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.1); opacity: 0.8; }
          100% { transform: scale(1); opacity: 1; }
        }
        @keyframes fadeOut {
          from { opacity: 1; }
          to { opacity: 0; visibility: hidden; }
        }
      `}</style>
    </div>
  );
};

export default LoadingScreen;

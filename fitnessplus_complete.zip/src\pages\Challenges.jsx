import React, { useState } from 'react';
import { Trophy, Users, TrendingUp } from 'lucide-react';

export default function Challenges() {
  const [challenges] = useState([
    { id: 1, name: '30 jours de défi', participants: 1250, yourRank: 45, yourProgress: 18 },
    { id: 2, name: 'Marathon de cardio', participants: 890, yourRank: 12, yourProgress: 85 },
    { id: 3, name: 'Force extrême', participants: 620, yourRank: 156, yourProgress: 35 },
  ]);

  const [leaderboard] = useState([
    { rank: 1, name: 'Amadou Diallo', points: 4850, badge: '🥇' },
    { rank: 2, name: 'Fatima Ndiaye', points: 4720, badge: '🥈' },
    { rank: 3, name: 'Papa Sow', points: 4680, badge: '🥉' },
    { rank: 4, name: 'Vous', points: 3950, badge: '👤' },
    { rank: 5, name: 'Aïssatou Seck', points: 3820, badge: '👤' },
  ]);

  return (
    <div className="challenges">
      <h1>💪 Défis & Compétitions</h1>

      {/* Active Challenges */}
      <div className="section">
        <h2>Défis actifs</h2>
        {challenges.map(challenge => (
          <div key={challenge.id} className="challenge-card">
            <div className="challenge-header">
              <h3>{challenge.name}</h3>
              <span className="badge-rank">Rang #{challenge.yourRank}</span>
            </div>
            <div className="challenge-info">
              <div className="info-item">
                <Users size={16} />
                <span>{challenge.participants} participants</span>
              </div>
            </div>
            <div className="progress-bar">
              <div 
                className="progress-fill" 
                style={{ width: `${challenge.yourProgress}%` }}
              >
                {challenge.yourProgress}%
              </div>
            </div>
            <button className="btn-participate">Voir les détails</button>
          </div>
        ))}
      </div>

      {/* Leaderboard */}
      <div className="section">
        <h2>🏆 Classement global</h2>
        <div className="leaderboard">
          {leaderboard.map(entry => (
            <div 
              key={entry.rank} 
              className={`leaderboard-entry ${entry.rank <= 3 ? 'top-' + entry.rank : ''} ${entry.name === 'Vous' ? 'current-user' : ''}`}
            >
              <div className="rank">
                <span className="badge">{entry.badge}</span>
              </div>
              <div className="leaderboard-info">
                <h4>{entry.name}</h4>
                <p>{entry.points} points</p>
              </div>
              <div className="leaderboard-rank">#{entry.rank}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Featured Challenge */}
      <div className="featured-challenge">
        <div className="featured-content">
          <h3>🔥 Défi du mois</h3>
          <p>100 pompes en 7 jours</p>
          <button className="btn-join">Rejoindre</button>
        </div>
      </div>

      <style jsx>{`
        .challenges {
          padding: 20px;
          max-width: 500px;
          margin: 0 auto;
        }

        .challenges h1 {
          margin-bottom: 20px;
          color: #ff6b35;
        }

        .section {
          margin-bottom: 30px;
        }

        .section h2 {
          font-size: 16px;
          margin-bottom: 15px;
          color: #333;
        }

        .challenge-card {
          background: #fff;
          border: 1px solid #eee;
          padding: 15px;
          border-radius: 10px;
          margin-bottom: 12px;
        }

        .challenge-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 10px;
        }

        .challenge-header h3 {
          margin: 0;
          font-size: 14px;
          color: #333;
        }

        .badge-rank {
          background: #ff6b35;
          color: white;
          padding: 4px 8px;
          border-radius: 20px;
          font-size: 11px;
          font-weight: bold;
        }

        .challenge-info {
          display: flex;
          gap: 15px;
          margin-bottom: 12px;
          font-size: 12px;
          color: #666;
        }

        .info-item {
          display: flex;
          align-items: center;
          gap: 5px;
        }

        .progress-bar {
          width: 100%;
          height: 20px;
          background: #f0f0f0;
          border-radius: 10px;
          overflow: hidden;
          margin-bottom: 12px;
        }

        .progress-fill {
          height: 100%;
          background: linear-gradient(90deg, #ff6b35, #ffa500);
          display: flex;
          align-items: center;
          justify-content: center;
          color: white;
          font-size: 10px;
          font-weight: bold;
        }

        .btn-participate {
          width: 100%;
          padding: 8px;
          background: #f0f0f0;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-size: 12px;
          color: #ff6b35;
          font-weight: bold;
        }

        .leaderboard {
          background: #fff;
          border-radius: 10px;
          overflow: hidden;
        }

        .leaderboard-entry {
          display: flex;
          align-items: center;
          padding: 12px;
          border-bottom: 1px solid #eee;
          gap: 12px;
        }

        .leaderboard-entry.current-user {
          background: #fff9f0;
        }

        .leaderboard-entry.top-1 { background: #fffacd; }
        .leaderboard-entry.top-2 { background: #f5f5f5; }
        .leaderboard-entry.top-3 { background: #ffe4e1; }

        .rank {
          font-size: 20px;
        }

        .leaderboard-info {
          flex: 1;
        }

        .leaderboard-info h4 {
          margin: 0;
          font-size: 13px;
          color: #333;
        }

        .leaderboard-info p {
          margin: 3px 0 0 0;
          font-size: 11px;
          color: #666;
        }

        .leaderboard-rank {
          font-weight: bold;
          color: #ff6b35;
          font-size: 12px;
        }

        .featured-challenge {
          background: linear-gradient(135deg, #ff6b35, #ffa500);
          color: white;
          padding: 30px 20px;
          border-radius: 15px;
          text-align: center;
        }

        .featured-content h3 {
          margin: 0 0 10px 0;
          font-size: 18px;
        }

        .featured-content p {
          margin: 0 0 15px 0;
          font-size: 14px;
          opacity: 0.9;
        }

        .btn-join {
          background: white;
          color: #ff6b35;
          border: none;
          padding: 10px 25px;
          border-radius: 20px;
          font-weight: bold;
          cursor: pointer;
        }
      `}</style>
    </div>
  );
}

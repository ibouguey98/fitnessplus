import React from 'react';
import { Search, MessageCircle, TrendingUp } from 'lucide-react';

const CoachClients = () => {
  const clients = [
    { id: 1, name: 'Ibrahima Fall', goal: 'Prise de masse', progress: 75, weight: '82kg' },
    { id: 2, name: 'Mamadou Diop', goal: 'Perte de poids', progress: 40, weight: '95kg' },
    { id: 3, name: 'Fatou Sow', goal: 'Endurance', progress: 90, weight: '65kg' },
  ];

  return (
    <div className="page-container">
      <div className="flex-between mb-6">
        <h1>Mes Élèves (Scale)</h1>
      </div>

      <div className="glass-panel flex-center gap-2 mb-6" style={{ padding: '12px' }}>
        <Search size={20} color="var(--text-muted)" />
        <input 
          type="text" 
          placeholder="Rechercher un élève..." 
          style={{ background: 'transparent', border: 'none', color: 'white', outline: 'none', width: '100%' }}
        />
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        {clients.map(c => (
          <div key={c.id} className="glass-panel" style={{ padding: '20px' }}>
            <div className="flex-between mb-4">
              <div className="flex-center gap-3">
                <div style={{ width: '48px', height: '48px', borderRadius: '50%', background: 'var(--surface-solid)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '1.2rem', fontWeight: 'bold' }}>
                  {c.name.charAt(0)}
                </div>
                <div>
                  <h3 style={{ fontSize: '1.1rem', marginBottom: '2px' }}>{c.name}</h3>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Objectif : {c.goal}</div>
                </div>
              </div>
              <button className="btn-icon" style={{ width: '40px', height: '40px', background: 'var(--primary)', color: '#000' }}>
                <MessageCircle size={20} />
              </button>
            </div>
            
            <div className="flex-between mb-2">
              <span className="subtitle" style={{ fontSize: '0.8rem' }}><TrendingUp size={14} style={{ marginRight: '4px' }}/>Progression</span>
              <span style={{ fontWeight: 'bold', fontSize: '0.9rem' }}>{c.progress}%</span>
            </div>
            <div style={{ width: '100%', height: '6px', background: 'var(--surface-solid)', borderRadius: '3px', overflow: 'hidden' }}>
              <div style={{ width: `${c.progress}%`, height: '100%', background: 'var(--primary)', borderRadius: '3px' }}></div>
            </div>
          </div>
        ))}
      </div>
      {/* Footer */}
      <div style={{ padding: '40px 0', textAlign: 'center' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', letterSpacing: '1px' }}>
          CLIENT MANAGEMENT PORTAL
        </p>
      </div>

    </div>
  );
};

export default CoachClients;

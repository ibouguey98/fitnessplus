import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ShoppingBag, Search, Filter, Star, 
  Plus, ChevronRight, ShoppingCart, ArrowLeft
} from 'lucide-react';

const Shop = () => {
  const navigate = useNavigate();
  const [activeCategory, setActiveCategory] = useState('Tous');
  const [cart, setCart] = useState(() => {
    const saved = localStorage.getItem('fp_cart');
    return saved ? JSON.parse(saved) : [];
  });
  const [isCartOpen, setIsCartOpen] = useState(false);

  const categories = ['Tous', 'Suppléments', 'Équipement', 'Vêtements', 'Accessoires'];

  const products = [
    { 
      id: 1, name: 'Whey Isolate Premium', category: 'Suppléments', 
      price: 35000, rating: 4.9, 
      image: 'https://images.unsplash.com/photo-1593095183508-84ad1e66b30c?q=80&w=300&auto=format&fit=crop' 
    },
    { 
      id: 2, name: 'Gants MMA Pro', category: 'Équipement', 
      price: 28000, rating: 4.8, 
      image: 'https://images.unsplash.com/photo-1552674605-db6ffd4facb5?q=80&w=300&auto=format&fit=crop' 
    },
    { 
      id: 3, name: 'T-shirt Elite Performance', category: 'Vêtements', 
      price: 15000, rating: 5.0, 
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=300&auto=format&fit=crop' 
    },
    { 
      id: 4, name: 'Pack Énergie 24h', category: 'Suppléments', 
      price: 12500, rating: 4.7, 
      image: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=300&auto=format&fit=crop' 
    },
  ];

  const addToCart = (product) => {
    const newCart = [...cart];
    const existing = newCart.find(item => item.id === product.id);
    if (existing) {
      existing.quantity += 1;
    } else {
      newCart.push({ ...product, quantity: 1 });
    }
    setCart(newCart);
    localStorage.setItem('fp_cart', JSON.stringify(newCart));
  };

  const removeFromCart = (id) => {
    const newCart = cart.filter(item => item.id !== id);
    setCart(newCart);
    localStorage.setItem('fp_cart', JSON.stringify(newCart));
  };

  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const filteredProducts = activeCategory === 'Tous' 
    ? products 
    : products.filter(p => p.category === activeCategory);

  return (
    <div className="page-container">
      {/* Header */}
      <div className="flex-between mb-8 stagger-1">
        <div>
          <h1 style={{ fontSize: '2rem', marginBottom: '8px' }}>Boutique</h1>
          <p className="subtitle">L'équipement des champions</p>
        </div>
        <div 
          className="btn-icon" 
          style={{ position: 'relative', background: cart.length > 0 ? 'var(--primary)' : 'var(--bg-card)', color: cart.length > 0 ? '#000' : '#fff' }}
          onClick={() => setIsCartOpen(true)}
        >
          <ShoppingCart size={24} />
          {cart.length > 0 && (
            <div style={{ position: 'absolute', top: '-5px', right: '-5px', width: '20px', height: '20px', background: '#fff', borderRadius: '50%', color: '#000', fontSize: '0.7rem', fontWeight: '900', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '2px solid #000' }}>
              {cart.reduce((sum, item) => sum + item.quantity, 0)}
            </div>
          )}
        </div>
      </div>

      {/* Cart Drawer */}
      {isCartOpen && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', zIndex: 2000, display: 'flex', justifyContent: 'flex-end' }}>
          <div className="stagger-1" style={{ width: '100%', maxWidth: '400px', background: '#080808', height: '100%', padding: '40px 24px', display: 'flex', flexDirection: 'column' }}>
            <div className="flex-between mb-10">
              <h2 style={{ fontSize: '1.8rem' }}>Votre Panier</h2>
              <button className="btn-icon" onClick={() => setIsCartOpen(false)}><ArrowLeft size={24} /></button>
            </div>

            <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '20px' }} className="no-scrollbar">
              {cart.length === 0 ? (
                <div style={{ textAlign: 'center', marginTop: '100px', color: 'var(--text-muted)' }}>
                  <ShoppingBag size={60} style={{ opacity: 0.1, marginBottom: '20px' }} />
                  <p>Votre panier est vide</p>
                </div>
              ) : (
                cart.map(item => (
                  <div key={item.id} className="glass-panel" style={{ padding: '16px', display: 'flex', gap: '16px' }}>
                    <img src={item.image} style={{ width: '60px', height: '60px', borderRadius: '12px', objectFit: 'cover' }} />
                    <div style={{ flex: 1 }}>
                      <h4 style={{ fontSize: '0.9rem', marginBottom: '4px' }}>{item.name}</h4>
                      <p style={{ color: 'var(--primary)', fontWeight: '900', fontSize: '0.8rem' }}>{item.price.toLocaleString()} FCFA x {item.quantity}</p>
                    </div>
                    <button onClick={() => removeFromCart(item.id)} style={{ background: 'transparent', border: 'none', color: '#ef4444' }}>Retirer</button>
                  </div>
                ))
              )}
            </div>

            {cart.length > 0 && (
              <div style={{ paddingTop: '24px', borderTop: '1px solid #111' }}>
                <div className="flex-between mb-6">
                  <span className="subtitle">Total</span>
                  <span style={{ fontSize: '1.5rem', fontWeight: '900' }}>{total.toLocaleString()} FCFA</span>
                </div>
                <button 
                  className="btn-primary" 
                  onClick={() => navigate('/payment')}
                >
                  Commander
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Categories */}
      <div style={{ display: 'flex', gap: '12px', overflowX: 'auto', paddingBottom: '16px', marginBottom: '32px' }} className="no-scrollbar stagger-1">
        {categories.map(cat => (
          <button 
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`pill-tab ${activeCategory === cat ? 'active' : ''}`}
            style={{ padding: '12px 24px', fontSize: '0.8rem' }}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }} className="stagger-2">
        {filteredProducts.map((p) => (
          <div key={p.id} className="glass-panel" style={{ padding: '12px', display: 'flex', flexDirection: 'column' }}>
            <div style={{ width: '100%', aspectRatio: '1/1', borderRadius: '16px', overflow: 'hidden', marginBottom: '16px', position: 'relative' }}>
              <img src={p.image} alt={p.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              <button 
                style={{ 
                  position: 'absolute', bottom: '12px', right: '12px', 
                  width: '36px', height: '36px', borderRadius: '10px', 
                  background: 'var(--primary)', border: 'none', color: '#000',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer'
                }}
                onClick={() => addToCart(p)}
              >
                <Plus size={20} strokeWidth={3} />
              </button>
            </div>
            
            <div style={{ flex: 1 }}>
              <div className="flex-between mb-1">
                <span style={{ fontSize: '0.65rem', fontWeight: '800', color: 'var(--text-muted)' }}>{p.category.toUpperCase()}</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px', fontSize: '0.7rem', fontWeight: '900' }}>
                  <Star size={10} fill="var(--primary)" color="var(--primary)" /> {p.rating}
                </div>
              </div>
              <h4 style={{ fontSize: '0.95rem', marginBottom: '8px', lineHeight: '1.2', height: '2.4em', overflow: 'hidden' }}>{p.name}</h4>
              <div style={{ fontSize: '1.1rem', fontWeight: '900', color: '#fff' }}>{p.price.toLocaleString()} FCFA</div>
            </div>
          </div>
        ))}
      </div>

      {/* Featured Banner */}
      <div className="glass-panel mt-12 stagger-3" style={{ background: 'var(--primary)', color: '#000', padding: '32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', overflow: 'hidden', position: 'relative' }}>
        <div style={{ zIndex: 1 }}>
          <h3 style={{ color: '#000', fontSize: '1.5rem', marginBottom: '8px' }}>-20% SUR LE PACK PRO</h3>
          <p style={{ fontWeight: '700', fontSize: '0.8rem', opacity: 0.8, marginBottom: '20px' }}>Réservé aux membres Premium FitnessPlus</p>
          <button style={{ background: '#000', color: '#fff', border: 'none', padding: '12px 24px', borderRadius: '12px', fontWeight: '900', fontSize: '0.8rem', cursor: 'pointer' }}>PROFITER</button>
        </div>
        <div style={{ position: 'absolute', right: '-20px', top: '50%', transform: 'translateY(-50%)', opacity: 0.2 }}>
          <ShoppingBag size={120} color="#000" />
        </div>
      </div>
    </div>
  );
};

export default Shop;

import React from 'react';
import { Calendar as CalendarIcon, Clock, MapPin, Users } from 'lucide-react';

const CoachPlanning = () => {
  const classes = [
    { id: 1, time: '18:00', name: 'Prépa Lutte', room: 'Salle B', attendees: 15, duration: '1h' },
    { id: 2, time: '19:30', name: 'Cardio Plage', room: 'Extérieur', attendees: 24, duration: '45m' },
    { id: 3, time: '08:00', name: 'Cross-Training', room: 'Salle A', attendees: 12, duration: '1h', isTomorrow: true },
  ];

  return (
    <div className="page-container">
      <div className="flex-between mb-6">
        <h1>Mon Planning</h1>
        <button className="btn-icon" style={{ width: '40px', height: '40px' }}><CalendarIcon size={20} /></button>
      </div>

      <h3 className="mb-4" style={{ color: 'var(--primary)' }}>Aujourd'hui</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '32px' }}>
        {classes.filter(c => !c.isTomorrow).map(c => (
          <div key={c.id} className="glass-panel flex-between" style={{ padding: '16px', borderLeft: '4px solid var(--primary)' }}>
            <div>
              <div className="flex-center gap-2 mb-1">
                <Clock size={16} color="var(--text-muted)" />
                <span style={{ fontWeight: 'bold', fontSize: '1.2rem' }}>{c.time}</span>
              </div>
              <h3 style={{ fontSize: '1.1rem', marginBottom: '4px' }}>{c.name}</h3>
              <div className="flex-center gap-3 subtitle" style={{ fontSize: '0.8rem' }}>
                <span className="flex-center gap-1"><MapPin size={12}/> {c.room}</span>
                <span className="flex-center gap-1"><Users size={12}/> {c.attendees} inscrits</span>
              </div>
            </div>
            <button className="btn-primary" style={{ width: 'auto', padding: '8px 16px', fontSize: '0.9rem' }}>Démarrer</button>
          </div>
        ))}
      </div>

      <h3 className="mb-4" style={{ color: 'var(--text-muted)' }}>Demain</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {classes.filter(c => c.isTomorrow).map(c => (
          <div key={c.id} className="glass-panel flex-between" style={{ padding: '16px', opacity: 0.7 }}>
            <div>
              <div className="flex-center gap-2 mb-1">
                <Clock size={16} color="var(--text-muted)" />
                <span style={{ fontWeight: 'bold', fontSize: '1.2rem' }}>{c.time}</span>
              </div>
              <h3 style={{ fontSize: '1.1rem', marginBottom: '4px' }}>{c.name}</h3>
            </div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div style={{ padding: '40px 0', textAlign: 'center' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', letterSpacing: '1px' }}>
          PLANNING PORTAL v1.0
        </p>
      </div>

    </div>
  );
};

export default CoachPlanning;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  TrendingUp, Award, Activity, Heart, 
  ArrowRight, Calculator, Trophy, Users,
  CheckCircle, Zap, Star, Shield
} from 'lucide-react';

const Progress = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState(() => {
    const saved = localStorage.getItem('fp_user_data');
    return saved ? JSON.parse(saved) : { weight: 75, height: 175, goal: 'gain' };
  });

  const [bmi, setBmi] = useState(0);

  useEffect(() => {
    if (userData.weight && userData.height) {
      const h = userData.height / 100;
      setBmi((userData.weight / (h * h)).toFixed(1));
    }
  }, [userData]);

  const badges = [
    { id: 1, title: "Premier Pas", desc: "Premier entraînement terminé", icon: <CheckCircle size={24} />, earned: true, color: '#d4ff00' },
    { id: 2, title: "Lève-tôt", desc: "S'entraîner avant 8h", icon: <Zap size={24} />, earned: true, color: '#6366f1' },
    { id: 3, title: "Fidèle", desc: "7 jours de suite", icon: <Heart size={24} />, earned: false, color: '#f43f5e' },
    { id: 4, title: "Hercule", desc: "100kg au développé couché", icon: <Shield size={24} />, earned: false, color: '#fbbf24' },
  ];

  const stats = [
    { label: 'Calories', value: '1,240', unit: 'kcal', trend: '+12%', icon: <Activity size={20} /> },
    { label: 'Minutes', value: '450', unit: 'min', trend: '+5%', icon: <Zap size={20} /> },
    { label: 'Séances', value: '12', unit: 'sessions', trend: 'stable', icon: <Trophy size={20} /> },
  ];

  return (
    <div className="page-container" style={{ background: '#000' }}>
      <div className="flex-between mb-8 stagger-1">
        <div>
          <h2 style={{ fontSize: '2rem', marginBottom: '4px' }}>Votre Progression</h2>
          <p className="subtitle">Suivez vos exploits à Pikine</p>
        </div>
        <div style={{ width: '50px', height: '50px', background: 'var(--primary)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#000' }}>
          <TrendingUp size={24} />
        </div>
      </div>

      {/* Health Report Card */}
      <div className="glass-panel mb-8 stagger-1" style={{ padding: '24px', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: '-20px', right: '-20px', color: 'rgba(255,255,255,0.03)' }}>
          <Activity size={150} />
        </div>
        
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div className="flex-between mb-6">
            <h3 style={{ fontSize: '1.2rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Heart size={20} color="var(--danger)" /> Rapport de Santé
            </h3>
            <div style={{ padding: '6px 12px', background: 'rgba(255,255,255,0.05)', borderRadius: '20px', fontSize: '0.7rem', fontWeight: '800' }}>MAI 2026</div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
            <div style={{ background: 'rgba(255,255,255,0.03)', padding: '20px', borderRadius: '24px', border: '1px solid rgba(255,255,255,0.05)' }}>
              <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginBottom: '8px', textTransform: 'uppercase' }}>IMC Actuel</div>
              <div style={{ fontSize: '2rem', fontWeight: '900', color: 'var(--primary)' }}>{bmi}</div>
              <div style={{ fontSize: '0.75rem', marginTop: '4px', color: bmi < 25 ? '#4ade80' : '#fbbf24' }}>
                {bmi < 18.5 ? 'Insuffisance' : bmi < 25 ? 'Poids Idéal' : 'Surpoids'}
              </div>
            </div>
            <div style={{ background: 'rgba(255,255,255,0.03)', padding: '20px', borderRadius: '24px', border: '1px solid rgba(255,255,255,0.05)' }}>
              <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginBottom: '8px', textTransform: 'uppercase' }}>Objectif</div>
              <div style={{ fontSize: '1.2rem', fontWeight: '900' }}>{userData.goal === 'gain' ? '+5kg Muscle' : 'Perte de Poids'}</div>
              <div style={{ width: '100%', height: '6px', background: '#222', borderRadius: '3px', marginTop: '12px' }}>
                <div style={{ width: '65%', height: '100%', background: 'var(--primary)', borderRadius: '3px', boxShadow: '0 0 10px var(--primary-glow)' }} />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px', marginBottom: '32px' }} className="stagger-2">
        {stats.map((stat, i) => (
          <div key={i} className="glass-panel" style={{ padding: '16px', textAlign: 'center', background: 'rgba(255,255,255,0.02)' }}>
            <div style={{ color: 'var(--text-muted)', marginBottom: '8px', display: 'flex', justifyContent: 'center' }}>{stat.icon}</div>
            <div style={{ fontSize: '1.1rem', fontWeight: '900' }}>{stat.value}</div>
            <div style={{ fontSize: '0.6rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>{stat.unit}</div>
            <div style={{ fontSize: '0.6rem', color: '#4ade80', marginTop: '4px' }}>{stat.trend}</div>
          </div>
        ))}
      </div>

      {/* Badges Section */}
      <div className="mb-8 stagger-3">
        <h3 className="mb-6" style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <Award size={22} color="var(--primary)" /> Badges & Récompenses
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
          {badges.map(badge => (
            <div 
              key={badge.id} 
              className="glass-panel" 
              style={{ 
                padding: '20px', 
                opacity: badge.earned ? 1 : 0.4,
                filter: badge.earned ? 'none' : 'grayscale(1)',
                display: 'flex',
                alignItems: 'center',
                gap: '12px'
              }}
            >
              <div style={{ width: '44px', height: '44px', background: 'rgba(255,255,255,0.05)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: badge.color }}>
                {badge.icon}
              </div>
              <div style={{ flex: 1 }}>
                <h4 style={{ fontSize: '0.85rem', marginBottom: '2px' }}>{badge.title}</h4>
                <p style={{ fontSize: '0.65rem', color: 'var(--text-muted)' }}>{badge.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Referral Program */}
      <div className="glass-panel stagger-3" style={{ padding: '24px', background: 'linear-gradient(135deg, #111 0%, #000 100%)', border: '1px solid var(--primary-glow)' }}>
        <h3 style={{ fontSize: '1.1rem', marginBottom: '8px' }}>Parrainez un ami !</h3>
        <p className="subtitle" style={{ fontSize: '0.8rem', marginBottom: '20px' }}>Gagnez 1 mois gratuit pour chaque ami parrainé à FitnessPlus Pikine.</p>
        
        <div style={{ background: 'rgba(212, 255, 0, 0.05)', border: '1px dashed var(--primary)', borderRadius: '16px', padding: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <code style={{ fontSize: '1.2rem', fontWeight: '900', color: 'var(--primary)', letterSpacing: '2px' }}>PLUS-7890</code>
          <button style={{ background: 'var(--primary)', border: 'none', padding: '8px 16px', borderRadius: '10px', fontSize: '0.7rem', fontWeight: '900', cursor: 'pointer' }}>COPIER</button>
        </div>
      </div>

      <style>{`
        .stagger-1 { animation: slideUp 0.6s ease-out forwards; }
        .stagger-2 { opacity: 0; animation: slideUp 0.6s ease-out 0.2s forwards; }
        .stagger-3 { opacity: 0; animation: slideUp 0.6s ease-out 0.4s forwards; }
      `}</style>
    </div>
  );
};

export default Progress;

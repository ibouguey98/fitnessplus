import React, { useState, useEffect } from 'react';
import { Download, Wifi, WifiOff, CheckCircle } from 'lucide-react';

export default function OfflineMode() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [downloads, setDownloads] = useState({
    programs: false,
    videos: false,
    workouts: false,
  });

  const [storageUsage, setStorageUsage] = useState({
    used: 145,
    available: 500,
  });

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const toggleDownload = (item) => {
    setDownloads(prev => ({
      ...prev,
      [item]: !prev[item]
    }));
  };

  const downloadAllPrograms = () => {
    setStorageUsage(prev => ({
      ...prev,
      used: prev.used + 50
    }));
    toggleDownload('programs');
  };

  return (
    <div className="offline-mode">
      <h1>📱 Mode Hors Ligne</h1>

      {/* Connection Status */}
      <div className={`status-card ${isOnline ? 'online' : 'offline'}`}>
        {isOnline ? (
          <>
            <Wifi size={24} color="#4CAF50" />
            <h2>Connecté</h2>
            <p>Vous êtes en ligne. Les données se synchronisent automatiquement.</p>
          </>
        ) : (
          <>
            <WifiOff size={24} color="#f44336" />
            <h2>Hors ligne</h2>
            <p>Accès limité aux contenus téléchargés</p>
          </>
        )}
      </div>

      {/* Download Options */}
      <div className="download-section">
        <h2>📥 Contenus téléchargeables</h2>

        <div className="download-item">
          <div className="download-header">
            <h3>Mes programmes</h3>
            {downloads.programs && <CheckCircle size={20} color="#4CAF50" />}
          </div>
          <p>Accédez à tous vos programmes d\'entraînement sans internet</p>
          <button 
            className="btn-download"
            onClick={downloadAllPrograms}
          >
            <Download size={16} />
            {downloads.programs ? 'Téléchargé' : 'Télécharger'}
          </button>
        </div>

        <div className="download-item">
          <div className="download-header">
            <h3>Vidéos d\'exercices</h3>
            {downloads.videos && <CheckCircle size={20} color="#4CAF50" />}
          </div>
          <p>Tutoriels vidéo disponibles hors ligne</p>
          <button 
            className="btn-download"
            onClick={() => toggleDownload('videos')}
          >
            <Download size={16} />
            {downloads.videos ? 'Téléchargé' : 'Télécharger'}
          </button>
        </div>

        <div className="download-item">
          <div className="download-header">
            <h3>Historique d\'entraînement</h3>
            {downloads.workouts && <CheckCircle size={20} color="#4CAF50" />}
          </div>
          <p>Vos statistiques et historique</p>
          <button 
            className="btn-download"
            onClick={() => toggleDownload('workouts')}
          >
            <Download size={16} />
            {downloads.workouts ? 'Téléchargé' : 'Télécharger'}
          </button>
        </div>
      </div>

      {/* Storage Usage */}
      <div className="storage-section">
        <h2>💾 Stockage local</h2>
        <div className="storage-info">
          <span className="storage-used">{storageUsage.used}MB</span>
          <span className="storage-total">/ {storageUsage.available}MB</span>
        </div>
        <div className="storage-bar">
          <div 
            className="storage-fill" 
            style={{ width: `${(storageUsage.used / storageUsage.available) * 100}%` }}
          ></div>
        </div>
        <p className="storage-text">
          {storageUsage.available - storageUsage.used}MB disponible
        </p>
      </div>

      {/* Available Offline Features */}
      <div className="features-section">
        <h2>✅ Fonctionnalités disponibles hors ligne</h2>
        <div className="features-list">
          <div className="feature">✓ Consulter vos programmes</div>
          <div className="feature">✓ Suivre vos entraînements</div>
          <div className="feature">✓ Voir l\'historique</div>
          <div className="feature">✓ Utiliser le chronomètre</div>
          <div className="feature">✓ Lire les vidéos téléchargées</div>
          <div className="feature">✓ Synchronisation automatique à la reconnexion</div>
        </div>
      </div>

      {/* Sync Info */}
      <div className="sync-info">
        <h3>🔄 Synchronisation</h3>
        <p>
          {isOnline 
            ? 'Vos données se synchronisent en temps réel.' 
            : 'En attente de connexion pour la synchronisation...'}
        </p>
        <button className="btn-sync">Synchroniser maintenant</button>
      </div>

      <style jsx>{`
        .offline-mode {
          padding: 20px;
          max-width: 500px;
          margin: 0 auto;
        }

        .offline-mode h1 {
          margin-bottom: 20px;
          color: #ff6b35;
        }

        .status-card {
          padding: 20px;
          border-radius: 12px;
          text-align: center;
          margin-bottom: 20px;
        }

        .status-card.online {
          background: #e8f5e9;
          border: 2px solid #4CAF50;
        }

        .status-card.offline {
          background: #ffebee;
          border: 2px solid #f44336;
        }

        .status-card h2 {
          margin: 10px 0 5px 0;
          color: #333;
        }

        .status-card p {
          margin: 0;
          font-size: 12px;
          color: #666;
        }

        .download-section {
          margin-bottom: 30px;
        }

        .download-section h2 {
          margin-bottom: 15px;
          color: #333;
        }

        .download-item {
          background: white;
          border: 1px solid #eee;
          padding: 15px;
          border-radius: 10px;
          margin-bottom: 12px;
        }

        .download-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 8px;
        }

        .download-header h3 {
          margin: 0;
          font-size: 14px;
          color: #333;
        }

        .download-item p {
          margin: 0 0 10px 0;
          font-size: 12px;
          color: #666;
        }

        .btn-download {
          width: 100%;
          padding: 10px;
          background: #ff6b35;
          color: white;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-weight: bold;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          font-size: 12px;
        }

        .storage-section {
          background: #f9f9f9;
          padding: 15px;
          border-radius: 10px;
          margin-bottom: 20px;
        }

        .storage-section h2 {
          margin: 0 0 12px 0;
          color: #333;
        }

        .storage-info {
          display: flex;
          gap: 5px;
          margin-bottom: 10px;
        }

        .storage-used {
          font-size: 18px;
          font-weight: bold;
          color: #ff6b35;
        }

        .storage-total {
          font-size: 14px;
          color: #666;
        }

        .storage-bar {
          width: 100%;
          height: 12px;
          background: #e0e0e0;
          border-radius: 6px;
          overflow: hidden;
          margin-bottom: 8px;
        }

        .storage-fill {
          height: 100%;
          background: linear-gradient(90deg, #ff6b35, #ffa500);
        }

        .storage-text {
          margin: 0;
          font-size: 11px;
          color: #999;
        }

        .features-section {
          background: #e8f5e9;
          padding: 15px;
          border-radius: 10px;
          margin-bottom: 20px;
        }

        .features-section h2 {
          margin: 0 0 12px 0;
          color: #2e7d32;
        }

        .features-list {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .feature {
          font-size: 12px;
          color: #1b5e20;
        }

        .sync-info {
          background: white;
          border: 2px solid #ff6b35;
          padding: 15px;
          border-radius: 10px;
          text-align: center;
        }

        .sync-info h3 {
          margin: 0 0 8px 0;
          color: #ff6b35;
        }

        .sync-info p {
          margin: 0 0 12px 0;
          font-size: 12px;
          color: #666;
        }

        .btn-sync {
          width: 100%;
          padding: 10px;
          background: #ff6b35;
          color: white;
          border: none;
          border-radius: 6px;
          cursor: pointer;
          font-weight: bold;
          font-size: 12px;
        }
      `}</style>
    </div>
  );
}

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  MapPin, Play, Search, ArrowLeft, 
  Dumbbell, Star, Info, Navigation, ChevronRight
} from 'lucide-react';

const Explore = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('videos');

  const salles = [
    { id: 1, name: 'FitnessPlus Pikine', dist: '0.8 km', rating: 4.9, img: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=300&auto=format&fit=crop' },
    { id: 2, name: 'FitnessPlus Plateau', dist: '12 km', rating: 4.8, img: 'https://images.unsplash.com/photo-1571902943202-507ec2618e8f?q=80&w=300&auto=format&fit=crop' },
  ];

  const videos = [
    { id: 1, title: 'Squat Parfait', duration: '3:45', coach: 'Coach Moussa', views: '2.4k', img: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?q=80&w=400&auto=format&fit=crop' },
    { id: 2, title: 'Abdos en 5min', duration: '5:12', coach: 'Coach Awa', views: '1.8k', img: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=400&auto=format&fit=crop' },
    { id: 3, title: 'Technique Bench', duration: '4:20', coach: 'Coach Omar', views: '950', img: 'https://images.unsplash.com/photo-1534367507873-d2b7e24959ac?q=80&w=400&auto=format&fit=crop' },
  ];

  return (
    <div className="page-container" style={{ background: '#000' }}>
      <div className="flex-between mb-8 stagger-1">
        <h2 style={{ fontSize: '2rem' }}>Explorer</h2>
        <div className="btn-icon">
          <Search size={24} />
        </div>
      </div>

      {/* Tab Switcher */}
      <div style={{ display: 'flex', gap: '10px', marginBottom: '24px' }} className="stagger-1">
        <button 
          onClick={() => setActiveTab('videos')}
          className={`pill-tab ${activeTab === 'videos' ? 'active' : ''}`}
          style={{ flex: 1 }}
        >
          Tutoriels Vidéo
        </button>
        <button 
          onClick={() => setActiveTab('map')}
          className={`pill-tab ${activeTab === 'map' ? 'active' : ''}`}
          style={{ flex: 1 }}
        >
          Salles & GPS
        </button>
      </div>

      {activeTab === 'videos' ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }} className="stagger-2">
          {videos.map(vid => (
            <div key={vid.id} className="glass-panel" style={{ padding: '0', overflow: 'hidden' }}>
              <div style={{ position: 'relative', height: '180px' }}>
                <img src={vid.img} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <div style={{ width: '60px', height: '60px', background: 'var(--primary)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#000', boxShadow: '0 0 30px var(--primary-glow)' }}>
                    <Play size={30} fill="#000" />
                  </div>
                </div>
                <div style={{ position: 'absolute', bottom: '12px', right: '12px', background: 'rgba(0,0,0,0.8)', padding: '4px 8px', borderRadius: '6px', fontSize: '0.7rem', fontWeight: 'bold' }}>
                  {vid.duration}
                </div>
              </div>
              <div style={{ padding: '20px' }}>
                <div className="flex-between mb-2">
                  <h4 style={{ fontSize: '1.1rem' }}>{vid.title}</h4>
                  <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>{vid.views} vues</div>
                </div>
                <p className="subtitle" style={{ fontSize: '0.8rem' }}>Avec {vid.coach}</p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }} className="stagger-2">
          {/* Mock Map */}
          <div className="glass-panel" style={{ height: '250px', background: '#111', display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative', overflow: 'hidden' }}>
            <img src="https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?q=80&w=1000&auto=format&fit=crop" style={{ width: '100%', height: '100%', objectFit: 'cover', opacity: 0.5 }} />
            <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', color: 'var(--primary)', animation: 'pulse 2s infinite' }}>
              <MapPin size={48} fill="var(--primary-glow)" />
            </div>
            <div style={{ position: 'absolute', bottom: '20px', left: '20px', right: '20px' }}>
              <button className="btn-primary" style={{ height: '50px', fontSize: '0.9rem' }}>
                <Navigation size={18} /> Ouvrir dans Google Maps
              </button>
            </div>
          </div>

          <h3 className="mt-4">SALLES À PROXIMITÉ</h3>
          {salles.map(salle => (
            <div key={salle.id} className="glass-panel" style={{ display: 'flex', alignItems: 'center', gap: '16px', padding: '16px' }}>
              <img src={salle.img} style={{ width: '80px', height: '80px', borderRadius: '16px', objectFit: 'cover' }} />
              <div style={{ flex: 1 }}>
                <h4 style={{ fontSize: '1rem', marginBottom: '4px' }}>{salle.name}</h4>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><MapPin size={14} /> {salle.dist}</span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><Star size={14} color="var(--primary)" fill="var(--primary)" /> {salle.rating}</span>
                </div>
              </div>
              <div className="btn-icon" style={{ width: '40px', height: '40px' }}>
                <ChevronRight size={20} />
              </div>
            </div>
          ))}
        </div>
      )}

      <style>{`
        @keyframes pulse {
          0% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
          50% { transform: translate(-50%, -50%) scale(1.2); opacity: 0.7; }
          100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
        }
        .stagger-1 { animation: slideUp 0.6s ease-out forwards; }
        .stagger-2 { opacity: 0; animation: slideUp 0.6s ease-out 0.2s forwards; }
      `}</style>
    </div>
  );
};

export default Explore;

import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Menu, X, ShoppingBag, Users, Bot, Settings, ChevronLeft, Layout, Bell, Sparkles } from 'lucide-react';

const TopBar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const [role, setRole] = useState('client');

  useEffect(() => {
    const savedRole = localStorage.getItem('fp_user_role');
    if (savedRole) setRole(savedRole);
  }, [location.pathname]);

  const clientMenu = [
    { icon: <ShoppingBag />, label: 'Boutique', path: '/shop' },
    { icon: <Users />, label: 'Communauté', path: '/community' },
    { icon: <Bot />, label: 'Assistant IA', path: '/assistant' },
    { icon: <Settings />, label: 'Mon Profil', path: '/profile' },
    { icon: <X />, label: 'Déconnexion', path: '/auth' },
  ];

  const coachMenu = [
    { icon: <Layout />, label: 'Tableau de bord', path: '/coach-dashboard' },
    { icon: <Users />, label: 'Mes Clients', path: '/coach/clients' },
    { icon: <Settings />, label: 'Mon Profil', path: '/profile' },
    { icon: <X />, label: 'Déconnexion', path: '/auth' },
  ];

  const menuItems = role === 'coach' ? coachMenu : clientMenu;

  const handleNav = (path) => {
    setIsOpen(false);
    navigate(path);
  };

  return (
    <>
      <div style={{ 
        position: 'fixed', 
        top: 0, left: 0, right: 0, 
        paddingTop: 'env(safe-area-inset-top, 20px)',
        height: 'calc(80px + env(safe-area-inset-top, 0px))', 
        paddingLeft: '24px', paddingRight: '24px',
        display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', 
        paddingBottom: '16px', zIndex: 1000, 
        background: 'rgba(0,0,0,0.85)', backdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--surface-border)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <button onClick={() => navigate(-1)} style={{ background: '#111', border: 'none', color: 'white', width: '32px', height: '32px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <ChevronLeft size={20} />
          </button>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ fontSize: '1.2rem', fontWeight: '900', letterSpacing: '-0.05em' }}>
              FITNESS<span style={{ color: 'var(--primary)' }}>PLUS</span>
            </div>
            {role !== 'client' && (
              <span style={{ fontSize: '0.6rem', color: 'var(--primary)', fontWeight: '900', textTransform: 'uppercase', letterSpacing: '0.1em' }} translate="no">
                Mode {role}
              </span>
            )}
          </div>
        </div>
        <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
          <button onClick={() => navigate('/assistant')} style={{ background: 'transparent', border: 'none', color: 'var(--primary)', cursor: 'pointer' }}>
            <Sparkles size={24} fill="currentColor" style={{ filter: 'drop-shadow(0 0 8px var(--primary-glow))' }} />
          </button>
          <button onClick={() => setIsOpen(true)} style={{ background: 'transparent', border: 'none', color: 'white', cursor: 'pointer' }}>
            <Menu size={28} />
          </button>
        </div>
      </div>

      {isOpen && (
        <div style={{ 
          position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, 
          background: 'rgba(0,0,0,0.98)', backdropFilter: 'blur(30px)', 
          zIndex: 2000, display: 'flex', flexDirection: 'column',
          borderRadius: '28px', animation: 'fadeIn 0.3s ease'
        }}>
          <div style={{ padding: '40px 24px', display: 'flex', justifyContent: 'flex-end' }}>
            <button onClick={() => setIsOpen(false)} style={{ background: 'transparent', border: 'none', color: 'white', cursor: 'pointer' }}>
              <X size={32} />
            </button>
          </div>
          
          <div style={{ flex: 1, padding: '0 24px', display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {menuItems.map((item, index) => (
              <button 
                key={index} 
                onClick={() => handleNav(item.path)}
                style={{ display: 'flex', alignItems: 'center', gap: '16px', padding: '24px', background: '#0a0a0a', border: '1px solid #111', borderRadius: '24px', color: 'white', fontSize: '1.1rem', fontWeight: 'bold', cursor: 'pointer' }}
              >
                <div style={{ color: 'var(--primary)' }}>{item.icon}</div>
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </>
  );
};

export default TopBar;

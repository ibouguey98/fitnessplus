import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Utensils, Coffee, Sun, Moon, Plus, 
  ArrowLeft, Activity, Info, ChevronRight, Apple
} from 'lucide-react';

const Nutrition = () => {
  const navigate = useNavigate();
  const [meals, setMeals] = useState([
    { id: 1, type: 'Petit Déjeuner', name: 'Avoine & Fruits', cals: 350, icon: <Coffee size={18} /> },
    { id: 2, type: 'Déjeuner', name: 'Poulet & Riz Tiep', cals: 650, icon: <Sun size={18} /> },
  ]);

  const stats = {
    target: 2400,
    consumed: 1000,
    protein: '75g / 150g',
    carbs: '120g / 300g',
    fats: '30g / 80g'
  };

  return (
    <div className="page-container" style={{ background: '#000' }}>
      <div className="flex-between mb-8 stagger-1">
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button className="btn-icon" onClick={() => navigate(-1)} style={{ width: '40px', height: '40px' }}>
            <ArrowLeft size={20} />
          </button>
          <h2 style={{ fontSize: '1.8rem' }}>Nutrition</h2>
        </div>
        <div style={{ width: '50px', height: '50px', background: '#4ade80', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#000' }}>
          <Utensils size={24} />
        </div>
      </div>

      {/* Daily Summary */}
      <div className="glass-panel mb-8 stagger-1" style={{ padding: '24px', textAlign: 'center', border: '1px solid rgba(74, 222, 128, 0.2)' }}>
        <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', marginBottom: '8px', textTransform: 'uppercase' }}>RESTANT AUJOURD'HUI</div>
        <div style={{ fontSize: '3rem', fontWeight: '900', color: '#fff' }}>{stats.target - stats.consumed} <span style={{ fontSize: '1rem', color: 'var(--text-muted)' }}>KCAL</span></div>
        
        <div style={{ width: '100%', height: '8px', background: '#222', borderRadius: '4px', margin: '20px 0' }}>
          <div style={{ width: `${(stats.consumed / stats.target) * 100}%`, height: '100%', background: '#4ade80', borderRadius: '4px', boxShadow: '0 0 15px rgba(74, 222, 128, 0.4)' }} />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '10px' }}>
          <div>
            <div style={{ fontSize: '0.9rem', fontWeight: 'bold' }}>{stats.protein}</div>
            <div style={{ fontSize: '0.6rem', color: 'var(--text-muted)' }}>PROTÉINES</div>
          </div>
          <div>
            <div style={{ fontSize: '0.9rem', fontWeight: 'bold' }}>{stats.carbs}</div>
            <div style={{ fontSize: '0.6rem', color: 'var(--text-muted)' }}>GLUCIDES</div>
          </div>
          <div>
            <div style={{ fontSize: '0.9rem', fontWeight: 'bold' }}>{stats.fats}</div>
            <div style={{ fontSize: '0.6rem', color: 'var(--text-muted)' }}>LIPIDES</div>
          </div>
        </div>
      </div>

      {/* Meals Journal */}
      <div className="mb-8 stagger-2">
        <h3 className="mb-6">JOURNAL ALIMENTAIRE</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {meals.map(meal => (
            <div key={meal.id} className="glass-panel" style={{ padding: '20px', display: 'flex', alignItems: 'center', gap: '16px' }}>
              <div style={{ width: '40px', height: '40px', background: 'rgba(255,255,255,0.05)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#4ade80' }}>
                {meal.icon}
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '0.65rem', color: '#4ade80', fontWeight: '900', textTransform: 'uppercase' }}>{meal.type}</div>
                <div style={{ fontWeight: '700' }}>{meal.name}</div>
              </div>
              <div style={{ fontWeight: '900' }}>{meal.cals} <span style={{ fontSize: '0.6rem', color: 'var(--text-muted)' }}>KCAL</span></div>
            </div>
          ))}
          
          <button className="glass-panel" style={{ padding: '20px', border: '1px dashed #333', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '12px', color: 'var(--text-muted)', cursor: 'pointer', background: 'transparent', width: '100%' }}>
            <Plus size={20} /> Ajouter un repas
          </button>
        </div>
      </div>

      {/* AI Nutrition Advice */}
      <div className="glass-panel stagger-3" style={{ padding: '24px', background: 'linear-gradient(135deg, #0a0a0a 0%, #000 100%)', border: '1px solid rgba(255,255,255,0.05)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
          <div style={{ width: '32px', height: '32px', background: 'var(--primary)', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#000' }}>
            <Activity size={18} />
          </div>
          <h4 style={{ fontSize: '1rem' }}>CONSEIL NUTRITION IA</h4>
        </div>
        <p className="subtitle" style={{ fontSize: '0.85rem', lineHeight: '1.5' }}>
          "Tu as consommé assez de glucides pour ton entraînement de ce soir. Pour le dîner, privilégie des **protéines maigres** (poisson ou blanc de poulet) pour optimiser ta récupération."
        </p>
      </div>

      <style>{`
        .stagger-1 { animation: slideUp 0.6s ease-out forwards; }
        .stagger-2 { opacity: 0; animation: slideUp 0.6s ease-out 0.2s forwards; }
        .stagger-3 { opacity: 0; animation: slideUp 0.6s ease-out 0.4s forwards; }
      `}</style>
    </div>
  );
};

export default Nutrition;

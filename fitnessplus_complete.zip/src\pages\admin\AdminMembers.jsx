import React, { useState } from 'react';
import { Users, Search, MoreVertical, ShieldAlert, Plus, ChevronLeft, Save, CheckCircle2 } from 'lucide-react';

const AdminMembers = () => {
  const [view, setView] = useState('list'); // 'list' or 'add'
  const [members, setMembers] = useState([
    { id: 1, name: 'Ibrahima Fall', status: 'Actif', plan: 'Mensuel', date: '12 Jan 2026' },
    { id: 2, name: 'Moussa Diop', status: 'Expiré', plan: 'Par Séance', date: '04 Fév 2026' },
    { id: 3, name: 'Awa Cissé', status: 'Actif', plan: 'Premium Scale', date: '15 Fév 2026' },
    { id: 4, name: 'Cheikh Ndiaye', status: 'Actif', plan: 'Mensuel', date: '28 Jan 2026' },
  ]);

  const [newMember, setNewMember] = useState({ name: '', plan: 'Mensuel' });

  const handleAddMember = () => {
    if (!newMember.name) return;
    const member = {
      id: members.length + 1,
      name: newMember.name,
      status: 'Actif',
      plan: newMember.plan,
      date: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'short', year: 'numeric' })
    };
    setMembers([member, ...members]);
    setView('list');
    setNewMember({ name: '', plan: 'Mensuel' });
  };

  if (view === 'add') {
    return (
      <div className="page-container">
        <div className="flex-center gap-2 mb-6" style={{ justifyContent: 'flex-start', cursor: 'pointer' }} onClick={() => setView('list')}>
          <ChevronLeft size={24} />
          <h1>Nouveau Membre</h1>
        </div>
        <div className="glass-panel mb-6">
          <div className="mb-4">
            <label className="subtitle" style={{ fontSize: '0.8rem', display: 'block', marginBottom: '8px' }}>Nom Complet</label>
            <input type="text" placeholder="Ex: Fatou Sow" value={newMember.name} onChange={(e) => setNewMember({...newMember, name: e.target.value})} style={{ width: '100%', background: 'var(--surface-solid)', border: '1px solid var(--surface-border)', color: 'white', padding: '12px', borderRadius: '12px', fontSize: '1rem' }} />
          </div>
          <div className="mb-4">
            <label className="subtitle" style={{ fontSize: '0.8rem', display: 'block', marginBottom: '8px' }}>Type d'Abonnement</label>
            <select value={newMember.plan} onChange={(e) => setNewMember({...newMember, plan: e.target.value})} style={{ width: '100%', background: 'var(--surface-solid)', border: '1px solid var(--surface-border)', color: 'white', padding: '12px', borderRadius: '12px', fontSize: '1rem', outline: 'none' }}>
              <option value="Mensuel">Mensuel</option>
              <option value="Par Séance">Par Séance</option>
              <option value="Premium Scale">Premium Scale</option>
            </select>
          </div>
        </div>
        <button className="btn-primary" onClick={handleAddMember}><CheckCircle2 size={20} style={{ marginRight: '8px' }} /> Créer le compte</button>
      </div>
    );
  }

  return (
    <div className="page-container">
      <div className="flex-between mb-6">
        <h1>Membres ({members.length})</h1>
        <button className="btn-icon" style={{ width: '40px', height: '40px', background: 'var(--primary)', color: '#000' }} onClick={() => setView('add')}>
          <Plus size={24} />
        </button>
      </div>

      <div className="glass-panel flex-center gap-2 mb-6" style={{ padding: '12px' }}>
        <Search size={20} color="var(--text-muted)" />
        <input 
          type="text" 
          placeholder="Rechercher un membre..." 
          style={{ background: 'transparent', border: 'none', color: 'white', outline: 'none', width: '100%' }}
        />
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {members.map(m => (
          <div key={m.id} className="glass-panel flex-between" style={{ padding: '16px', borderLeft: m.status === 'Expiré' ? '4px solid var(--danger)' : '4px solid var(--primary)' }}>
            <div className="flex-center gap-3">
              <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'var(--surface-solid)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold' }}>
                {m.name.charAt(0)}
              </div>
              <div>
                <h3 style={{ fontSize: '1rem', marginBottom: '2px' }}>{m.name}</h3>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{m.plan} • Inscrit le {m.date}</div>
              </div>
            </div>
            
            <div className="flex-center gap-3">
              {m.status === 'Expiré' && <ShieldAlert size={20} color="var(--danger)" />}
              <span style={{ fontSize: '0.8rem', fontWeight: 'bold', color: m.status === 'Expiré' ? 'var(--danger)' : 'var(--primary)' }}>
                {m.status}
              </span>
              <MoreVertical size={20} color="var(--text-muted)" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminMembers;

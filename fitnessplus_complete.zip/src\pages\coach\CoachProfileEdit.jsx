import React from 'react';
import { User, Image as ImageIcon, Star, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const CoachProfileEdit = () => {
  const navigate = useNavigate();

  return (
    <div className="page-container">
      <h1 className="mb-6">Mon Profil</h1>

      <div className="glass-panel flex-center mb-6" style={{ flexDirection: 'column', padding: '30px 20px' }}>
        <div style={{ position: 'relative' }}>
          <div style={{ width: '80px', height: '80px', borderRadius: '50%', background: 'linear-gradient(135deg, var(--primary), var(--secondary))', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px', color: '#170533', fontWeight: 'bold', fontSize: '2rem' }}>
            O
          </div>
          <div style={{ position: 'absolute', bottom: '16px', right: '-5px', background: 'var(--surface)', borderRadius: '50%', padding: '6px', border: '2px solid var(--bg-dark)' }}>
            <ImageIcon size={14} color="var(--text-main)" />
          </div>
        </div>
        <h2 style={{ fontSize: '1.5rem' }}>Coach Ousmane</h2>
        <div className="flex-center gap-1 mt-2">
          <Star size={16} color="var(--primary)" fill="var(--primary)" />
          <span style={{ fontWeight: 'bold' }}>4.9/5</span>
          <span style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>(124 avis)</span>
        </div>
      </div>

      <h3 className="mb-4">Informations</h3>
      <div className="glass-panel mb-6" style={{ padding: '0' }}>
        <div style={{ padding: '16px', borderBottom: '1px solid var(--surface-border)' }}>
          <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '8px' }}>Spécialités</label>
          <input type="text" defaultValue="Prépa Lutte, Force, Agilité" style={{ width: '100%', background: 'transparent', border: 'none', color: 'white', fontSize: '1rem', outline: 'none' }} />
        </div>
        <div style={{ padding: '16px' }}>
          <label style={{ fontSize: '0.8rem', color: 'var(--text-muted)', display: 'block', marginBottom: '8px' }}>Biographie courte</label>
          <textarea rows="3" defaultValue="Ancien préparateur physique pour les écuries de lutte de Pikine, Ousmane vous aide à développer votre explosivité." style={{ width: '100%', background: 'transparent', border: 'none', color: 'white', fontSize: '0.9rem', outline: 'none', resize: 'none' }}></textarea>
        </div>
      </div>

      <button className="btn-primary mb-4">Enregistrer les modifications</button>

      <button className="btn-primary" style={{ background: 'transparent', border: '1px solid var(--danger)', color: 'var(--danger)' }} onClick={() => navigate('/auth')}>
        <LogOut size={20} style={{ marginRight: '8px', verticalAlign: 'middle' }} />
        Déconnexion
      </button>

      {/* Footer */}
      <div style={{ padding: '40px 0', textAlign: 'center' }}>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.8rem', letterSpacing: '1px' }}>
          PROFILE SETTINGS v1.0
        </p>
      </div>

    </div>
  );
};

export default CoachProfileEdit;

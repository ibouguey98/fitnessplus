import React, { useState } from 'react';
import { Bell, Clock, AlertCircle, CheckCircle } from 'lucide-react';

export default function Notifications() {
  const [notifications] = useState([
    { id: 1, type: 'class', title: 'Cours de Yoga dans 30 min', time: '14:30', icon: '🧘' },
    { id: 2, type: 'reminder', title: 'N\'oubliez pas votre entraînement', time: '09:00', icon: '💪' },
    { id: 3, type: 'achievement', title: 'Vous avez atteint 100 calories!', time: 'Aujourd\'hui', icon: '🎉' },
    { id: 4, type: 'payment', title: 'Votre abonnement expire demain', time: 'Demain', icon: '💳' },
  ]);

  const [settings, setSettings] = useState({
    classReminders: true,
    workoutReminders: true,
    challengeNotifications: true,
    paymentAlerts: true,
    communityUpdates: false,
  });

  const toggleSetting = (key) => {
    setSettings({ ...settings, [key]: !settings[key] });
  };

  return (
    <div className="notifications">
      <h1>⏰ Rappels & Notifications</h1>

      {/* Recent Notifications */}
      <div className="section">
        <h2>Notifications récentes</h2>
        {notifications.map(notif => (
          <div key={notif.id} className="notification-item">
            <div className="notif-icon">{notif.icon}</div>
            <div className="notif-content">
              <h3>{notif.title}</h3>
              <p>{notif.time}</p>
            </div>
            <CheckCircle size={20} color="#ccc" />
          </div>
        ))}
      </div>

      {/* Notification Settings */}
      <div className="section">
        <h2>Paramètres des notifications</h2>
        
        <div className="settings-group">
          <div className="setting-item">
            <div className="setting-info">
              <h3>Rappels de cours</h3>
              <p>Alertes 30 min avant chaque cours</p>
            </div>
            <label className="toggle-switch">
              <input 
                type="checkbox" 
                checked={settings.classReminders}
                onChange={() => toggleSetting('classReminders')}
              />
              <span className="slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <div className="setting-info">
              <h3>Rappels d\'entraînement</h3>
              <p>Rappels quotidiens pour vos séances</p>
            </div>
            <label className="toggle-switch">
              <input 
                type="checkbox" 
                checked={settings.workoutReminders}
                onChange={() => toggleSetting('workoutReminders')}
              />
              <span className="slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <div className="setting-info">
              <h3>Notifications de défi</h3>
              <p>Mises à jour sur les défis en cours</p>
            </div>
            <label className="toggle-switch">
              <input 
                type="checkbox" 
                checked={settings.challengeNotifications}
                onChange={() => toggleSetting('challengeNotifications')}
              />
              <span className="slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <div className="setting-info">
              <h3>Alertes de paiement</h3>
              <p>Notifications sur votre abonnement</p>
            </div>
            <label className="toggle-switch">
              <input 
                type="checkbox" 
                checked={settings.paymentAlerts}
                onChange={() => toggleSetting('paymentAlerts')}
              />
              <span className="slider"></span>
            </label>
          </div>

          <div className="setting-item">
            <div className="setting-info">
              <h3>Mises à jour communauté</h3>
              <p>Nouvelles de la communauté</p>
            </div>
            <label className="toggle-switch">
              <input 
                type="checkbox" 
                checked={settings.communityUpdates}
                onChange={() => toggleSetting('communityUpdates')}
              />
              <span className="slider"></span>
            </label>
          </div>
        </div>
      </div>

      {/* Schedule */}
      <div className="section">
        <h2>Horaires des rappels</h2>
        <div className="schedule-card">
          <div className="schedule-item">
            <Clock size={18} />
            <div>
              <h4>Heure de rappel du matin</h4>
              <p>06:00 AM</p>
            </div>
          </div>
          <div className="schedule-item">
            <Clock size={18} />
            <div>
              <h4>Heure de rappel du soir</h4>
              <p>06:00 PM</p>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .notifications {
          padding: 20px;
          max-width: 500px;
          margin: 0 auto;
        }

        .notifications h1 {
          margin-bottom: 20px;
          color: #ff6b35;
        }

        .section {
          margin-bottom: 30px;
        }

        .section h2 {
          font-size: 16px;
          margin-bottom: 15px;
          color: #333;
        }

        .notification-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px;
          background: #f9f9f9;
          border-radius: 8px;
          margin-bottom: 10px;
        }

        .notif-icon {
          font-size: 24px;
        }

        .notif-content {
          flex: 1;
        }

        .notif-content h3 {
          margin: 0;
          font-size: 13px;
          color: #333;
        }

        .notif-content p {
          margin: 3px 0 0 0;
          font-size: 11px;
          color: #999;
        }

        .settings-group {
          background: #fff;
          border-radius: 10px;
          overflow: hidden;
        }

        .setting-item {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 15px;
          border-bottom: 1px solid #eee;
        }

        .setting-info h3 {
          margin: 0 0 5px 0;
          font-size: 13px;
          color: #333;
        }

        .setting-info p {
          margin: 0;
          font-size: 11px;
          color: #999;
        }

        .toggle-switch {
          position: relative;
          display: inline-block;
          width: 50px;
          height: 28px;
        }

        .toggle-switch input {
          opacity: 0;
          width: 0;
          height: 0;
        }

        .slider {
          position: absolute;
          cursor: pointer;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background-color: #ccc;
          transition: 0.3s;
          border-radius: 28px;
        }

        .slider:before {
          position: absolute;
          content: "";
          height: 22px;
          width: 22px;
          left: 3px;
          bottom: 3px;
          background-color: white;
          transition: 0.3s;
          border-radius: 50%;
        }

        input:checked + .slider {
          background-color: #ff6b35;
        }

        input:checked + .slider:before {
          transform: translateX(22px);
        }

        .schedule-card {
          background: #fff;
          border-radius: 10px;
          overflow: hidden;
        }

        .schedule-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 15px;
          border-bottom: 1px solid #eee;
          color: #ff6b35;
        }

        .schedule-item h4 {
          margin: 0 0 3px 0;
          font-size: 13px;
          color: #333;
        }

        .schedule-item p {
          margin: 0;
          font-size: 12px;
          color: #666;
        }
      `}</style>
    </div>
  );
}

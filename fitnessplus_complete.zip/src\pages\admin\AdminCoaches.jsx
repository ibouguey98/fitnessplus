import React, { useState, useEffect } from 'react';
import { UserPlus, Trash2, ChevronLeft, Save, Star } from 'lucide-react';

const AdminCoaches = () => {
  const [coaches, setCoaches] = useState([
    { id: 1, name: 'Ousmane', specialty: 'Lutte Sénégalaise', rating: 4.9 },
    { id: 2, name: 'Amina', specialty: 'Cardio Corniche', rating: 4.8 },
    { id: 3, name: 'Fatou', specialty: 'Zumba Mbalax', rating: 4.7 }
  ]);
  const [newCoach, setNewCoach] = useState({ name: '', specialty: '' });

  useEffect(() => {
    const saved = localStorage.getItem('fp_coaches');
    if (saved) setCoaches(JSON.parse(saved));
  }, []);

  const saveCoaches = (list) => {
    setCoaches(list);
    localStorage.setItem('fp_coaches', JSON.stringify(list));
  };

  const handleAdd = () => {
    if (!newCoach.name) return;
    const coach = { id: Date.now(), ...newCoach, rating: 5.0 };
    const newList = [...coaches, coach];
    saveCoaches(newList);
    setNewCoach({ name: '', specialty: '' });
  };

  const handleDelete = (id) => {
    const newList = coaches.filter(c => c.id !== id);
    saveCoaches(newList);
  };

  return (
    <div className="page-container">
      <div className="flex-center gap-2 mb-6" style={{ justifyContent: 'flex-start' }} onClick={() => window.history.back()}>
        <ChevronLeft size={24} />
        <h1>Gestion des Coachs</h1>
      </div>

      <div className="glass-panel mb-6">
        <h3 className="mb-4">Ajouter un Coach</h3>
        <div className="mb-3">
          <input 
            type="text" 
            placeholder="Nom du Coach" 
            value={newCoach.name}
            onChange={(e) => setNewCoach({...newCoach, name: e.target.value})}
            style={{ width: '100%', background: 'var(--surface-solid)', border: '1px solid var(--surface-border)', color: 'white', padding: '12px', borderRadius: '12px' }}
          />
        </div>
        <div className="mb-4">
          <input 
            type="text" 
            placeholder="Spécialité (ex: Zumba, Lutte)" 
            value={newCoach.specialty}
            onChange={(e) => setNewCoach({...newCoach, specialty: e.target.value})}
            style={{ width: '100%', background: 'var(--surface-solid)', border: '1px solid var(--surface-border)', color: 'white', padding: '12px', borderRadius: '12px' }}
          />
        </div>
        <button className="btn-primary" onClick={handleAdd}>
          <UserPlus size={20} style={{ marginRight: '8px' }} /> Ajouter à l'équipe
        </button>
      </div>

      <h3 className="mb-4">Équipe Actuelle ({coaches.length})</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
        {coaches.map(c => (
          <div key={c.id} className="glass-panel flex-between" style={{ padding: '16px' }}>
            <div className="flex-center gap-3">
              <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'var(--primary)', color: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold' }}>
                {c.name.charAt(0)}
              </div>
              <div>
                <h4 style={{ margin: 0 }}>Coach {c.name}</h4>
                <p className="subtitle" style={{ fontSize: '0.8rem' }}>{c.specialty} • <Star size={10} style={{ display: 'inline' }} /> {c.rating}</p>
              </div>
            </div>
            <button 
              onClick={() => handleDelete(c.id)}
              style={{ background: 'transparent', border: 'none', color: 'var(--danger)', cursor: 'pointer' }}
            >
              <Trash2 size={20} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminCoaches;

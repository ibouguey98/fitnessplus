import React from 'react';
import { useNavigate } from 'react-router-dom';
import { CheckCircle, Zap } from 'lucide-react';

const ChoosePlan = () => {
  const navigate = useNavigate();
  const [tarifs, setTarifs] = React.useState({ mensuel: '25 000', seance: '10 000', journalier: '2 500' });

  React.useEffect(() => {
    const savedTarifs = localStorage.getItem('fp_tarifs');
    if (savedTarifs) setTarifs(JSON.parse(savedTarifs));
  }, []);

  const handleChoice = (plan) => {
    alert(`Vous avez sélectionné : ${plan}. Bienvenue dans l'aventure FitnessPlus !`);
    navigate('/dashboard');
  };

  return (
    <div className="page-container" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', background: 'var(--bg-darker)', paddingTop: '40px' }}>
      
      <div style={{ textAlign: 'center', marginBottom: '32px' }}>
        <h1 className="text-gradient mb-2" style={{ fontSize: '2rem' }}>Choisissez votre formule</h1>
        <p className="subtitle">Pour accéder à votre espace client, veuillez sélectionner un abonnement.</p>
      </div>

      <div style={{ width: '100%', maxWidth: '400px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
        
        {/* Silver */}
        <div 
          className="glass-panel" 
          style={{ border: '1px solid var(--surface-border)', cursor: 'pointer', transition: 'transform 0.2s', padding: '16px' }}
          onClick={() => handleChoice('Silver')}
        >
          <h2 style={{ fontSize: '1.2rem' }}>🥈 Formule Silver</h2>
          <p className="subtitle" style={{ fontSize: '0.8rem', marginBottom: '8px' }}>8 séances / mois. Idéal pour débuter.</p>
          <div style={{ fontSize: '1.8rem', fontWeight: '900', color: 'var(--secondary)' }}>
            60 000 <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>FCFA</span>
          </div>
        </div>

        {/* Gold */}
        <div 
          className="glass-panel" 
          style={{ border: '2px solid var(--primary)', cursor: 'pointer', position: 'relative', transition: 'transform 0.2s', padding: '16px' }}
          onClick={() => handleChoice('Gold')}
        >
          <div style={{ position: 'absolute', top: -12, right: 20, background: 'var(--primary)', color: '#000', padding: '4px 16px', borderRadius: '12px', fontSize: '0.7rem', fontWeight: 'bold', textTransform: 'uppercase' }}>Populaire</div>
          <h2 style={{ fontSize: '1.2rem' }}>🥇 Formule Gold</h2>
          <p className="subtitle" style={{ fontSize: '0.8rem', marginBottom: '8px' }}>12 séances / mois. Pour progresser visiblement.</p>
          <div style={{ fontSize: '1.8rem', fontWeight: '900', color: 'var(--primary)' }}>
            80 000 <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>FCFA</span>
          </div>
        </div>

        {/* Platinum */}
        <div 
          className="glass-panel" 
          style={{ border: '1px solid var(--surface-border)', cursor: 'pointer', padding: '16px' }}
          onClick={() => handleChoice('Platinum')}
        >
          <h2 style={{ fontSize: '1.2rem' }}>💎 Formule Platinum</h2>
          <p className="subtitle" style={{ fontSize: '0.8rem', marginBottom: '8px' }}>20 séances / mois. Transformation rapide.</p>
          <div style={{ fontSize: '1.8rem', fontWeight: '900', color: 'var(--secondary)' }}>
            90 000 <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>FCFA</span>
          </div>
        </div>

        <p className="subtitle" style={{ textAlign: 'center', fontSize: '0.8rem', marginTop: '10px' }}>
          Ou séance simple à <span style={{ color: 'var(--primary)', fontWeight: 'bold' }}>2 000 FCFA</span>
        </p>
      </div>
    </div>
  );
};

export default ChoosePlan;

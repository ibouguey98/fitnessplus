import React, { useState, useEffect } from 'react';
import { Settings, Bell, Clock, ShieldCheck, CreditCard, ChevronRight, Save, ChevronLeft, Check, Users } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const AdminSettings = () => {
  const navigate = useNavigate();
  const [view, setView] = useState('main'); 
  const [tarifs, setTarifs] = useState({ mensuel: '30 000', seance: '2 000', journalier: '2 000' });
  const [horaires, setHoraires] = useState('07:00 - 23:00');
  const [accessControl, setAccessControl] = useState(true);
  const [alerts, setAlerts] = useState(true);

  useEffect(() => {
    const savedTarifs = localStorage.getItem('fp_tarifs');
    if (savedTarifs) setTarifs(JSON.parse(savedTarifs));
  }, []);

  const handleSave = (type) => {
    if (type === 'Tarifs') {
      localStorage.setItem('fp_tarifs', JSON.stringify(tarifs));
    }
    alert(`${type} mis à jour avec succès !`);
    setView('main');
  };

  if (view === 'pricing') {
    return (
      <div className="page-container">
        <div className="flex-center gap-2 mb-6" style={{ justifyContent: 'flex-start', cursor: 'pointer' }} onClick={() => setView('main')}>
          <ChevronLeft size={24} />
          <h1>Tarification</h1>
        </div>
        <div className="glass-panel mb-6">
          <div className="mb-4">
            <label className="subtitle" style={{ fontSize: '0.8rem', display: 'block', marginBottom: '8px' }}>Abonnement Mensuel (FCFA)</label>
            <input type="text" value={tarifs.mensuel} onChange={(e) => setTarifs({...tarifs, mensuel: e.target.value})} style={{ width: '100%', background: 'var(--surface-solid)', border: '1px solid var(--surface-border)', color: 'white', padding: '12px', borderRadius: '12px', fontSize: '1.2rem', fontWeight: 'bold' }} />
          </div>
          <div className="mb-4">
            <label className="subtitle" style={{ fontSize: '0.8rem', display: 'block', marginBottom: '8px' }}>Séance Individuelle Coach (FCFA)</label>
            <input type="text" value={tarifs.seance} onChange={(e) => setTarifs({...tarifs, seance: e.target.value})} style={{ width: '100%', background: 'var(--surface-solid)', border: '1px solid var(--surface-border)', color: 'white', padding: '12px', borderRadius: '12px', fontSize: '1.2rem', fontWeight: 'bold' }} />
          </div>
          <div>
            <label className="subtitle" style={{ fontSize: '0.8rem', display: 'block', marginBottom: '8px' }}>Accès Journalier Simple (FCFA)</label>
            <input type="text" value={tarifs.journalier} onChange={(e) => setTarifs({...tarifs, journalier: e.target.value})} style={{ width: '100%', background: 'var(--surface-solid)', border: '1px solid var(--surface-border)', color: 'white', padding: '12px', borderRadius: '12px', fontSize: '1.2rem', fontWeight: 'bold' }} />
          </div>
        </div>
        <button className="btn-primary" onClick={() => handleSave('Tarifs')}><Save size={20} style={{ marginRight: '8px' }} /> Enregistrer</button>
      </div>
    );
  }

  if (view === 'hours') {
    return (
      <div className="page-container">
        <div className="flex-center gap-2 mb-6" style={{ justifyContent: 'flex-start', cursor: 'pointer' }} onClick={() => setView('main')}>
          <ChevronLeft size={24} />
          <h1>Horaires d'ouverture</h1>
        </div>
        <div className="glass-panel mb-6">
          <label className="subtitle" style={{ fontSize: '0.8rem', display: 'block', marginBottom: '8px' }}>Plage horaire globale</label>
          <input type="text" value={horaires} onChange={(e) => setHoraires(e.target.value)} style={{ width: '100%', background: 'var(--surface-solid)', border: '1px solid var(--surface-border)', color: 'white', padding: '12px', borderRadius: '12px', fontSize: '1.2rem', fontWeight: 'bold' }} />
          <p className="subtitle mt-3" style={{ fontSize: '0.8rem' }}>Exemple: 06:00 - 23:00</p>
        </div>
        <button className="btn-primary" onClick={() => handleSave('Horaires')}><Save size={20} style={{ marginRight: '8px' }} /> Enregistrer</button>
      </div>
    );
  }

  return (
    <div className="page-container">
      <h1 className="mb-6">Paramètres Salle</h1>

      <div className="mb-6">
        <h3 className="mb-3" style={{ fontSize: '0.9rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Configuration Globale</h3>
        <div className="glass-panel" style={{ padding: 0 }}>
          <div className="flex-between" style={{ padding: '16px', borderBottom: '1px solid var(--surface-border)', cursor: 'pointer' }} onClick={() => setView('hours')}>
            <div className="flex-center gap-3"><Clock size={20} color="var(--primary)" /><span>Horaires d'Ouverture</span></div>
            <div className="flex-center gap-2"><span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>{horaires}</span><ChevronRight size={16} color="var(--text-muted)"/></div>
          </div>
          <div className="flex-between" style={{ padding: '16px', borderBottom: '1px solid var(--surface-border)', cursor: 'pointer' }} onClick={() => setView('pricing')}>
            <div className="flex-center gap-3"><CreditCard size={20} color="var(--text-main)" /><span>Tarification & Abonnements</span></div>
            <div className="flex-center gap-2"><span style={{ fontSize: '0.8rem', color: 'var(--primary)', fontWeight: 'bold' }}>{tarifs.mensuel} F</span><ChevronRight size={16} color="var(--text-muted)"/></div>
          </div>
          <div className="flex-between" style={{ padding: '16px', borderBottom: '1px solid var(--surface-border)', cursor: 'pointer' }} onClick={() => navigate('/admin/coaches')}>
            <div className="flex-center gap-3"><Users size={20} color="var(--secondary)" /><span>Gestion de l'Équipe (Coachs)</span></div>
            <ChevronRight size={16} color="var(--text-muted)"/>
          </div>
          <div className="flex-between" style={{ padding: '16px', cursor: 'pointer' }} onClick={() => setAccessControl(!accessControl)}>
            <div className="flex-center gap-3"><ShieldCheck size={20} color={accessControl ? "var(--primary)" : "var(--danger)"} /><span>Contrôle d'Accès (QR)</span></div>
            <div style={{ background: accessControl ? 'var(--success)' : 'var(--danger)', padding: '4px 12px', borderRadius: '12px', fontSize: '0.7rem', color: '#000', fontWeight: 'bold' }}>
              {accessControl ? 'ACTIF' : 'INACTIF'}
            </div>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="mb-3" style={{ fontSize: '0.9rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Notifications</h3>
        <div className="glass-panel" style={{ padding: 0 }}>
          <div className="flex-between" style={{ padding: '16px', cursor: 'pointer' }} onClick={() => setAlerts(!alerts)}>
            <div className="flex-center gap-3"><Bell size={20} color="var(--text-main)" /><span>Alertes Impayés</span></div>
            <div style={{ width: '44px', height: '24px', background: alerts ? 'var(--primary)' : 'var(--surface-solid)', borderRadius: '12px', position: 'relative', transition: 'all 0.3s' }}>
              <div style={{ position: 'absolute', right: alerts ? '2px' : '22px', top: '2px', width: '20px', height: '20px', background: '#000', borderRadius: '50%', transition: 'all 0.3s' }}></div>
            </div>
          </div>
        </div>
      </div>

      <button className="btn-primary" style={{ background: 'transparent', border: '1px solid var(--danger)', color: 'var(--danger)' }} onClick={() => navigate('/auth')}>
        Fermer la session Admin
      </button>
    </div>
  );
};

export default AdminSettings;

import React, { useState } from 'react';
import { Bell, Moon, Smartphone, Shield, HelpCircle, ChevronRight } from 'lucide-react';

const AppSettings = () => {
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(true);

  return (
    <div className="page-container">
      <h1 className="mb-6">Paramètres App</h1>

      <div className="mb-6">
        <h3 className="mb-4" style={{ fontSize: '1rem', color: 'var(--text-muted)' }}>Préférences</h3>
        <div className="glass-panel" style={{ padding: 0 }}>
          <div className="flex-between" style={{ padding: '16px', borderBottom: '1px solid var(--surface-border)' }}>
            <div className="flex-center gap-3">
              <Bell size={20} color="var(--primary)" />
              <span style={{ fontWeight: '500' }}>Notifications Push</span>
            </div>
            <div 
              onClick={() => setNotifications(!notifications)}
              style={{ width: '44px', height: '24px', background: notifications ? 'var(--primary)' : 'var(--surface-solid)', borderRadius: '12px', position: 'relative', cursor: 'pointer', transition: 'all 0.3s' }}
            >
              <div style={{ position: 'absolute', right: notifications ? '2px' : '22px', top: '2px', width: '20px', height: '20px', background: '#000', borderRadius: '50%', transition: 'all 0.3s' }} />
            </div>
          </div>
          <div className="flex-between" style={{ padding: '16px' }}>
            <div className="flex-center gap-3">
              <Moon size={20} color="var(--secondary)" />
              <span style={{ fontWeight: '500' }}>Mode Sombre</span>
            </div>
            <div 
              onClick={() => setDarkMode(!darkMode)}
              style={{ width: '44px', height: '24px', background: darkMode ? 'var(--primary)' : 'var(--surface-solid)', borderRadius: '12px', position: 'relative', cursor: 'pointer', transition: 'all 0.3s' }}
            >
              <div style={{ position: 'absolute', right: darkMode ? '2px' : '22px', top: '2px', width: '20px', height: '20px', background: '#000', borderRadius: '50%', transition: 'all 0.3s' }} />
            </div>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <h3 className="mb-4" style={{ fontSize: '1rem', color: 'var(--text-muted)' }}>Assistance</h3>
        <div className="glass-panel" style={{ padding: 0 }}>
          <div className="flex-between" style={{ padding: '16px', borderBottom: '1px solid var(--surface-border)', cursor: 'pointer' }}>
            <div className="flex-center gap-3">
              <Shield size={20} color="var(--text-main)" />
              <span style={{ fontWeight: '500' }}>Confidentialité</span>
            </div>
            <ChevronRight size={20} color="var(--text-muted)" />
          </div>
          <div className="flex-between" style={{ padding: '16px', cursor: 'pointer' }}>
            <div className="flex-center gap-3">
              <HelpCircle size={20} color="var(--text-main)" />
              <span style={{ fontWeight: '500' }}>Centre d'aide</span>
            </div>
            <ChevronRight size={20} color="var(--text-muted)" />
          </div>
        </div>
      </div>

      <div style={{ textAlign: 'center', marginTop: '40px' }}>
        <p className="subtitle" style={{ fontSize: '0.8rem' }}>Version 1.0.4 (Stable)</p>
      </div>
    </div>
  );
};

export default AppSettings;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Camera, X, CheckCircle2, ShieldCheck } from 'lucide-react';

const Scanner = () => {
  const navigate = useNavigate();
  const [scanning, setScanning] = useState(true);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    if (scanning) {
      const timer = setTimeout(() => {
        setScanning(false);
        setSuccess(true);
      }, 3000); // Simulate 3 seconds of scanning
      return () => clearTimeout(timer);
    }
  }, [scanning]);

  return (
    <div className="page-container" style={{ 
      background: '#000', 
      height: '100vh', 
      padding: 0, 
      display: 'flex', 
      flexDirection: 'column',
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* Camera Viewport (Simulated) */}
      <div style={{ 
        flex: 1, 
        position: 'relative', 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'center',
        background: '#111'
      }}>
        {scanning && (
          <>
            {/* Viewfinder corners */}
            <div style={{ position: 'absolute', top: '25%', left: '15%', width: '40px', height: '40px', borderTop: '4px solid var(--primary)', borderLeft: '4px solid var(--primary)', borderRadius: '8px 0 0 0' }} />
            <div style={{ position: 'absolute', top: '25%', right: '15%', width: '40px', height: '40px', borderTop: '4px solid var(--primary)', borderRight: '4px solid var(--primary)', borderRadius: '0 8px 0 0' }} />
            <div style={{ position: 'absolute', bottom: '25%', left: '15%', width: '40px', height: '40px', borderBottom: '4px solid var(--primary)', borderLeft: '4px solid var(--primary)', borderRadius: '0 0 0 8px' }} />
            <div style={{ position: 'absolute', bottom: '25%', right: '15%', width: '40px', height: '40px', borderBottom: '4px solid var(--primary)', borderRight: '4px solid var(--primary)', borderRadius: '0 0 8px 0' }} />
            
            {/* Scanning Line */}
            <div style={{ 
              position: 'absolute', 
              top: '25%', 
              left: '15%', 
              right: '15%', 
              height: '2px', 
              background: 'var(--primary)', 
              boxShadow: '0 0 15px var(--primary)',
              animation: 'moveScan 2s infinite ease-in-out'
            }} />
            
            <p style={{ position: 'absolute', bottom: '20%', color: 'var(--primary)', fontWeight: 'bold', letterSpacing: '1px' }}>SCAN EN COURS...</p>
          </>
        )}

        {success && (
          <div className="glass-panel" style={{ 
            textAlign: 'center', 
            padding: '40px', 
            animation: 'scaleIn 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275)' 
          }}>
            <div style={{ background: 'var(--primary)', width: '80px', height: '80px', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px' }}>
              <CheckCircle2 size={48} color="#000" />
            </div>
            <h2 style={{ fontSize: '1.8rem', marginBottom: '8px' }}>ACCÈS AUTORISÉ</h2>
            <p className="subtitle" style={{ color: 'var(--primary)', fontWeight: 'bold' }}>Bienvenue à FitnessPlus Pikine !</p>
            <button className="btn-primary mt-6" onClick={() => navigate('/dashboard')}>ENTRER</button>
          </div>
        )}

        {/* Back Button */}
        <button 
          onClick={() => navigate(-1)} 
          style={{ position: 'absolute', top: '40px', right: '20px', background: 'rgba(0,0,0,0.5)', border: 'none', color: 'white', padding: '10px', borderRadius: '50%', cursor: 'pointer' }}
        >
          <X size={24} />
        </button>
      </div>

      <style>{`
        @keyframes moveScan {
          0% { transform: translateY(0); }
          50% { transform: translateY(35vh); }
          100% { transform: translateY(0); }
        }
        @keyframes scaleIn {
          from { opacity: 0; transform: scale(0.8); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>

      {/* Bottom Tip */}
      <div style={{ padding: '30px', textAlign: 'center', background: 'var(--bg-dark)' }}>
        <p className="subtitle">Placez le QR Code de la borne dans le cadre pour déverrouiller l'accès.</p>
      </div>
    </div>
  );
};

export default Scanner;

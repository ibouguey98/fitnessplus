import React, { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '40px', background: '#000', color: '#fff', height: '100vh' }}>
          <h1>Désolé, une erreur est survenue.</h1>
          <pre style={{ color: 'red', marginTop: '20px' }}>{this.state.error?.toString()}</pre>
          <button onClick={() => { localStorage.clear(); window.location.href='/'; }} style={{ marginTop: '20px', padding: '10px 20px', background: 'var(--primary)', border: 'none', borderRadius: '8px', fontWeight: 'bold' }}>Réinitialiser l'application</button>
        </div>
      );
    }
    return this.props.children;
  }
}

console.log('FitnessPlus mounting...');
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
)


if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js');
  });
}

import React, { useState } from 'react';
import { TrendingUp, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const ProgressTracking = () => {
  const navigate = useNavigate();
  const [workoutHistory] = useState([
    { date: '2026-05-07', exercise: 'Musculation', duration: 60, calories: 350, intensity: 'Intense' },
    { date: '2026-05-06', exercise: 'Cardio', duration: 45, calories: 280, intensity: 'Modéré' },
    { date: '2026-05-05', exercise: 'Yoga', duration: 50, calories: 150, intensity: 'Facile' },
    { date: '2026-05-04', exercise: 'Crossfit', duration: 75, calories: 420, intensity: 'Intense' },
  ]);

  const stats = {
    totalWorkouts: 42,
    totalCalories: 8500,
    totalMinutes: 2800,
    currentStreak: 12,
    thisWeek: 5,
  };

  return (
    <div className="page-container" style={{ background: '#000' }}>
      {/* Header */}
      <div className="flex-between mb-8 stagger-1">
        <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
          <button className="btn-icon" onClick={() => navigate(-1)} style={{ width: '40px', height: '40px' }}>
            <ArrowLeft size={20} />
          </button>
          <h2 style={{ fontSize: '1.8rem' }}>Suivi Progression</h2>
        </div>
        <div style={{ width: '50px', height: '50px', background: 'var(--primary)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#000', boxShadow: '0 0 20px var(--primary-glow)' }}>
          <TrendingUp size={24} />
        </div>
      </div>

      {/* Stats Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '24px' }} className="stagger-1">
        <div className="glass-panel" style={{ padding: '20px', textAlign: 'center', border: '1px solid rgba(212, 255, 0, 0.2)' }}>
          <div style={{ fontSize: '2rem', fontWeight: '900', color: 'var(--primary)' }}>{stats.totalWorkouts}</div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '8px', textTransform: 'uppercase' }}>Entraînements</div>
        </div>
        <div className="glass-panel" style={{ padding: '20px', textAlign: 'center', border: '1px solid rgba(212, 255, 0, 0.2)' }}>
          <div style={{ fontSize: '2rem', fontWeight: '900', color: 'var(--primary)' }}>{stats.currentStreak}</div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '8px', textTransform: 'uppercase' }}>Jours Consécutifs</div>
        </div>
        <div className="glass-panel" style={{ padding: '20px', textAlign: 'center', border: '1px solid rgba(212, 255, 0, 0.2)' }}>
          <div style={{ fontSize: '2rem', fontWeight: '900', color: 'var(--primary)' }}>{stats.totalCalories}</div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '8px', textTransform: 'uppercase' }}>Calories</div>
        </div>
        <div className="glass-panel" style={{ padding: '20px', textAlign: 'center', border: '1px solid rgba(212, 255, 0, 0.2)' }}>
          <div style={{ fontSize: '2rem', fontWeight: '900', color: 'var(--primary)' }}>{(stats.totalMinutes / 60).toFixed(0)}h</div>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '8px', textTransform: 'uppercase' }}>Temps Total</div>
        </div>
      </div>

      {/* Weekly Chart */}
      <div className="glass-panel stagger-2" style={{ padding: '24px', border: '1px solid var(--surface-border)', marginBottom: '24px' }}>
        <h3 style={{ marginBottom: '20px' }}>Activité cette semaine</h3>
        <div style={{ display: 'flex', justifyContent: 'space-around', alignItems: 'flex-end', height: '140px' }}>
          {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map((day, i) => (
            <div key={day} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '8px' }}>
              <div style={{ 
                width: '30px', 
                height: `${(i + 1) * 15}%`, 
                background: `linear-gradient(to top, var(--primary), rgba(212, 255, 0, 0.5))`,
                borderRadius: '4px',
                boxShadow: i > 3 ? '0 0 15px var(--primary-glow)' : 'none'
              }} />
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>{day}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Workout History */}
      <div className="stagger-2">
        <h3 style={{ marginBottom: '16px' }}>Historique d\'entraînement</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {workoutHistory.map((workout, idx) => (
            <div key={idx} className="glass-panel" style={{ padding: '16px', border: '1px solid var(--surface-border)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                <h4 style={{ margin: 0, fontSize: '0.95rem' }}>{workout.exercise}</h4>
                <span style={{ fontSize: '0.8rem', color: 'var(--primary)' }}>{workout.calories} cal</span>
              </div>
              <div style={{ display: 'flex', gap: '16px', fontSize: '0.85rem', color: 'var(--text-muted)', marginBottom: '8px' }}>
                <span>{workout.date}</span>
                <span>•</span>
                <span>{workout.duration}min</span>
              </div>
              <div style={{ 
                display: 'inline-block',
                padding: '4px 12px',
                borderRadius: '6px',
                fontSize: '0.75rem',
                fontWeight: '600',
                background: workout.intensity === 'Intense' ? 'rgba(239, 68, 68, 0.2)' : workout.intensity === 'Modéré' ? 'rgba(212, 255, 0, 0.15)' : 'rgba(16, 185, 129, 0.2)',
                color: workout.intensity === 'Intense' ? '#ef4444' : workout.intensity === 'Modéré' ? 'var(--primary)' : '#10b981'
              }}>
                {workout.intensity}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA Button */}
      <button 
        style={{ 
          width: '100%', 
          padding: '16px', 
          background: 'var(--primary)',
          color: '#000',
          border: 'none',
          borderRadius: '12px',
          fontWeight: '700',
          fontSize: '0.95rem',
          marginTop: '24px',
          cursor: 'pointer',
          boxShadow: '0 0 20px var(--primary-glow)',
          transition: 'all 0.3s'
        }}
        onMouseEnter={(e) => e.target.style.transform = 'translateY(-2px)'}
        onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}
      >
        Commencer une séance
      </button>

    </div>
  );
};

export default ProgressTracking;

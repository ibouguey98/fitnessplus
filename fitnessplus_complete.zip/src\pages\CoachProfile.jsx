import React from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Star, Award, MessageCircle, CalendarClock } from 'lucide-react';

const CoachProfile = () => {
  const navigate = useNavigate();
  // On mock l'ID pour la démo
  
  return (
    <div className="page-container">
      <div className="flex-center mb-6" style={{ justifyContent: 'flex-start', gap: '16px' }}>
        <button className="btn-icon" onClick={() => navigate(-1)}>
          <ArrowLeft size={20} />
        </button>
        <h2>Profil du Coach</h2>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginBottom: '24px' }}>
        <div style={{ width: '120px', height: '120px', borderRadius: '50%', background: 'linear-gradient(135deg, var(--primary), var(--secondary))', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px', fontSize: '3rem', fontWeight: 'bold', color: '#170533' }}>
          O
        </div>
        <h1 style={{ fontSize: '1.8rem' }}>Coach Ousmane</h1>
        <p className="subtitle" style={{ fontSize: '1rem', marginTop: '4px' }}>Expert en Force & Lutte</p>
        
        <div className="flex-center gap-1 mt-3" style={{ background: 'var(--surface-solid)', padding: '6px 12px', borderRadius: '20px' }}>
          <Star size={16} color="var(--primary)" fill="var(--primary)" />
          <Star size={16} color="var(--primary)" fill="var(--primary)" />
          <Star size={16} color="var(--primary)" fill="var(--primary)" />
          <Star size={16} color="var(--primary)" fill="var(--primary)" />
          <Star size={16} color="var(--primary)" />
          <span style={{ marginLeft: '8px', fontSize: '0.9rem', fontWeight: '600' }}>4.8/5</span>
        </div>
      </div>

      <div className="glass-panel mb-6">
        <h3 className="mb-2">À propos</h3>
        <p className="subtitle" style={{ lineHeight: '1.6' }}>
          Ancien préparateur physique pour les écuries de lutte de Pikine, Ousmane vous aide à développer votre explosivité et votre résilience mentale. Un coaching rigoureux pour des résultats rapides.
        </p>
      </div>

      <h3 className="mb-4">Offre Premium Coaching (Scale)</h3>
      <div className="glass-panel mb-6" style={{ border: '1px solid var(--primary)' }}>
        <div className="flex-between mb-3">
          <div className="flex-center gap-2">
            <Award size={24} color="var(--primary)" />
            <span style={{ fontWeight: 'bold', fontSize: '1.1rem' }}>Pack Transformation</span>
          </div>
          <span style={{ fontWeight: 'bold', fontSize: '1.2rem' }}>50 000 FCFA</span>
        </div>
        <ul className="subtitle" style={{ listStylePosition: 'inside', marginBottom: '16px', lineHeight: '1.8' }}>
          <li>Suivi individuel 3x par semaine</li>
          <li>Plan nutritionnel adapté (Thieb diet)</li>
          <li>Accès WhatsApp 24/7</li>
        </ul>
        <button className="btn-primary" onClick={() => navigate('/payment')}>Souscrire au Programme</button>
      </div>

      <div className="flex-between gap-3">
        <button className="glass-panel flex-center gap-2" style={{ flex: 1, padding: '15px', cursor: 'pointer' }} onClick={() => alert('Ouverture de WhatsApp pour contacter Coach Ousmane...')}>
          <MessageCircle size={20} color="var(--text-main)" />
          <span>Contacter</span>
        </button>
        <button className="glass-panel flex-center gap-2" style={{ flex: 1, padding: '15px', cursor: 'pointer' }} onClick={() => alert('Calendrier des disponibilités (Bientôt disponible).')}>
          <CalendarClock size={20} color="var(--text-main)" />
          <span>Dispos</span>
        </button>
      </div>

    </div>
  );
};

export default CoachProfile;

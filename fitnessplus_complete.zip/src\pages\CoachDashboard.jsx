import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Calendar, Users, Award, ChevronRight, 
  MessageCircle, DollarSign, TrendingUp, 
  CheckCircle, Bell, MoreHorizontal, Activity
} from 'lucide-react';

const CoachDashboard = () => {
  const navigate = useNavigate();
  const [isAvailable, setIsAvailable] = useState(true);

  return (
    <div className="page-container">
      {/* Header */}
      <div className="flex-between mb-8 stagger-1">
        <div>
          <h1 style={{ fontSize: '1.8rem', marginBottom: '4px' }}>Coach Ousmane 👋</h1>
          <div className="flex-center gap-2" style={{ justifyContent: 'flex-start' }}>
            <div style={{ 
              width: '10px', height: '10px', borderRadius: '50%', 
              background: isAvailable ? 'var(--primary)' : 'var(--danger)',
              boxShadow: `0 0 10px ${isAvailable ? 'var(--primary)' : 'var(--danger)'}`
            }} />
            <span className="subtitle" style={{ fontSize: '0.85rem' }}>{isAvailable ? 'En ligne • Prêt à coacher' : 'Occupé • En séance'}</span>
          </div>
        </div>
        <div className="btn-icon" onClick={() => setIsAvailable(!isAvailable)}>
          <Bell size={24} />
        </div>
      </div>

      {/* Main Stats Card */}
      <div className="glass-panel mb-8 stagger-1" style={{ padding: '24px', border: '1px solid var(--primary-glow)' }}>
        <div className="flex-between mb-6">
          <div style={{ color: 'var(--primary)', fontWeight: '800', fontSize: '0.75rem', textTransform: 'uppercase' }}>Revenus de la semaine</div>
          <button className="btn-icon" style={{ width: '32px', height: '32px', background: 'transparent' }}><MoreHorizontal size={18} /></button>
        </div>
        <div style={{ fontSize: '2.5rem', fontWeight: '900', marginBottom: '24px' }}>450 000 <span style={{ fontSize: '1rem', color: 'var(--text-muted)' }}>FCFA</span></div>
        
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', height: '80px', gap: '8px' }}>
          {[40, 70, 45, 90, 65, 80, 100].map((h, i) => (
            <div key={i} style={{ flex: 1, background: i === 6 ? 'var(--primary)' : '#222', height: `${h}%`, borderRadius: '4px', transition: 'all 0.4s' }}></div>
          ))}
        </div>
        <div className="flex-between mt-4" style={{ fontSize: '0.65rem', color: 'var(--text-muted)', fontWeight: '700' }}>
          <span>L</span><span>M</span><span>M</span><span>J</span><span>V</span><span>S</span><span>D</span>
        </div>
      </div>

      {/* Active Session Card */}
      <div className="glass-panel mb-8 stagger-2" style={{ background: 'var(--primary)', color: '#000', padding: '24px', position: 'relative', overflow: 'hidden', border: 'none' }}>
        <div style={{ position: 'absolute', top: '-10px', right: '-10px', opacity: 0.1 }}><Activity size={100} /></div>
        <div className="flex-between mb-4">
          <span style={{ fontWeight: '900', fontSize: '0.75rem', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Séance en cours</span>
          <div style={{ padding: '4px 10px', background: '#000', color: 'var(--primary)', borderRadius: '20px', fontSize: '0.65rem', fontWeight: '900' }}>LIVE</div>
        </div>
        <h2 style={{ fontSize: '1.5rem', color: '#000', marginBottom: '8px' }}>Prépa Lutte</h2>
        <div className="flex-between">
          <p style={{ fontWeight: '700', fontSize: '0.9rem', opacity: 0.8 }}>Salle B • 15 Participants</p>
          <button style={{ background: '#000', color: '#fff', border: 'none', padding: '12px 24px', borderRadius: '14px', fontWeight: '900', fontSize: '0.8rem', cursor: 'pointer' }}>FINIR</button>
        </div>
      </div>

      {/* Clients Section */}
      <div className="flex-between mb-4 stagger-2">
        <h3>Clients Premium</h3>
        <span style={{ color: 'var(--primary)', fontSize: '0.8rem', fontWeight: '800' }}>VOIR TOUT</span>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', marginBottom: '40px' }} className="stagger-3">
        {[
          { name: 'Ibrahima Fall', goal: 'Prise de masse', img: 'IF' },
          { name: 'Mamadou Diop', goal: 'Perte de poids', img: 'MD' },
          { name: 'Fatou Sow', goal: 'Remise en forme', img: 'FS' },
        ].map((client, i) => (
          <div key={i} className="glass-panel" style={{ display: 'flex', alignItems: 'center', gap: '16px', padding: '16px 20px' }}>
            <div style={{ width: '48px', height: '48px', borderRadius: '14px', background: '#222', border: '1px solid var(--surface-border)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: '900', color: 'var(--primary)' }}>
              {client.img}
            </div>
            <div style={{ flex: 1 }}>
              <h4 style={{ fontSize: '1rem', marginBottom: '2px' }}>{client.name}</h4>
              <p className="subtitle" style={{ fontSize: '0.75rem' }}>{client.goal}</p>
            </div>
            <button className="btn-icon" style={{ width: '40px', height: '40px', background: 'transparent' }}>
              <MessageCircle size={20} color="var(--primary)" />
            </button>
          </div>
        ))}
      </div>

      {/* Stats Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }} className="stagger-3">
        <div className="glass-panel" style={{ padding: '24px' }}>
          <TrendingUp size={24} color="var(--primary)" style={{ marginBottom: '16px' }} />
          <div style={{ fontSize: '1.8rem', fontWeight: '900' }}>+12%</div>
          <p className="subtitle" style={{ fontSize: '0.75rem' }}>Performance</p>
        </div>
        <div className="glass-panel" style={{ padding: '24px' }}>
          <Users size={24} color="var(--secondary)" style={{ marginBottom: '16px' }} />
          <div style={{ fontSize: '1.8rem', fontWeight: '900' }}>142</div>
          <p className="subtitle" style={{ fontSize: '0.75rem' }}>Total Clients</p>
        </div>
      </div>
    </div>
  );
};

export default CoachDashboard;

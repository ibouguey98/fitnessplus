import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  User, Settings, CreditCard, Award, 
  LogOut, ChevronRight, Crown, MapPin, Phone, Mail
} from 'lucide-react';

const Profile = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState(null);
  const [userPlan, setUserPlan] = useState(localStorage.getItem('fp_user_plan') || 'aucun');

  useEffect(() => {
    const saved = localStorage.getItem('fp_user_data');
    if (saved) setUserData(JSON.parse(saved));
  }, []);

  const logout = () => {
    localStorage.removeItem('fp_user_role');
    localStorage.removeItem('fp_user_plan');
    navigate('/auth');
  };

  return (
    <div className="page-container">
      <div className="flex-between mb-8 stagger-1">
        <h1 style={{ fontSize: '2rem' }}>Mon Profil</h1>
        <div className="btn-icon">
          <Settings size={24} />
        </div>
      </div>
      
      {/* User Info Card */}
      <div className="glass-panel flex-center mb-8 stagger-1" style={{ flexDirection: 'column', padding: '40px 20px', textAlign: 'center' }}>
        <div style={{ position: 'relative', marginBottom: '20px' }}>
          <div style={{ width: '100px', height: '100px', borderRadius: '30px', background: 'var(--bg-dark)', border: '2px solid var(--primary)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary)', boxShadow: '0 0 30px var(--primary-glow)' }}>
            <User size={50} />
          </div>
          {userPlan !== 'aucun' && (
            <div style={{ position: 'absolute', bottom: '-10px', right: '-10px', width: '36px', height: '36px', background: 'var(--primary)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#000', border: '4px solid var(--bg-card)' }}>
              <Crown size={18} />
            </div>
          )}
        </div>
        
        <h2 style={{ fontSize: '1.6rem', marginBottom: '8px' }}>{userData?.name || 'Ibrahima Fall'}</h2>
        <div className="flex-center gap-2" style={{ marginBottom: '4px' }}>
          <span style={{ padding: '4px 12px', borderRadius: '20px', background: 'var(--primary-glow)', color: 'var(--primary)', fontSize: '0.75rem', fontWeight: '900', textTransform: 'uppercase' }}>
            {userPlan === 'aucun' ? 'Membre Standard' : `Membre ${userPlan.toUpperCase()}`}
          </span>
        </div>
        <p className="subtitle" style={{ fontSize: '0.8rem' }}>Membre depuis Mars 2026</p>
      </div>

      {/* Upgrade Call to Action if no plan */}
      {userPlan === 'aucun' && (
        <div className="glass-panel mb-8 stagger-2" style={{ background: 'var(--primary)', color: '#000', border: 'none' }}>
          <div className="flex-between mb-4">
            <h3 style={{ color: '#000', fontSize: '1.1rem' }}>Passez au niveau supérieur</h3>
            <Crown size={20} />
          </div>
          <p style={{ fontSize: '0.85rem', fontWeight: '700', marginBottom: '24px', opacity: 0.8 }}>Accès 24/7, coach privé et programmes personnalisés.</p>
          <button className="btn-primary" style={{ background: '#000', color: '#fff', padding: '16px' }} onClick={() => navigate('/payment')}>
            Découvrir les offres
          </button>
        </div>
      )}

      {/* Menu Options */}
      <div className="stagger-2">
        <h3 className="mb-4" style={{ fontSize: '0.8rem', color: 'var(--text-muted)', textTransform: 'uppercase', letterSpacing: '0.1em' }}>Compte</h3>
        <div className="glass-panel mb-8" style={{ padding: '0', overflow: 'hidden' }}>
          {[
            { icon: <Award size={20} />, label: 'Mes Objectifs', path: '/goals' },
            { icon: <CreditCard size={20} />, label: 'Abonnement & Factures', path: '/payment' },
            { icon: <Mail size={20} />, label: 'Support Technique', path: '/support' },
          ].map((item, i) => (
            <div key={i} onClick={() => navigate(item.path)} style={{ display: 'flex', alignItems: 'center', gap: '20px', padding: '24px', borderBottom: i < 2 ? '1px solid #111' : 'none', cursor: 'pointer' }}>
              <div style={{ color: 'var(--primary)' }}>{item.icon}</div>
              <span style={{ flex: 1, fontWeight: '700' }}>{item.label}</span>
              <ChevronRight size={18} color="#333" />
            </div>
          ))}
        </div>
      </div>

      {/* Contact & Logout */}
      <div className="stagger-3">
        <div className="glass-panel mb-10" style={{ padding: '24px' }}>
          <div className="flex-center gap-4 mb-4" style={{ justifyContent: 'flex-start' }}>
            <MapPin size={18} color="var(--primary)" />
            <p className="subtitle" style={{ fontSize: '0.8rem' }}>Pikine Khourounar près de Khelcom Bache</p>
          </div>
          <div className="flex-center gap-4 mb-4" style={{ justifyContent: 'flex-start' }}>
            <Phone size={18} color="var(--primary)" />
            <p className="subtitle" style={{ fontSize: '0.8rem' }}>+221 78 719 17 17</p>
          </div>
          <div className="flex-center gap-4" style={{ justifyContent: 'flex-start' }}>
            <Mail size={18} color="var(--primary)" />
            <p className="subtitle" style={{ fontSize: '0.8rem' }}>contact@fitnessplus.sn</p>
          </div>
        </div>

        <button 
          onClick={logout}
          className="btn-primary" 
          style={{ background: 'transparent', border: '1px solid #ef4444', color: '#ef4444', height: '64px' }}
        >
          <LogOut size={20} /> <span translate="no">Déconnexion</span>
        </button>
      </div>
    </div>
  );
};

export default Profile;

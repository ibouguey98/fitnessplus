import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  User, Activity as Dumbbell, Target, Weight, Scale, 
  ChevronRight, ArrowLeft, Zap, Heart, Award as Trophy,
  Layout
} from 'lucide-react';

const Onboarding = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(localStorage.getItem('fp_user_role') ? 2 : 1);
  const [data, setData] = useState({
    profile: localStorage.getItem('fp_user_role') || 'client',
    goal: 'lose',
    name: '',
    weight: '',
    height: '',
    level: 'intermediate'
  });

  const next = () => {
    localStorage.setItem('fp_user_role', data.profile);
    if (data.profile === 'admin') {
      navigate('/admin');
    } else {
      setStep(s => s + 1);
    }
  };
  const prev = () => setStep(s => s - 1);

  const save = () => {
    localStorage.setItem('fp_user_data', JSON.stringify(data));
    if (data.profile === 'coach') {
      navigate('/coach-dashboard');
    } else {
      navigate('/dashboard');
    }
  };

  return (
    <div style={{ minHeight: '100vh', background: '#000', color: 'white', padding: '60px 24px' }}>
      
      {/* Header */}
      <div className="flex-between mb-8">
        {step > 1 ? (
          <button onClick={prev} className="btn-icon"><ArrowLeft size={20} /></button>
        ) : <div style={{ width: '54px' }} />}
        
        <div style={{ display: 'flex', gap: '6px' }}>
          {[1, 2, 3, 4].map(s => (
            <div key={s} style={{ 
              width: s === step ? '24px' : '8px', 
              height: '8px', 
              background: s <= step ? 'var(--primary)' : '#222', 
              borderRadius: '10px',
              transition: 'all 0.3s'
            }} />
          ))}
        </div>
        <div style={{ width: '54px' }} />
      </div>

      {step === 1 && (
        <div className="stagger-1">
          <h1 style={{ fontSize: '2.5rem', marginBottom: '12px', textAlign: 'center' }}>Choisissez<br />votre profil</h1>
          <p className="subtitle" style={{ textAlign: 'center', marginBottom: '48px' }}>Nous personnaliserons votre expérience en fonction de votre rôle.</p>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <div 
              onClick={() => setData({...data, profile: 'client'})}
              className="glass-panel" 
              style={{ 
                border: data.profile === 'client' ? '2px solid var(--primary)' : '1px solid var(--surface-border)',
                display: 'flex', alignItems: 'center', gap: '20px'
              }}
            >
              <div style={{ width: '50px', height: '50px', background: data.profile === 'client' ? 'var(--primary)' : '#222', borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <User color={data.profile === 'client' ? '#000' : '#888'} />
              </div>
              <div style={{ flex: 1 }}>
                <h3 style={{ fontSize: '1.1rem', marginBottom: '4px' }}>Client</h3>
                <p className="subtitle" style={{ fontSize: '0.8rem' }}>S'entraîner, réserver, suivre mes progrès</p>
              </div>
              {data.profile === 'client' && <ChevronRight color="var(--primary)" />}
            </div>

            <div 
              onClick={() => setData({...data, profile: 'coach'})}
              className="glass-panel" 
              style={{ 
                border: data.profile === 'coach' ? '2px solid var(--primary)' : '1px solid var(--surface-border)',
                display: 'flex', alignItems: 'center', gap: '20px'
              }}
            >
              <div style={{ width: '50px', height: '50px', background: data.profile === 'coach' ? 'var(--primary)' : '#222', borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Dumbbell color={data.profile === 'coach' ? '#000' : '#888'} />
              </div>
              <div style={{ flex: 1 }}>
                <h3 style={{ fontSize: '1.1rem', marginBottom: '4px' }} translate="no">Coach</h3>
                <p className="subtitle" style={{ fontSize: '0.8rem' }}>Gérer mes séances, mes clients</p>
              </div>
              {data.profile === 'coach' && <ChevronRight color="var(--primary)" />}
            </div>

            <div 
              onClick={() => setData({...data, profile: 'admin'})}
              className="glass-panel" 
              style={{ 
                border: data.profile === 'admin' ? '2px solid var(--primary)' : '1px solid var(--surface-border)',
                display: 'flex', alignItems: 'center', gap: '20px'
              }}
            >
              <div style={{ width: '50px', height: '50px', background: data.profile === 'admin' ? 'var(--primary)' : '#222', borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Layout color={data.profile === 'admin' ? '#000' : '#888'} />
              </div>
              <div style={{ flex: 1 }}>
                <h3 style={{ fontSize: '1.1rem', marginBottom: '4px' }}>Administrateur</h3>
                <p className="subtitle" style={{ fontSize: '0.8rem' }}>Gérer la salle, les revenus, les membres</p>
              </div>
              {data.profile === 'admin' && <ChevronRight color="var(--primary)" />}
            </div>
          </div>
          
          <button className="btn-primary" style={{ marginTop: '80px' }} onClick={next}>Suivant</button>
        </div>
      )}

      {step === 2 && (
        <div className="stagger-1">
          <h1 style={{ fontSize: '2.5rem', marginBottom: '12px', textAlign: 'center' }}>Quel est votre<br />objectif principal ?</h1>
          <p className="subtitle" style={{ textAlign: 'center', marginBottom: '48px' }}>Cela nous aidera à personnaliser votre expérience.</p>
          
          <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '16px' }}>
            {[
              { id: 'lose', label: 'Perte de poids', icon: <Weight size={20} /> },
              { id: 'build', label: 'Prise de masse', icon: <Zap size={20} /> },
              { id: 'fit', label: 'Remise en forme', icon: <Heart size={20} /> },
              { id: 'wellbeing', label: 'Bien-être', icon: <Target size={20} /> },
              { id: 'performance', label: 'Performance', icon: <Trophy size={20} /> },
            ].map(g => (
              <div 
                key={g.id}
                onClick={() => setData({...data, goal: g.id})}
                className="glass-panel"
                style={{ 
                  display: 'flex', alignItems: 'center', gap: '16px', padding: '16px 24px',
                  border: data.goal === g.id ? '2px solid var(--primary)' : '1px solid var(--surface-border)',
                  background: data.goal === g.id ? 'rgba(212, 255, 0, 0.05)' : 'var(--bg-card)'
                }}
              >
                <div style={{ color: data.goal === g.id ? 'var(--primary)' : '#555' }}>{g.icon}</div>
                <span style={{ fontWeight: '700', flex: 1 }}>{g.label}</span>
                <div style={{ width: '20px', height: '20px', borderRadius: '50%', border: '2px solid', borderColor: data.goal === g.id ? 'var(--primary)' : '#333', background: data.goal === g.id ? 'var(--primary)' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {data.goal === g.id && <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#000' }} />}
                </div>
              </div>
            ))}
          </div>
          
          <button className="btn-primary" style={{ marginTop: '40px' }} onClick={next}>Suivant</button>
        </div>
      )}

      {step === 3 && (
        <div className="stagger-1">
          <h1 style={{ fontSize: '2.5rem', marginBottom: '12px', textAlign: 'center' }}>Informations<br />personnelles</h1>
          <p className="subtitle" style={{ textAlign: 'center', marginBottom: '40px' }}>Complétez votre profil.</p>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
            <div className="glass-panel" style={{ padding: '20px' }}>
              <label style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: '700', textTransform: 'uppercase', marginBottom: '8px', display: 'block' }}>Nom complet</label>
              <input 
                type="text" 
                placeholder="Ex: Ibrahima Fall" 
                value={data.name}
                onChange={e => setData({...data, name: e.target.value})}
                style={{ width: '100%', background: 'transparent', border: 'none', color: 'white', fontSize: '1.1rem', fontWeight: 'bold', outline: 'none' }}
              />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div className="glass-panel" style={{ padding: '20px' }}>
                <label style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: '700', textTransform: 'uppercase', marginBottom: '8px', display: 'block' }}>Âge</label>
                <input type="number" placeholder="24" style={{ width: '100%', background: 'transparent', border: 'none', color: 'white', fontSize: '1.1rem', fontWeight: 'bold', outline: 'none' }} />
              </div>
              <div className="glass-panel" style={{ padding: '20px' }}>
                <label style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: '700', textTransform: 'uppercase', marginBottom: '8px', display: 'block' }}>Poids (kg)</label>
                <input 
                  type="number" 
                  placeholder="75" 
                  value={data.weight}
                  onChange={e => setData({...data, weight: e.target.value})}
                  style={{ width: '100%', background: 'transparent', border: 'none', color: 'white', fontSize: '1.1rem', fontWeight: 'bold', outline: 'none' }}
                />
              </div>
            </div>

            <div className="glass-panel" style={{ padding: '20px' }}>
              <label style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: '700', textTransform: 'uppercase', marginBottom: '8px', display: 'block' }}>Taille (cm)</label>
              <input 
                type="number" 
                placeholder="180" 
                value={data.height}
                onChange={e => setData({...data, height: e.target.value})}
                style={{ width: '100%', background: 'transparent', border: 'none', color: 'white', fontSize: '1.1rem', fontWeight: 'bold', outline: 'none' }}
              />
            </div>

            <div className="glass-panel" style={{ padding: '20px' }}>
              <label style={{ fontSize: '0.7rem', color: 'var(--text-muted)', fontWeight: '700', textTransform: 'uppercase', marginBottom: '8px', display: 'block' }}>Niveau</label>
              <select 
                value={data.level}
                onChange={e => setData({...data, level: e.target.value})}
                style={{ width: '100%', background: 'transparent', border: 'none', color: 'white', fontSize: '1.1rem', fontWeight: 'bold', outline: 'none' }}
              >
                <option value="beginner">Débutant</option>
                <option value="intermediate">Intermédiaire</option>
                <option value="advanced">Avancé</option>
              </select>
            </div>
          </div>
          
          <button className="btn-primary" style={{ marginTop: '40px' }} onClick={save}>Terminer</button>
        </div>
      )}

    </div>
  );
};

export default Onboarding;

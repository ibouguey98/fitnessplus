import React, { useState } from 'react';
import { Activity, TrendingUp, Heart, Zap } from 'lucide-react';

export default function HealthReports() {
  const [metrics, setMetrics] = useState({
    bmi: 24.5,
    weight: 75,
    height: 175,
    age: 28,
    caloriesBurned: 8500,
    waterIntake: 2.5,
    sleepHours: 7.5,
    restingHeartRate: 62,
  });

  const [weeklyData] = useState([
    { day: 'Lun', calories: 450, distance: 5.2, duration: 45 },
    { day: 'Mar', calories: 520, distance: 6.1, duration: 52 },
    { day: 'Mer', calories: 380, distance: 4.8, duration: 38 },
    { day: 'Jeu', calories: 620, distance: 7.3, duration: 65 },
    { day: 'Ven', calories: 490, distance: 5.9, duration: 48 },
    { day: 'Sam', calories: 780, distance: 9.2, duration: 85 },
    { day: 'Dim', calories: 350, distance: 3.5, duration: 30 },
  ]);

  const getBMICategory = (bmi) => {
    if (bmi < 18.5) return { cat: 'Sous-poids', color: '#4CAF50' };
    if (bmi < 25) return { cat: 'Normal', color: '#2196F3' };
    if (bmi < 30) return { cat: 'Surpoids', color: '#ff9800' };
    return { cat: 'Obésité', color: '#f44336' };
  };

  const bmiData = getBMICategory(metrics.bmi);
  const totalCalories = weeklyData.reduce((sum, d) => sum + d.calories, 0);
  const totalDistance = weeklyData.reduce((sum, d) => sum + d.distance, 0);
  const avgDuration = Math.round(weeklyData.reduce((sum, d) => sum + d.duration, 0) / 7);

  return (
    <div className="health-reports">
      <h1>📊 Rapports de santé</h1>

      {/* BMI Card */}
      <div className="bmi-card">
        <h2>Indice de Masse Corporelle</h2>
        <div className="bmi-display">
          <div className="bmi-circle" style={{ borderColor: bmiData.color }}>
            <div className="bmi-value">{metrics.bmi}</div>
            <div className="bmi-status" style={{ color: bmiData.color }}>
              {bmiData.cat}
            </div>
          </div>
        </div>
        <div className="bmi-input">
          <input type="number" placeholder="Poids (kg)" value={metrics.weight} readOnly />
          <input type="number" placeholder="Taille (cm)" value={metrics.height} readOnly />
        </div>
        <p className="bmi-text">
          Poids: {metrics.weight}kg | Taille: {metrics.height}cm
        </p>
      </div>

      {/* Key Metrics */}
      <div className="metrics-section">
        <h2>Métriques principales</h2>
        <div className="metrics-grid">
          <div className="metric-card">
            <Heart size={24} color="#ff6b35" />
            <div className="metric-info">
              <span className="metric-label">Fréquence cardiaque</span>
              <span className="metric-value">{metrics.restingHeartRate} bpm</span>
            </div>
          </div>
          <div className="metric-card">
            <Zap size={24} color="#ffa500" />
            <div className="metric-info">
              <span className="metric-label">Calories brûlées</span>
              <span className="metric-value">{metrics.caloriesBurned}</span>
            </div>
          </div>
          <div className="metric-card">
            <Activity size={24} color="#4CAF50" />
            <div className="metric-info">
              <span className="metric-label">Heures de sommeil</span>
              <span className="metric-value">{metrics.sleepHours}h</span>
            </div>
          </div>
          <div className="metric-card">
            <TrendingUp size={24} color="#2196F3" />
            <div className="metric-info">
              <span className="metric-label">Eau consommée</span>
              <span className="metric-value">{metrics.waterIntake}L</span>
            </div>
          </div>
        </div>
      </div>

      {/* Weekly Summary */}
      <div className="weekly-summary">
        <h2>Résumé de la semaine</h2>
        <div className="summary-stats">
          <div className="summary-card">
            <span className="summary-label">Total calories</span>
            <span className="summary-value">{totalCalories}</span>
          </div>
          <div className="summary-card">
            <span className="summary-label">Distance totale</span>
            <span className="summary-value">{totalDistance.toFixed(1)}km</span>
          </div>
          <div className="summary-card">
            <span className="summary-label">Durée moyenne</span>
            <span className="summary-value">{avgDuration}min</span>
          </div>
        </div>
      </div>

      {/* Weekly Chart */}
      <div className="chart-section">
        <h2>Calories par jour</h2>
        <div className="week-chart">
          {weeklyData.map(day => (
            <div key={day.day} className="day-column">
              <div className="bar" style={{ height: `${(day.calories / 100)}px` }}>
                <span className="value">{day.calories}</span>
              </div>
              <span className="day">{day.day}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Health Tips */}
      <div className="health-tips">
        <h2>💡 Recommandations</h2>
        <div className="tip">
          <span>✓ Continuez vos exercices réguliers</span>
        </div>
        <div className="tip">
          <span>✓ Augmentez votre consommation d\'eau</span>
        </div>
        <div className="tip">
          <span>✓ Maintenez au moins 7-8h de sommeil</span>
        </div>
        <div className="tip">
          <span>✓ Variez vos types d\'entraînement</span>
        </div>
      </div>

      <style jsx>{`
        .health-reports {
          padding: 20px;
          max-width: 500px;
          margin: 0 auto;
        }

        .health-reports h1 {
          margin-bottom: 20px;
          color: #ff6b35;
        }

        .bmi-card {
          background: white;
          border: 2px solid #e0e0e0;
          padding: 20px;
          border-radius: 15px;
          margin-bottom: 20px;
        }

        .bmi-card h2 {
          margin: 0 0 15px 0;
          color: #333;
          font-size: 16px;
        }

        .bmi-display {
          display: flex;
          justify-content: center;
          margin-bottom: 15px;
        }

        .bmi-circle {
          width: 150px;
          height: 150px;
          border: 8px solid #2196F3;
          border-radius: 50%;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
        }

        .bmi-value {
          font-size: 40px;
          font-weight: bold;
          color: #333;
        }

        .bmi-status {
          font-size: 12px;
          font-weight: bold;
        }

        .bmi-input {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
          margin-bottom: 10px;
        }

        .bmi-input input {
          padding: 8px;
          border: 1px solid #eee;
          border-radius: 6px;
          font-size: 12px;
        }

        .bmi-text {
          margin: 0;
          text-align: center;
          font-size: 12px;
          color: #666;
        }

        .metrics-section {
          margin-bottom: 20px;
        }

        .metrics-section h2 {
          margin-bottom: 12px;
          color: #333;
        }

        .metrics-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
        }

        .metric-card {
          display: flex;
          align-items: center;
          gap: 12px;
          background: #f9f9f9;
          padding: 12px;
          border-radius: 8px;
        }

        .metric-info {
          display: flex;
          flex-direction: column;
          gap: 3px;
        }

        .metric-label {
          font-size: 10px;
          color: #999;
        }

        .metric-value {
          font-size: 14px;
          font-weight: bold;
          color: #333;
        }

        .weekly-summary {
          background: linear-gradient(135deg, #ff6b35, #ffa500);
          color: white;
          padding: 20px;
          border-radius: 12px;
          margin-bottom: 20px;
        }

        .weekly-summary h2 {
          margin: 0 0 15px 0;
          font-size: 16px;
        }

        .summary-stats {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
        }

        .summary-card {
          background: rgba(255,255,255,0.2);
          padding: 12px;
          border-radius: 8px;
          text-align: center;
        }

        .summary-label {
          display: block;
          font-size: 10px;
          opacity: 0.8;
          margin-bottom: 5px;
        }

        .summary-value {
          display: block;
          font-size: 18px;
          font-weight: bold;
        }

        .chart-section {
          margin-bottom: 20px;
        }

        .chart-section h2 {
          margin-bottom: 15px;
          color: #333;
        }

        .week-chart {
          display: flex;
          justify-content: space-around;
          align-items: flex-end;
          height: 180px;
          background: #f9f9f9;
          padding: 15px;
          border-radius: 10px;
          gap: 8px;
        }

        .day-column {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
        }

        .bar {
          width: 30px;
          background: linear-gradient(to top, #ff6b35, #ffa500);
          border-radius: 5px 5px 0 0;
          display: flex;
          align-items: flex-end;
          justify-content: center;
          position: relative;
        }

        .value {
          font-size: 10px;
          color: white;
          font-weight: bold;
          margin-bottom: 2px;
        }

        .day {
          font-size: 10px;
          color: #666;
          font-weight: bold;
        }

        .health-tips {
          background: #e8f5e9;
          padding: 15px;
          border-radius: 10px;
        }

        .health-tips h2 {
          margin: 0 0 12px 0;
          color: #2e7d32;
        }

        .tip {
          padding: 8px 0;
          font-size: 12px;
          color: #1b5e20;
          border-bottom: 1px solid #c8e6c9;
        }

        .tip:last-child {
          border-bottom: none;
        }
      `}</style>
    </div>
  );
}

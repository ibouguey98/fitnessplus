import React, { useState } from 'react';
import { Share2, Users, Gift, Copy, Check } from 'lucide-react';

export default function Referral() {
  const [referralCode] = useState('FPLUS2024ABC');
  const [copied, setCopied] = useState(false);
  const [referrals] = useState([
    { name: 'Moussa Sow', date: '2026-04-15', status: 'Actif', reward: '500 FCFA' },
    { name: 'Amine Ba', date: '2026-04-22', status: 'Actif', reward: '500 FCFA' },
    { name: 'Yacine Diop', date: '2026-05-01', status: 'En attente', reward: '500 FCFA' },
  ]);

  const stats = {
    totalReferrals: 3,
    activeReferrals: 2,
    totalEarnings: 1000,
    pendingRewards: 500,
  };

  const copyCode = () => {
    navigator.clipboard.writeText(referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="referral">
      <h1>👥 Système de Parrainage</h1>

      {/* Referral Link */}
      <div className="referral-card">
        <h2>Partagez et gagnez!</h2>
        <p>Invitez vos amis et recevez des récompenses</p>
        
        <div className="referral-code-section">
          <h3>Votre code de parrainage</h3>
          <div className="code-box">
            <span className="code">{referralCode}</span>
            <button 
              className="btn-copy"
              onClick={copyCode}
            >
              {copied ? <Check size={18} /> : <Copy size={18} />}
            </button>
          </div>
          <button className="btn-share">
            <Share2 size={16} /> Partager
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="stats-section">
        <h2>Mes statistiques</h2>
        <div className="stats-grid">
          <div className="stat-box">
            <div className="stat-number">{stats.totalReferrals}</div>
            <div className="stat-label">Parrainages</div>
          </div>
          <div className="stat-box">
            <div className="stat-number">{stats.activeReferrals}</div>
            <div className="stat-label">Actifs</div>
          </div>
          <div className="stat-box">
            <div className="stat-number">{stats.totalEarnings}</div>
            <div className="stat-label">Points gagnés</div>
          </div>
          <div className="stat-box">
            <div className="stat-number">{stats.pendingRewards}</div>
            <div className="stat-label">En attente</div>
          </div>
        </div>
      </div>

      {/* Rewards */}
      <div className="rewards-section">
        <h2>Récompenses disponibles</h2>
        <div className="reward-card">
          <Gift size={24} />
          <h3>Récompense par parrainage</h3>
          <p>500 FCFA par ami invité</p>
        </div>
        <div className="reward-card bonus">
          <Gift size={24} />
          <h3>Bonus de 10 parrainages</h3>
          <p>5 000 FCFA bonus!</p>
        </div>
      </div>

      {/* Referral List */}
      <div className="referrals-list">
        <h2>Mes filleuls</h2>
        {referrals.map((ref, idx) => (
          <div key={idx} className="referral-item">
            <div className="referral-avatar">
              <Users size={24} color="white" />
            </div>
            <div className="referral-info">
              <h4>{ref.name}</h4>
              <p>{ref.date}</p>
            </div>
            <div className="referral-status">
              <span className={`status ${ref.status.toLowerCase().replace(' ', '-')}`}>
                {ref.status}
              </span>
              <span className="reward">+{ref.reward}</span>
            </div>
          </div>
        ))}
      </div>

      {/* How it works */}
      <div className="how-it-works">
        <h2>Comment ça marche</h2>
        <div className="step">
          <div className="step-number">1</div>
          <h3>Partagez votre code</h3>
          <p>Envoyez votre code à vos amis</p>
        </div>
        <div className="step">
          <div className="step-number">2</div>
          <h3>Ils s\'inscrivent</h3>
          <p>Vos amis utilisent votre code pour s\'inscrire</p>
        </div>
        <div className="step">
          <div className="step-number">3</div>
          <h3>Recevez la récompense</h3>
          <p>Vous recevez 500 FCFA instantanément</p>
        </div>
      </div>

      <style jsx>{`
        .referral {
          padding: 20px;
          max-width: 500px;
          margin: 0 auto;
        }

        .referral h1 {
          margin-bottom: 20px;
          color: #ff6b35;
        }

        .referral-card {
          background: linear-gradient(135deg, #ff6b35, #ffa500);
          color: white;
          padding: 30px 20px;
          border-radius: 15px;
          margin-bottom: 30px;
          text-align: center;
        }

        .referral-card h2 {
          margin: 0 0 5px 0;
          font-size: 18px;
        }

        .referral-card p {
          margin: 0 0 20px 0;
          font-size: 13px;
          opacity: 0.9;
        }

        .referral-code-section {
          background: rgba(255,255,255,0.2);
          padding: 15px;
          border-radius: 10px;
        }

        .referral-code-section h3 {
          margin: 0 0 10px 0;
          font-size: 12px;
          opacity: 0.8;
        }

        .code-box {
          display: flex;
          align-items: center;
          gap: 10px;
          background: white;
          padding: 12px;
          border-radius: 8px;
          margin-bottom: 12px;
        }

        .code {
          flex: 1;
          font-size: 16px;
          font-weight: bold;
          color: #ff6b35;
          letter-spacing: 2px;
        }

        .btn-copy {
          background: #ff6b35;
          color: white;
          border: none;
          width: 36px;
          height: 36px;
          border-radius: 50%;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .btn-share {
          width: 100%;
          padding: 10px;
          background: white;
          color: #ff6b35;
          border: none;
          border-radius: 6px;
          font-weight: bold;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
        }

        .stats-section {
          margin-bottom: 30px;
        }

        .stats-section h2 {
          margin-bottom: 15px;
          color: #333;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
        }

        .stat-box {
          background: #f9f9f9;
          padding: 15px;
          border-radius: 10px;
          text-align: center;
        }

        .stat-number {
          font-size: 24px;
          font-weight: bold;
          color: #ff6b35;
          margin-bottom: 5px;
        }

        .stat-label {
          font-size: 12px;
          color: #666;
        }

        .rewards-section {
          margin-bottom: 30px;
        }

        .rewards-section h2 {
          margin-bottom: 15px;
          color: #333;
        }

        .reward-card {
          background: white;
          border: 2px solid #ffe0cc;
          padding: 15px;
          border-radius: 10px;
          text-align: center;
          margin-bottom: 10px;
          color: #ff6b35;
        }

        .reward-card.bonus {
          background: #fff9f0;
          border-color: #ff6b35;
        }

        .reward-card h3 {
          margin: 10px 0 5px 0;
          font-size: 14px;
        }

        .reward-card p {
          margin: 0;
          font-size: 12px;
          color: #666;
        }

        .referrals-list {
          margin-bottom: 30px;
        }

        .referrals-list h2 {
          margin-bottom: 15px;
          color: #333;
        }

        .referral-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px;
          background: #f9f9f9;
          border-radius: 8px;
          margin-bottom: 10px;
        }

        .referral-avatar {
          width: 45px;
          height: 45px;
          background: #ff6b35;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .referral-info {
          flex: 1;
        }

        .referral-info h4 {
          margin: 0;
          font-size: 13px;
          color: #333;
        }

        .referral-info p {
          margin: 3px 0 0 0;
          font-size: 11px;
          color: #999;
        }

        .referral-status {
          display: flex;
          flex-direction: column;
          align-items: flex-end;
          gap: 5px;
        }

        .status {
          font-size: 10px;
          font-weight: bold;
          padding: 2px 8px;
          border-radius: 3px;
        }

        .status.actif {
          background: #ccffcc;
          color: #00cc00;
        }

        .status.en-attente {
          background: #ffffcc;
          color: #ff9900;
        }

        .reward {
          font-size: 12px;
          font-weight: bold;
          color: #ff6b35;
        }

        .how-it-works {
          background: #f9f9f9;
          padding: 20px;
          border-radius: 12px;
        }

        .how-it-works h2 {
          margin: 0 0 20px 0;
          color: #333;
        }

        .step {
          display: flex;
          gap: 15px;
          margin-bottom: 20px;
        }

        .step-number {
          width: 40px;
          height: 40px;
          background: #ff6b35;
          color: white;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: bold;
          flex-shrink: 0;
        }

        .step h3 {
          margin: 0 0 3px 0;
          font-size: 13px;
          color: #333;
        }

        .step p {
          margin: 0;
          font-size: 11px;
          color: #666;
        }
      `}</style>
    </div>
  );
}

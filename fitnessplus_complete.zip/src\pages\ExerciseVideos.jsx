import React, { useState } from 'react';
import { Play, Clock, Zap } from 'lucide-react';

export default function ExerciseVideos() {
  const [videos] = useState([
    { id: 1, title: 'Pompes parfaites', duration: 8, difficulty: 'Facile', views: 2500, thumbnail: '💪' },
    { id: 2, title: 'Squats pour débutants', duration: 12, difficulty: 'Facile', views: 3200, thumbnail: '🦵' },
    { id: 3, title: 'Abdos en 10 min', duration: 10, difficulty: 'Modéré', views: 4100, thumbnail: '🔥' },
    { id: 4, title: 'Circuit HIIT intense', duration: 20, difficulty: 'Intense', views: 5800, thumbnail: '⚡' },
    { id: 5, title: 'Étirements du soir', duration: 15, difficulty: 'Facile', views: 1900, thumbnail: '🧘' },
    { id: 6, title: 'Gainages avancés', duration: 18, difficulty: 'Intense', views: 3400, thumbnail: '💯' },
  ]);

  const [selectedCategory, setSelectedCategory] = useState('Tous');
  const categories = ['Tous', 'Facile', 'Modéré', 'Intense'];

  return (
    <div className="exercise-videos">
      <h1>🎥 Vidéos d\'exercices</h1>

      {/* Categories */}
      <div className="categories">
        {categories.map(cat => (
          <button 
            key={cat}
            className={`category-btn ${selectedCategory === cat ? 'active' : ''}`}
            onClick={() => setSelectedCategory(cat)}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Video Grid */}
      <div className="videos-grid">
        {videos.map(video => (
          <div key={video.id} className="video-card">
            <div className="video-thumbnail">
              <div className="thumbnail-icon">{video.thumbnail}</div>
              <div className="play-button">
                <Play size={32} fill="white" color="white" />
              </div>
              <span className="video-duration">
                <Clock size={12} /> {video.duration}min
              </span>
            </div>
            <div className="video-info">
              <h3>{video.title}</h3>
              <div className="video-meta">
                <span className="difficulty">{video.difficulty}</span>
                <span className="views">👁️ {video.views}</span>
              </div>
              <button className="btn-watch">Regarder</button>
            </div>
          </div>
        ))}
      </div>

      {/* Recommended Workout Plans */}
      <div className="workout-plans">
        <h2>📅 Programmes recommandés</h2>
        
        <div className="plan-card">
          <h3>🔥 Défi 7 jours</h3>
          <p>Entraînements quotidiens de 20 minutes</p>
          <div className="plan-videos">
            <span>5 vidéos</span>
            <span>Intense</span>
          </div>
          <button className="btn-start">Commencer</button>
        </div>

        <div className="plan-card">
          <h3>💪 Musculation débutant</h3>
          <p>Programme complet 3x/semaine</p>
          <div className="plan-videos">
            <span>12 vidéos</span>
            <span>Modéré</span>
          </div>
          <button className="btn-start">Commencer</button>
        </div>

        <div className="plan-card">
          <h3>🧘 Flexibilité & Relax</h3>
          <p>Étirements et méditation</p>
          <div className="plan-videos">
            <span>8 vidéos</span>
            <span>Facile</span>
          </div>
          <button className="btn-start">Commencer</button>
        </div>
      </div>

      <style jsx>{`
        .exercise-videos {
          padding: 20px;
          max-width: 500px;
          margin: 0 auto;
        }

        .exercise-videos h1 {
          margin-bottom: 20px;
          color: #ff6b35;
        }

        .categories {
          display: flex;
          gap: 10px;
          margin-bottom: 20px;
          overflow-x: auto;
          padding-bottom: 10px;
        }

        .category-btn {
          padding: 8px 16px;
          border: 2px solid #eee;
          background: white;
          border-radius: 20px;
          cursor: pointer;
          font-size: 12px;
          white-space: nowrap;
          transition: all 0.3s;
        }

        .category-btn.active {
          background: #ff6b35;
          color: white;
          border-color: #ff6b35;
        }

        .videos-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
          margin-bottom: 30px;
        }

        .video-card {
          background: white;
          border-radius: 12px;
          overflow: hidden;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
          transition: transform 0.3s;
        }

        .video-card:hover {
          transform: translateY(-4px);
        }

        .video-thumbnail {
          position: relative;
          width: 100%;
          aspect-ratio: 16/9;
          background: linear-gradient(135deg, #ff6b35, #ffa500);
          display: flex;
          align-items: center;
          justify-content: center;
        }

        .thumbnail-icon {
          font-size: 40px;
        }

        .play-button {
          position: absolute;
          width: 50px;
          height: 50px;
          background: rgba(0,0,0,0.5);
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          opacity: 0;
          transition: opacity 0.3s;
        }

        .video-card:hover .play-button {
          opacity: 1;
        }

        .video-duration {
          position: absolute;
          bottom: 8px;
          right: 8px;
          background: rgba(0,0,0,0.7);
          color: white;
          padding: 4px 8px;
          border-radius: 4px;
          font-size: 11px;
          display: flex;
          align-items: center;
          gap: 4px;
        }

        .video-info {
          padding: 12px;
        }

        .video-info h3 {
          margin: 0 0 8px 0;
          font-size: 13px;
          color: #333;
        }

        .video-meta {
          display: flex;
          gap: 8px;
          margin-bottom: 10px;
          font-size: 11px;
        }

        .difficulty {
          background: #ffe0cc;
          color: #ff6b35;
          padding: 2px 6px;
          border-radius: 3px;
        }

        .views {
          color: #999;
        }

        .btn-watch {
          width: 100%;
          padding: 8px;
          background: #f0f0f0;
          border: none;
          border-radius: 6px;
          color: #ff6b35;
          font-weight: bold;
          font-size: 12px;
          cursor: pointer;
        }

        .workout-plans {
          margin-top: 30px;
        }

        .workout-plans h2 {
          margin-bottom: 15px;
          color: #333;
        }

        .plan-card {
          background: white;
          border: 2px solid #eee;
          padding: 15px;
          border-radius: 12px;
          margin-bottom: 12px;
        }

        .plan-card h3 {
          margin: 0 0 5px 0;
          color: #333;
          font-size: 14px;
        }

        .plan-card p {
          margin: 0 0 10px 0;
          font-size: 12px;
          color: #666;
        }

        .plan-videos {
          display: flex;
          gap: 12px;
          margin-bottom: 10px;
          font-size: 11px;
          color: #999;
        }

        .btn-start {
          width: 100%;
          padding: 10px;
          background: #ff6b35;
          color: white;
          border: none;
          border-radius: 6px;
          font-weight: bold;
          cursor: pointer;
        }
      `}</style>
    </div>
  );
}

import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Heart, MessageCircle, Share2, MoreHorizontal, 
  Plus, Users, Flame, Award, ChevronLeft, Trophy, ChevronRight
} from 'lucide-react';

const Community = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('Feed');

  const posts = [
    { 
      id: 1, user: 'Ousmane Fall', role: 'Coach', 
      content: 'Nouvelle séance de Crossfit terminée ! Fier de l\'équipe ce matin. 🇸🇳💪', 
      likes: 124, comments: 18, time: '2h',
      image: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=600&auto=format&fit=crop'
    },
    { 
      id: 2, user: 'Amina Diop', role: 'Membre Gold', 
      content: 'Enfin atteint mon objectif de 10km en moins de 50min. Merci pour les conseils !', 
      likes: 89, comments: 12, time: '5h',
      image: 'https://images.unsplash.com/photo-1502904550040-753d59f3aa56?q=80&w=600&auto=format&fit=crop'
    },
  ];

  return (
    <div className="page-container">
      {/* Header */}
      <div className="flex-between mb-8 stagger-1">
        <div>
          <h1 style={{ fontSize: '2rem', marginBottom: '4px' }}>Communauté</h1>
          <p className="subtitle">Partage tes exploits avec la team</p>
        </div>
        <button className="btn-icon" style={{ borderRadius: '50%', background: 'var(--primary)', color: '#000', border: 'none' }}>
          <Plus size={24} />
        </button>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: '24px', borderBottom: '1px solid #111', marginBottom: '32px' }} className="stagger-1">
        {['Feed', 'Défis', 'Classement'].map(tab => (
          <button 
            key={tab}
            onClick={() => setActiveTab(tab)}
            style={{ 
              background: 'transparent', border: 'none', color: activeTab === tab ? 'var(--primary)' : '#555',
              padding: '12px 0', fontSize: '1rem', fontWeight: '900', cursor: 'pointer',
              borderBottom: activeTab === tab ? '3px solid var(--primary)' : 'none'
            }}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Posts Feed */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '32px' }} className="stagger-2">
        {posts.map((post) => (
          <div key={post.id} className="post-card">
            <div className="flex-between mb-4">
              <div className="flex-center" style={{ gap: '12px' }}>
                <div style={{ width: '44px', height: '44px', borderRadius: '12px', background: '#222', border: '1px solid #333', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: '900', color: 'var(--primary)' }}>
                  {post.user.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <h4 style={{ fontSize: '0.95rem' }}>{post.user}</h4>
                  <span className="subtitle" style={{ fontSize: '0.7rem' }}>{post.role} • {post.time}</span>
                </div>
              </div>
              <MoreHorizontal size={20} color="#333" />
            </div>

            <p style={{ fontSize: '0.95rem', lineHeight: '1.6', marginBottom: '16px', color: '#eee' }}>{post.content}</p>

            {post.image && (
              <div style={{ width: '100%', borderRadius: '24px', overflow: 'hidden', marginBottom: '16px', border: '1px solid #111' }}>
                <img src={post.image} alt="post" style={{ width: '100%', height: 'auto', display: 'block' }} />
              </div>
            )}

            <div className="flex-center" style={{ justifyContent: 'flex-start', gap: '24px' }}>
              <div className="flex-center" style={{ gap: '8px', color: '#888', fontSize: '0.85rem', fontWeight: '700' }}>
                <Heart size={20} /> {post.likes}
              </div>
              <div className="flex-center" style={{ gap: '8px', color: '#888', fontSize: '0.85rem', fontWeight: '700' }}>
                <MessageCircle size={20} /> {post.comments}
              </div>
              <div className="flex-center" style={{ gap: '8px', color: '#888', fontSize: '0.85rem', fontWeight: '700' }}>
                <Share2 size={20} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Leaderboard Section */}
      <div className="mb-8 mt-8 stagger-2">
        <div className="flex-between mb-6">
          <h3 style={{ fontSize: '1.2rem', display: 'flex', alignItems: 'center', gap: '8px' }}>
            <Trophy size={22} color="var(--primary)" /> Classement Pikine
          </h3>
          <span style={{ fontSize: '0.7rem', color: 'var(--primary)', fontWeight: '800' }}>VOIR TOUT</span>
        </div>

        <div className="glass-panel" style={{ padding: '8px' }}>
          {[
            { rank: 1, name: 'Moussa D.', points: '2,840', avatar: 'https://i.pravatar.cc/150?u=moussa' },
            { rank: 2, name: 'Awa S.', points: '2,610', avatar: 'https://i.pravatar.cc/150?u=awa' },
            { rank: 3, name: 'Omar K.', points: '2,450', avatar: 'https://i.pravatar.cc/150?u=omar' },
          ].map((user, i) => (
            <div key={i} className="flex-between" style={{ padding: '16px', borderBottom: i < 2 ? '1px solid rgba(255,255,255,0.05)' : 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                <span style={{ fontWeight: '900', color: i === 0 ? 'var(--primary)' : 'var(--text-muted)', width: '20px' }}>{user.rank}</span>
                <img src={user.avatar} style={{ width: '40px', height: '40px', borderRadius: '50%', border: i === 0 ? '2px solid var(--primary)' : 'none' }} />
                <span style={{ fontWeight: '700' }}>{user.name}</span>
              </div>
              <div style={{ fontWeight: '900' }}>{user.points} <span style={{ fontSize: '0.6rem', color: 'var(--text-muted)' }}>PTS</span></div>
            </div>
          ))}
        </div>
      </div>

      <div className="mb-6 stagger-2">
        <h3 className="mb-6">DÉFIS ACTUELS</h3>
        <div className="glass-panel" style={{ display: 'flex', alignItems: 'center', gap: '16px', padding: '16px', border: '1px solid var(--primary-glow)' }}>
          <div style={{ width: '50px', height: '50px', background: 'var(--primary)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Flame size={28} color="#000" />
          </div>
          <div style={{ flex: 1 }}>
            <h4 style={{ fontSize: '1rem', marginBottom: '4px' }}>DÉFI DE LA SEMAINE</h4>
            <p className="subtitle" style={{ fontSize: '0.8rem' }}>100 tractions en 7 jours. Participe et gagne des points FitnessPlus !</p>
          </div>
          <ChevronRight size={24} color="#333" />
        </div>
      </div>
    </div>
  );
};

export default Community;

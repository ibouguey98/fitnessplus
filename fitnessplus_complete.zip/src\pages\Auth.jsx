import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Activity as Dumbbell, User, UserCheck, ShieldCheck, ArrowRight } from 'lucide-react';

const Auth = () => {
  const navigate = useNavigate();

  const handleAccess = (role) => {
    localStorage.setItem('fp_user_role', role);
    if (role === 'admin') navigate('/admin');
    else if (role === 'coach') navigate('/coach-dashboard');
    else navigate('/onboarding');
  };

  return (
    <div style={{ 
      height: '100vh', background: '#000', position: 'relative', overflow: 'hidden',
      display: 'flex', flexDirection: 'column', justifyContent: 'flex-end'
    }}>
      {/* Background Hero */}
      <div style={{ 
        position: 'absolute', top: 0, left: 0, right: 0, bottom: 0,
        background: `linear-gradient(to bottom, rgba(0,0,0,0.2) 0%, rgba(0,0,0,1) 95%), url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop')`,
        backgroundSize: 'cover', backgroundPosition: 'center', zIndex: 0
      }} />

      <div style={{ position: 'relative', zIndex: 1, padding: '40px 24px', animation: 'slideUp 0.8s ease' }}>
        <div style={{ marginBottom: '40px', textAlign: 'center' }}>
          <div style={{ width: '60px', height: '60px', background: 'var(--primary)', borderRadius: '18px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 24px', boxShadow: '0 0 40px var(--primary-glow)' }}>
            <Dumbbell size={30} color="#000" />
          </div>
          <h1 style={{ fontSize: '2.5rem', marginBottom: '8px' }}>FITNESS<span style={{ color: 'var(--primary)' }}>PLUS</span></h1>
          <p className="subtitle">Choisissez votre espace pour commencer</p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', marginBottom: '40px' }}>
          {[
            { id: 'client', label: 'Espace Client', icon: <User />, desc: 'S\'entraîner & Suivre ses progrès' },
            { id: 'coach', label: 'Espace Coach', icon: <UserCheck />, desc: 'Gérer ses séances & Clients' },
            { id: 'admin', label: 'Espace Admin', icon: <ShieldCheck />, desc: 'Contrôle total & SaaS' },
          ].map((role) => (
            <button 
              key={role.id}
              onClick={() => handleAccess(role.id)}
              className="glass-panel"
              style={{ 
                display: 'flex', alignItems: 'center', gap: '20px', padding: '24px',
                border: '1px solid var(--surface-border)', textAlign: 'left', cursor: 'pointer',
                width: '100%', position: 'relative', overflow: 'hidden'
              }}
            >
              <div style={{ width: '50px', height: '50px', background: 'rgba(255,255,255,0.05)', borderRadius: '14px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary)' }}>
                {role.icon}
              </div>
              <div style={{ flex: 1 }}>
                <h3 style={{ fontSize: '1.2rem', marginBottom: '4px' }} translate="no">{role.label}</h3>
                <p className="subtitle" style={{ fontSize: '0.8rem' }}>{role.desc}</p>
              </div>
              <ArrowRight size={20} color="#333" />
            </button>
          ))}
        </div>

        <p style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: '0.75rem', letterSpacing: '0.1em', textTransform: 'uppercase' }}>
          Ultra-Premium Fitness Experience
        </p>
      </div>
    </div>
  );
};

export default Auth;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Activity, Flame, Clock, Bell, ChevronRight, 
  TrendingUp, MoreHorizontal, Shield, Star, Trophy, Zap, Heart, Search
} from 'lucide-react';

const Dashboard = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState(null);
  const [userPlan, setUserPlan] = useState(localStorage.getItem('fp_user_plan') || 'aucun');
  const [tarifs, setTarifs] = useState({
    silver: { price: '25 000' },
    gold: { price: '45 000' },
    platinum: { price: '75 000' }
  });

  useEffect(() => {
    const savedData = localStorage.getItem('fp_user_data');
    if (savedData) setUserData(JSON.parse(savedData));

    const savedTarifs = localStorage.getItem('fp_tarifs_full');
    if (savedTarifs) setTarifs(JSON.parse(savedTarifs));
    
    const handleStorage = () => {
      const updatedTarifs = localStorage.getItem('fp_tarifs_full');
      if (updatedTarifs) setTarifs(JSON.parse(updatedTarifs));
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const getGoalLabel = (goal) => {
    const goals = { lose: 'Perte de poids', build: 'Prise de masse', fit: 'Remise en forme', wellbeing: 'Bien-être', performance: 'Performance' };
    return goals[goal] || 'Objectif Santé';
  };

  const getPlanInfo = () => {
    if (userPlan === 'platinum') return { label: 'PLATINUM VIP', icon: <Trophy size={18} color="var(--primary)" />, color: 'var(--primary)' };
    if (userPlan === 'gold') return { label: 'GOLD PASS', icon: <Star size={18} color="var(--primary)" />, color: 'var(--primary)' };
    if (userPlan === 'silver') return { label: 'SILVER PASS', icon: <Shield size={18} color="#888" />, color: '#888' };
    return { label: 'AUCUN ABONNEMENT', icon: <Zap size={18} color="#555" />, color: '#555' };
  };

  const planInfo = getPlanInfo();

  return (
    <div className="page-container" style={{ position: 'relative' }}>
      {/* Background silhouette hidden on mobile, visible on desktop */}
      <div className="desktop-bg" style={{ 
        position: 'absolute', top: 0, right: 0, width: '100%', height: '500px',
        backgroundImage: `url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop')`,
        backgroundSize: 'cover', backgroundPosition: 'center', opacity: 0.1, zIndex: 0,
        pointerEvents: 'none'
      }}>
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, background: 'linear-gradient(to bottom, transparent, black)' }} />
      </div>

      <div style={{ position: 'relative', zIndex: 1 }}>
        {/* Header */}
        <div className="flex-between mb-8 stagger-1">
          <div>
            <h1 style={{ fontSize: '1.8rem', marginBottom: '4px' }}>Bonjour, {userData?.name?.split(' ')[0] || 'Ousmane'} 👋</h1>
            <p className="subtitle">Prêt à te dépasser aujourd'hui ?</p>
          </div>
          <div className="btn-icon" onClick={() => navigate('/explore')}>
            <Search size={24} />
          </div>
        </div>

        {/* Status Card */}
        <div className="glass-panel mb-8 stagger-1" style={{ 
          background: 'linear-gradient(135deg, #111 0%, #000 100%)', 
          border: '1px solid var(--surface-border)',
          display: 'flex', alignItems: 'center', gap: '20px', padding: '20px'
        }}>
          <div style={{ width: '56px', height: '56px', background: '#080808', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid #1a1a1a' }}>
            {planInfo.icon}
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '0.65rem', fontWeight: '900', color: planInfo.color, textTransform: 'uppercase', letterSpacing: '0.1em', marginBottom: '4px' }}>STATUT MEMBRE</div>
            <h3 style={{ fontSize: '1.1rem' }}>{planInfo.label}</h3>
          </div>
          <div style={{ color: 'var(--primary)' }}><ChevronRight /></div>
        </div>

        {/* Quick Stats Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '24px' }} className="stagger-1">
          <div onClick={() => navigate('/progress')} className="glass-panel" style={{ padding: '20px', cursor: 'pointer' }}>
            <div style={{ color: 'var(--primary)', marginBottom: '12px' }}><Activity size={24} /></div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>IMC Actuel</div>
            <div style={{ fontSize: '1.4rem', fontWeight: '900' }}>22.4</div>
          </div>
          <div onClick={() => navigate('/nutrition')} className="glass-panel" style={{ padding: '20px', cursor: 'pointer' }}>
            <div style={{ color: '#4ade80', marginBottom: '12px' }}><Zap size={24} /></div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>Calories</div>
            <div style={{ fontSize: '1.4rem', fontWeight: '900' }}>1,240</div>
          </div>
        </div>

        {/* Streak & Goal */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '24px' }} className="stagger-2">
          <div className="glass-panel" style={{ padding: '20px' }}>
            <div style={{ color: 'var(--primary)', fontWeight: '800', fontSize: '0.7rem', marginBottom: '8px' }}>SÉRIE 🔥</div>
            <div style={{ fontSize: '2.5rem', fontWeight: '900' }}>12 <span style={{ fontSize: '1rem', color: 'var(--text-muted)' }}>j</span></div>
          </div>
          <div className="glass-panel" style={{ padding: '20px', textAlign: 'center' }}>
             <div style={{ position: 'relative', width: '60px', height: '60px', margin: '0 auto 8px' }}>
                <svg width="60" height="60" viewBox="0 0 60 60">
                  <circle cx="30" cy="30" r="25" fill="none" stroke="#111" strokeWidth="5" />
                  <circle cx="30" cy="30" r="25" fill="none" stroke="var(--primary)" strokeWidth="5" 
                    strokeDasharray="157" strokeDashoffset={157 * 0.3} strokeLinecap="round" transform="rotate(-90 30 30)" />
                </svg>
                <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.9rem', fontWeight: '900' }}>70%</div>
             </div>
             <div style={{ fontSize: '0.6rem', color: 'var(--text-muted)' }}>{getGoalLabel(userData?.goal)}</div>
          </div>
        </div>

        {/* Programs */}
        <div className="flex-between mb-4 stagger-3">
          <h3>Mes programmes</h3>
          <span style={{ color: 'var(--primary)', fontSize: '0.8rem', fontWeight: '800' }} onClick={() => navigate('/classes')}>VOIR TOUT</span>
        </div>
        <div style={{ display: 'flex', gap: '16px', overflowX: 'auto', paddingBottom: '16px' }} className="no-scrollbar stagger-3">
          {[
            { title: 'Full Body', weeks: '4 sem', icon: <Activity size={20} /> },
            { title: 'Cardio Brûle', weeks: '3 sem', icon: <Flame size={20} /> },
            { title: 'Musculation', weeks: '6 sem', icon: <TrendingUp size={20} /> },
          ].map((p, i) => (
            <div key={i} className="glass-panel" style={{ minWidth: '160px', padding: '20px' }}>
              <div style={{ width: '40px', height: '40px', background: 'rgba(255,255,255,0.05)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '12px', color: 'var(--primary)' }}>
                {p.icon}
              </div>
              <h4 style={{ fontSize: '0.9rem' }}>{p.title}</h4>
              <p className="subtitle" style={{ fontSize: '0.7rem' }}>{p.weeks}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
